# Supplementary Code

This folder contains standalone scripts for CAD conversion, drawing conversion,
rendering, model querying, and geometric evaluation.

## Environment

Create the recommended environment from:

```bash
conda env create -f dependencies/environment.yml
conda activate cad-reconstruction
```

The environment uses Conda because several CAD and OpenCASCADE packages are not
reliably available through pip on all platforms.

## Contents

- `solidworks_conversion/convert_solidworks_to_stl_step.py`: converts one
  SolidWorks part or assembly to STEP and STL through the SolidWorks COM API.
- `drawing_conversion/slddrw_to_pdf.py`: converts one SolidWorks drawing to PDF.
- `drawing_conversion/pdf_to_image.py`: converts one PDF page to a raster image.
- `rendering/`: CAD rendering utilities for single-view, cube-view,
  dodecahedron-view, and walkthrough-video inputs.
- `llm_query/zeroshot/`: query scripts for drawing-only and auxiliary-render
  zero-shot settings.
- `llm_query/agentic/`: query scripts for iterative feedback settings.
- `evaluation/`: alignment and geometric comparison utilities.
- `sample_data/`: ten sanitized sample cases with raw CAD files, drawings,
  drawing bitmaps, STEP, mesh, plain B-rep renders, and videos.

API credentials are read from environment variables or from local key files that
are not included in this folder.
