                      
"""
Align two STL meshes with selectable alignment modes and evaluate their geometric similarity.

Metrics:
    - Surface F-score at a configurable distance tolerance
    - Filled voxel intersection-over-union (IoU)
    - RMS Chamfer distance normalized by the reference bounding-box diagonal

Alignment modes:
    - icp: original PCA/centroid initialization followed by ICP
    - orthogonal90: test 24 axis-aligned 90-degree variants, no ICP refinement
    - none: evaluate without applying any alignment transform

Dependencies:
    pip install numpy scipy trimesh matplotlib

Example:
    python align_stl_icp_eval.py reference.stl candidate.stl \
        --surface-tolerance 1.0 --voxel-pitch 1.0 --plot
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from itertools import permutations, product
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

from align_stl_icp_chamfer import (
    IcpResult,
    compose_transform,
    icp,
    initial_pca_transform,
    load_mesh,
    plot_alignment,
    sample_points,
    transform_points,
)


@dataclass
class AlignmentCandidate:
    name: str
    transform: np.ndarray
    score: float
    icp_error: float | None = None
    icp_iterations: int = 0
    icp_converged: bool = False


def reference_diagonal(points: np.ndarray) -> float:
    diagonal = float(np.linalg.norm(np.ptp(points, axis=0)))
    if diagonal <= 0.0:
        raise ValueError("The reference mesh has a zero-size bounding box")
    return diagonal


def centroid_transform(
    source_points: np.ndarray,
    target_points: np.ndarray,
    rotation: np.ndarray | None = None,
) -> np.ndarray:
    rotation = np.eye(3, dtype=np.float64) if rotation is None else rotation
    source_centroid = source_points.mean(axis=0)
    target_centroid = target_points.mean(axis=0)
    translation = target_centroid - rotation @ source_centroid
    return compose_transform(rotation, translation)


def right_handed_axis_rotations() -> list[np.ndarray]:
    """Return the 24 proper rotations that map one XYZ frame to another."""
    rotations: list[np.ndarray] = []
    eye = np.eye(3, dtype=np.float64)
    for order in permutations(range(3)):
        permutation = eye[:, order]
        for signs in product((-1.0, 1.0), repeat=3):
            rotation = permutation @ np.diag(signs)
            if np.linalg.det(rotation) > 0.0:
                rotations.append(rotation)
    return rotations


def pca_frame_candidates(
    source_points: np.ndarray,
    target_points: np.ndarray,
) -> list[tuple[str, np.ndarray]]:
    """Generate PCA-based starts with all right-handed sign/permutation fixes."""
    source_centroid = source_points.mean(axis=0)
    target_centroid = target_points.mean(axis=0)

    source_centered = source_points - source_centroid
    target_centered = target_points - target_centroid
    _, _, source_vt = np.linalg.svd(source_centered, full_matrices=False)
    _, _, target_vt = np.linalg.svd(target_centered, full_matrices=False)
    source_axes = source_vt.T
    target_axes = target_vt.T
    if np.linalg.det(source_axes) < 0:
        source_axes[:, -1] *= -1.0
    if np.linalg.det(target_axes) < 0:
        target_axes[:, -1] *= -1.0

    candidates: list[tuple[str, np.ndarray]] = []
    for index, frame_rotation in enumerate(right_handed_axis_rotations(), start=1):
        rotation = target_axes @ frame_rotation @ source_axes.T
        translation = target_centroid - rotation @ source_centroid
        candidates.append((f"pca-frame-{index:02d}", compose_transform(rotation, translation)))
    return candidates


def transformed_symmetric_score(
    source_points: np.ndarray,
    target_points: np.ndarray,
    transform: np.ndarray,
    reject_percentile: float = 95.0,
) -> float:
    moved = transform_points(source_points, transform)
    source_to_target, target_to_source = nearest_neighbor_distances(target_points, moved)
    if 0.0 < reject_percentile < 100.0:
        source_to_target = source_to_target[
            source_to_target <= np.percentile(source_to_target, reject_percentile)
        ]
        target_to_source = target_to_source[
            target_to_source <= np.percentile(target_to_source, reject_percentile)
        ]
    return float(0.5 * (np.mean(source_to_target) + np.mean(target_to_source)))


def initial_alignment_candidates(
    source_points: np.ndarray,
    target_points: np.ndarray,
    *,
    include_pca: bool,
    include_orthogonal: bool,
    reject_percentile: float,
) -> list[AlignmentCandidate]:
    raw_candidates: list[tuple[str, np.ndarray]] = [
        ("centroid", centroid_transform(source_points, target_points)),
    ]

    if include_pca:
        raw_candidates.append(("legacy-pca", initial_pca_transform(source_points, target_points)))
        raw_candidates.extend(pca_frame_candidates(source_points, target_points))

    if include_orthogonal:
        for index, rotation in enumerate(right_handed_axis_rotations(), start=1):
            raw_candidates.append(
                (
                    f"orthogonal-axis-{index:02d}",
                    centroid_transform(source_points, target_points, rotation),
                )
            )

    unique: dict[tuple[float, ...], tuple[str, np.ndarray]] = {}
    for name, transform in raw_candidates:
        key = tuple(np.round(transform[:3, :].ravel(), decimals=10))
        unique.setdefault(key, (name, transform))

    candidates = [
        AlignmentCandidate(
            name=name,
            transform=transform,
            score=transformed_symmetric_score(
                source_points,
                target_points,
                transform,
                reject_percentile=reject_percentile,
            ),
        )
        for name, transform in unique.values()
    ]
    candidates.sort(key=lambda candidate: candidate.score)
    return candidates


def choose_icp_alignment(
    source_points: np.ndarray,
    target_points: np.ndarray,
    *,
    no_pca_init: bool,
    orthogonal_init: bool,
    multistart_count: int,
    coarse_iterations: int,
    max_iterations: int,
    tolerance: float,
    reject_percentile: float,
    verbose: bool,
):
    candidates = initial_alignment_candidates(
        source_points,
        target_points,
        include_pca=not no_pca_init,
        include_orthogonal=orthogonal_init,
        reject_percentile=reject_percentile,
    )
    if not candidates:
        raise RuntimeError("No alignment candidates were generated")

    shortlist = candidates[: max(1, multistart_count)]
    refined: list[AlignmentCandidate] = []
    for candidate in shortlist:
        coarse = icp(
            source_points,
            target_points,
            initial_transform=candidate.transform,
            max_iterations=max(1, coarse_iterations),
            tolerance=tolerance,
            reject_percentile=reject_percentile,
        )
        score = transformed_symmetric_score(
            source_points,
            target_points,
            coarse.transform,
            reject_percentile=reject_percentile,
        )
        refined.append(
            AlignmentCandidate(
                name=candidate.name,
                transform=coarse.transform,
                score=score,
                icp_error=coarse.mean_error,
                icp_iterations=coarse.iterations,
                icp_converged=coarse.converged,
            )
        )

    refined.sort(key=lambda candidate: candidate.score)
    best = refined[0]
    result = icp(
        source_points,
        target_points,
        initial_transform=best.transform,
        max_iterations=max_iterations,
        tolerance=tolerance,
        reject_percentile=reject_percentile,
    )

    if verbose:
        print("Alignment candidate search")
        print(f"  generated starts: {len(candidates)}")
        print(f"  coarse ICP starts tried: {len(shortlist)}")
        for index, candidate in enumerate(refined[: min(8, len(refined))], start=1):
            print(
                f"  #{index}: {candidate.name}, score={candidate.score:.6g}, "
                f"coarse_error={candidate.icp_error:.6g}"
            )
        print(f"  selected start: {best.name}")
        print()

    return result, best, candidates


def choose_alignment_by_mode(
    source_points: np.ndarray,
    target_points: np.ndarray,
    *,
    alignment_mode: str,
    no_pca_init: bool,
    max_iterations: int,
    tolerance: float,
    reject_percentile: float,
    verbose: bool,
) -> tuple[IcpResult, AlignmentCandidate]:
    if alignment_mode == "none":
        transform = np.eye(4, dtype=np.float64)
        score = transformed_symmetric_score(
            source_points,
            target_points,
            transform,
            reject_percentile=reject_percentile,
        )
        return (
            IcpResult(transform, score, 0, True),
            AlignmentCandidate("none", transform, score),
        )

    if alignment_mode == "orthogonal90":
        candidates = [
            AlignmentCandidate(
                name=f"orthogonal-axis-{index:02d}",
                transform=centroid_transform(source_points, target_points, rotation),
                score=0.0,
            )
            for index, rotation in enumerate(right_handed_axis_rotations(), start=1)
        ]
        for candidate in candidates:
            candidate.score = transformed_symmetric_score(
                source_points,
                target_points,
                candidate.transform,
                reject_percentile=reject_percentile,
            )
        candidates.sort(key=lambda candidate: candidate.score)
        best = candidates[0]

        if verbose:
            print("Orthogonal 90-degree alignment search")
            print(f"  tested starts: {len(candidates)}")
            for index, candidate in enumerate(candidates[: min(8, len(candidates))], start=1):
                print(f"  #{index}: {candidate.name}, score={candidate.score:.6g}")
            print(f"  selected start: {best.name}")
            print()

        return IcpResult(best.transform, best.score, 0, True), best

    if alignment_mode == "icp":
        if no_pca_init:
            initial_transform = centroid_transform(source_points, target_points)
            selected = AlignmentCandidate("centroid", initial_transform, 0.0)
        else:
            initial_transform = initial_pca_transform(source_points, target_points)
            selected = AlignmentCandidate("pca", initial_transform, 0.0)

        result = icp(
            source_points,
            target_points,
            initial_transform=initial_transform,
            max_iterations=max_iterations,
            tolerance=tolerance,
            reject_percentile=reject_percentile,
        )
        selected.score = transformed_symmetric_score(
            source_points,
            target_points,
            result.transform,
            reject_percentile=reject_percentile,
        )
        return result, selected

    raise ValueError(f"Unknown alignment mode: {alignment_mode}")


def nearest_neighbor_distances(
    reference_points: np.ndarray,
    candidate_points: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    reference_tree = cKDTree(reference_points)
    candidate_tree = cKDTree(candidate_points)
    reference_to_candidate, _ = candidate_tree.query(reference_points, k=1)
    candidate_to_reference, _ = reference_tree.query(candidate_points, k=1)
    return reference_to_candidate, candidate_to_reference


def surface_fscore(
    reference_to_candidate: np.ndarray,
    candidate_to_reference: np.ndarray,
    tolerance: float,
) -> dict[str, float]:
    if tolerance <= 0.0:
        raise ValueError("Surface tolerance must be greater than zero")

    recall = float(np.mean(reference_to_candidate <= tolerance))
    precision = float(np.mean(candidate_to_reference <= tolerance))
    denominator = precision + recall
    fscore = 2.0 * precision * recall / denominator if denominator > 0.0 else 0.0

    return {
        "precision": precision,
        "recall": recall,
        "fscore": fscore,
    }


def normalized_rms_chamfer(
    reference_to_candidate: np.ndarray,
    candidate_to_reference: np.ndarray,
    diagonal: float,
) -> dict[str, float]:
    reference_rms = float(np.sqrt(np.mean(reference_to_candidate**2)))
    candidate_rms = float(np.sqrt(np.mean(candidate_to_reference**2)))
    symmetric_rms = float(
        np.sqrt(
            0.5
            * (
                np.mean(reference_to_candidate**2)
                + np.mean(candidate_to_reference**2)
            )
        )
    )

    return {
        "reference_rms": reference_rms,
        "candidate_rms": candidate_rms,
        "symmetric_rms": symmetric_rms,
        "normalized_rms": symmetric_rms / diagonal,
    }


def normalized_mean_chamfer(
    reference_to_candidate: np.ndarray,
    candidate_to_reference: np.ndarray,
    diagonal: float,
) -> dict[str, float]:
    reference_mean = float(np.mean(reference_to_candidate))
    candidate_mean = float(np.mean(candidate_to_reference))
    symmetric_mean = 0.5 * (reference_mean + candidate_mean)

    return {
        "reference_mean": reference_mean,
        "candidate_mean": candidate_mean,
        "symmetric_mean": symmetric_mean,
        "normalized_mean": symmetric_mean / diagonal,
    }


def hausdorff_distance(
    reference_to_candidate: np.ndarray,
    candidate_to_reference: np.ndarray,
    diagonal: float,
) -> dict[str, float]:
    reference_max = float(np.max(reference_to_candidate))
    candidate_max = float(np.max(candidate_to_reference))
    hausdorff = max(reference_max, candidate_max)

    reference_p95 = float(np.percentile(reference_to_candidate, 95.0))
    candidate_p95 = float(np.percentile(candidate_to_reference, 95.0))
    robust_hausdorff = max(reference_p95, candidate_p95)

    return {
        "reference_max": reference_max,
        "candidate_max": candidate_max,
        "hausdorff": hausdorff,
        "normalized_hausdorff": hausdorff / diagonal,
        "reference_p95": reference_p95,
        "candidate_p95": candidate_p95,
        "robust_hausdorff": robust_hausdorff,
        "normalized_robust_hausdorff": robust_hausdorff / diagonal,
    }


def size_errors(reference_mesh, candidate_mesh) -> dict[str, float | bool]:
    reference_volume = abs(float(reference_mesh.volume))
    candidate_volume = abs(float(candidate_mesh.volume))
    volume_difference = abs(candidate_volume - reference_volume)
    volume_error_percent = (
        volume_difference / reference_volume * 100.0
        if reference_volume > 0.0
        else float("nan")
    )

    reference_area = float(reference_mesh.area)
    candidate_area = float(candidate_mesh.area)
    area_difference = abs(candidate_area - reference_area)
    area_error_percent = (
        area_difference / reference_area * 100.0
        if reference_area > 0.0
        else float("nan")
    )

    return {
        "reference_volume": reference_volume,
        "candidate_volume": candidate_volume,
        "volume_difference": volume_difference,
        "volume_error_percent": volume_error_percent,
        "reference_area": reference_area,
        "candidate_area": candidate_area,
        "area_difference": area_difference,
        "area_error_percent": area_error_percent,
        "reference_watertight": bool(reference_mesh.is_watertight),
        "candidate_watertight": bool(candidate_mesh.is_watertight),
    }


def voxel_indices(mesh, pitch: float, origin: np.ndarray) -> np.ndarray:
    voxel_grid = mesh.voxelized(pitch).fill()
    points = np.asarray(voxel_grid.points, dtype=np.float64)
    if points.size == 0:
        return np.empty((0, 3), dtype=np.int64)

    indices = np.rint((points - origin) / pitch).astype(np.int64)
    return np.unique(indices, axis=0)


def rows_as_structured(array: np.ndarray) -> np.ndarray:
    contiguous = np.ascontiguousarray(array)
    dtype = np.dtype((np.void, contiguous.dtype.itemsize * contiguous.shape[1]))
    return contiguous.view(dtype).ravel()


def voxel_iou(reference_mesh, aligned_candidate_mesh, pitch: float) -> dict[str, float | int]:
    if pitch <= 0.0:
        raise ValueError("Voxel pitch must be greater than zero")

    combined_min = np.minimum(reference_mesh.bounds[0], aligned_candidate_mesh.bounds[0])
    origin = np.floor(combined_min / pitch) * pitch

    reference_indices = voxel_indices(reference_mesh, pitch, origin)
    candidate_indices = voxel_indices(aligned_candidate_mesh, pitch, origin)
    reference_rows = rows_as_structured(reference_indices)
    candidate_rows = rows_as_structured(candidate_indices)

    intersection_count = int(np.intersect1d(reference_rows, candidate_rows).size)
    union_count = int(reference_rows.size + candidate_rows.size - intersection_count)
    iou = intersection_count / union_count if union_count else 1.0

    return {
        "iou": float(iou),
        "intersection_voxels": intersection_count,
        "union_voxels": union_count,
        "reference_voxels": int(reference_rows.size),
        "candidate_voxels": int(candidate_rows.size),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate two STL files with selectable alignment modes."
    )
    parser.add_argument("reference_stl", type=Path, help="Fixed/reference STL file")
    parser.add_argument("candidate_stl", type=Path, help="Candidate STL file to align")
    parser.add_argument("--samples", type=int, default=10000, help="Surface samples per mesh")
    parser.add_argument("--max-iterations", type=int, default=80, help="Maximum ICP iterations")
    parser.add_argument("--tolerance", type=float, default=1e-6, help="ICP convergence tolerance")
    parser.add_argument(
        "--reject-percentile",
        type=float,
        default=95.0,
        help="Ignore matches above this percentile for ICP/scoring; use 100 to disable",
    )
    parser.add_argument("--seed", type=int, default=7, help="Surface-sampling random seed")
    parser.add_argument(
        "--alignment-mode",
        choices=("icp", "orthogonal90", "none"),
        default="icp",
        help=(
            "Alignment type: icp uses the original PCA/centroid + ICP flow; "
            "orthogonal90 tests 24 axis-aligned 90-degree variants without ICP; "
            "none evaluates the meshes without applying a transform."
        ),
    )
    parser.add_argument("--no-pca-init", action="store_true", help="For icp mode, use centroid initialization only")
    parser.add_argument(
        "--quiet-alignment-search",
        action="store_true",
        help="Do not print the orthogonal90 candidate ranking",
    )
    parser.add_argument(
        "--surface-tolerance",
        type=float,
        help="Absolute distance threshold for surface F-score; default is 1%% of reference diagonal",
    )
    parser.add_argument(
        "--voxel-pitch",
        type=float,
        help="Voxel side length; default is 1/80 of the reference diagonal",
    )
    parser.add_argument("--output", type=Path, help="Optional aligned candidate STL output path")
    parser.add_argument("--matrix", action="store_true", help="Print the final 4x4 transform matrix")
    parser.add_argument("--plot", action="store_true", help="Show blue reference and red candidate points")
    parser.add_argument("--plot-output", type=Path, help="Optional path for the alignment PNG")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.samples < 3:
        raise ValueError("At least three surface samples are required")

    reference_mesh = load_mesh(args.reference_stl)
    candidate_mesh = load_mesh(args.candidate_stl)
    reference_points = sample_points(reference_mesh, args.samples, args.seed)
    candidate_points = sample_points(candidate_mesh, args.samples, args.seed)
    diagonal = reference_diagonal(np.asarray(reference_mesh.vertices, dtype=np.float64))

    result, selected_start = choose_alignment_by_mode(
        candidate_points,
        reference_points,
        alignment_mode=args.alignment_mode,
        no_pca_init=args.no_pca_init,
        max_iterations=args.max_iterations,
        tolerance=args.tolerance,
        reject_percentile=args.reject_percentile,
        verbose=not args.quiet_alignment_search,
    )

    aligned_candidate_points = transform_points(candidate_points, result.transform)
    aligned_candidate_mesh = candidate_mesh.copy()
    aligned_candidate_mesh.apply_transform(result.transform)

    reference_to_candidate, candidate_to_reference = nearest_neighbor_distances(
        reference_points,
        aligned_candidate_points,
    )

    surface_tolerance = (
        args.surface_tolerance
        if args.surface_tolerance is not None
        else diagonal * 0.01
    )
    voxel_pitch = args.voxel_pitch if args.voxel_pitch is not None else diagonal / 80.0
    fscore = surface_fscore(
        reference_to_candidate,
        candidate_to_reference,
        surface_tolerance,
    )
    rms_chamfer = normalized_rms_chamfer(
        reference_to_candidate,
        candidate_to_reference,
        diagonal,
    )
    mean_chamfer = normalized_mean_chamfer(
        reference_to_candidate,
        candidate_to_reference,
        diagonal,
    )
    hausdorff = hausdorff_distance(
        reference_to_candidate,
        candidate_to_reference,
        diagonal,
    )
    voxels = voxel_iou(reference_mesh, aligned_candidate_mesh, voxel_pitch)
    sizes = size_errors(reference_mesh, aligned_candidate_mesh)

    print("Alignment")
    print(f"  mode: {args.alignment_mode}")
    print(f"  selected pose: {selected_start.name}")
    if args.alignment_mode == "icp":
        print(f"  ICP converged: {result.converged}")
        print(f"  ICP iterations: {result.iterations}")
        print(f"  final ICP mean nearest-neighbor error (lower is better): {result.mean_error:.6g}")
    else:
        print("  ICP used: False")
        print(f"  alignment nearest-neighbor score (lower is better): {result.mean_error:.6g}")
    print()
    print(f"Surface F-score (tolerance {surface_tolerance:.6g})")
    print(f"  precision (higher is better): {fscore['precision'] * 100.0:.2f}%")
    print(f"  recall (higher is better): {fscore['recall'] * 100.0:.2f}%")
    print(f"  F-score (higher is better): {fscore['fscore'] * 100.0:.2f}%")
    print()
    print(f"Voxel IoU (pitch {voxel_pitch:.6g})")
    print(f"  IoU (higher is better): {voxels['iou'] * 100.0:.2f}%")
    print(f"  intersection voxels: {voxels['intersection_voxels']}")
    print(f"  union voxels: {voxels['union_voxels']}")
    print()
    print("RMS Chamfer")
    print(f"  reference -> candidate RMS (lower is better): {rms_chamfer['reference_rms']:.6g}")
    print(f"  candidate -> reference RMS (lower is better): {rms_chamfer['candidate_rms']:.6g}")
    print(f"  symmetric RMS Chamfer (lower is better): {rms_chamfer['symmetric_rms']:.6g}")
    print(f"  normalized RMS Chamfer (lower is better): {rms_chamfer['normalized_rms']:.6g}")
    print()
    print("Mean Chamfer (non-RMS)")
    print(f"  reference -> candidate mean (lower is better): {mean_chamfer['reference_mean']:.6g}")
    print(f"  candidate -> reference mean (lower is better): {mean_chamfer['candidate_mean']:.6g}")
    print(f"  symmetric mean Chamfer (lower is better): {mean_chamfer['symmetric_mean']:.6g}")
    print(f"  normalized mean Chamfer (lower is better): {mean_chamfer['normalized_mean']:.6g}")
    print()
    print("Hausdorff distance")
    print(f"  reference -> candidate maximum (lower is better): {hausdorff['reference_max']:.6g}")
    print(f"  candidate -> reference maximum (lower is better): {hausdorff['candidate_max']:.6g}")
    print(f"  Hausdorff maximum (lower is better): {hausdorff['hausdorff']:.6g}")
    print(f"  normalized Hausdorff maximum (lower is better): {hausdorff['normalized_hausdorff']:.6g}")
    print(f"  robust Hausdorff 95th percentile (lower is better): {hausdorff['robust_hausdorff']:.6g}")
    print(f"  normalized robust Hausdorff (lower is better): {hausdorff['normalized_robust_hausdorff']:.6g}")
    print()
    print("Volume accuracy")
    print(f"  reference volume: {sizes['reference_volume']:.6g}")
    print(f"  candidate volume: {sizes['candidate_volume']:.6g}")
    print(f"  absolute volume difference (lower is better): {sizes['volume_difference']:.6g}")
    print(f"  volume error (lower is better): {sizes['volume_error_percent']:.2f}%")
    print(f"  reference watertight: {sizes['reference_watertight']}")
    print(f"  candidate watertight: {sizes['candidate_watertight']}")
    print()
    print("Surface-area accuracy")
    print(f"  reference surface area: {sizes['reference_area']:.6g}")
    print(f"  candidate surface area: {sizes['candidate_area']:.6g}")
    print(f"  absolute area difference (lower is better): {sizes['area_difference']:.6g}")
    print(f"  surface-area error (lower is better): {sizes['area_error_percent']:.2f}%")

    if args.matrix:
        print()
        print("Transform matrix candidate -> reference")
        print(np.array2string(result.transform, precision=8, suppress_small=True))

    if args.output:
        aligned_candidate_mesh.export(args.output)
        print()
        print(f"Wrote aligned STL: {args.output}")

    if args.plot or args.plot_output:
        plot_alignment(
            reference_points,
            aligned_candidate_points,
            output_path=args.plot_output,
            show=args.plot,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
