                      
"""
Align two STL files with rigid ICP and compare them with Chamfer distance.

The script treats the first mesh as the fixed/reference mesh and transforms the
second mesh onto it. Alignment is rotation + translation only; no scaling is
applied.

Dependencies:
    pip install numpy scipy trimesh matplotlib

Example:
    python align_stl_icp_chamfer.py reference.stl candidate.stl --output aligned.stl --plot
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import trimesh
from scipy.spatial import cKDTree


@dataclass
class IcpResult:
    transform: np.ndarray
    mean_error: float
    iterations: int
    converged: bool


def load_mesh(path: Path) -> trimesh.Trimesh:
    loaded = trimesh.load_mesh(path, force="mesh")
    if isinstance(loaded, trimesh.Scene):
        if not loaded.geometry:
            raise ValueError(f"{path} did not contain any mesh geometry")
        loaded = trimesh.util.concatenate(tuple(loaded.geometry.values()))

    if not isinstance(loaded, trimesh.Trimesh) or loaded.vertices.size == 0:
        raise ValueError(f"{path} did not load as a non-empty mesh")

    return loaded


def sample_points(mesh: trimesh.Trimesh, count: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    if len(mesh.faces) > 0:
        points, _ = trimesh.sample.sample_surface(mesh, count, seed=rng)
        return np.asarray(points, dtype=np.float64)

    vertices = np.asarray(mesh.vertices, dtype=np.float64)
    if len(vertices) <= count:
        return vertices.copy()
    indices = rng.choice(len(vertices), size=count, replace=False)
    return vertices[indices]


def transform_points(points: np.ndarray, transform: np.ndarray) -> np.ndarray:
    return points @ transform[:3, :3].T + transform[:3, 3]


def compose_transform(rotation: np.ndarray, translation: np.ndarray) -> np.ndarray:
    transform = np.eye(4, dtype=np.float64)
    transform[:3, :3] = rotation
    transform[:3, 3] = translation
    return transform


def best_fit_transform(source: np.ndarray, target: np.ndarray) -> np.ndarray:
    source_centroid = source.mean(axis=0)
    target_centroid = target.mean(axis=0)
    source_centered = source - source_centroid
    target_centered = target - target_centroid

    covariance = source_centered.T @ target_centered
    u, _, vt = np.linalg.svd(covariance)
    rotation = vt.T @ u.T

    if np.linalg.det(rotation) < 0:
        vt[-1, :] *= -1.0
        rotation = vt.T @ u.T

    translation = target_centroid - rotation @ source_centroid
    return compose_transform(rotation, translation)


def pca_axes(points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    centroid = points.mean(axis=0)
    centered = points - centroid
    covariance = np.cov(centered.T)
    values, vectors = np.linalg.eigh(covariance)
    order = np.argsort(values)[::-1]
    axes = vectors[:, order]

    if np.linalg.det(axes) < 0:
        axes[:, -1] *= -1.0

    return centroid, axes


def initial_pca_transform(source: np.ndarray, target: np.ndarray) -> np.ndarray:
    source_centroid, source_axes = pca_axes(source)
    target_centroid, target_axes = pca_axes(target)

    best_transform = np.eye(4, dtype=np.float64)
    best_error = np.inf
    tree = cKDTree(target)

                                                                      
    for signs in (
        np.array([1.0, 1.0, 1.0]),
        np.array([1.0, -1.0, -1.0]),
        np.array([-1.0, 1.0, -1.0]),
        np.array([-1.0, -1.0, 1.0]),
    ):
        signed_target_axes = target_axes @ np.diag(signs)
        rotation = signed_target_axes @ source_axes.T
        translation = target_centroid - rotation @ source_centroid
        transform = compose_transform(rotation, translation)
        distances, _ = tree.query(transform_points(source, transform), k=1)
        error = float(np.mean(distances))
        if error < best_error:
            best_error = error
            best_transform = transform

    return best_transform


def icp(
    source: np.ndarray,
    target: np.ndarray,
    initial_transform: np.ndarray | None = None,
    max_iterations: int = 80,
    tolerance: float = 1e-6,
    reject_percentile: float = 95.0,
) -> IcpResult:
    transform = np.eye(4, dtype=np.float64) if initial_transform is None else initial_transform.copy()
    tree = cKDTree(target)
    previous_error = np.inf
    converged = False

    for iteration in range(1, max_iterations + 1):
        moved = transform_points(source, transform)
        distances, indices = tree.query(moved, k=1)

        if 0.0 < reject_percentile < 100.0:
            cutoff = np.percentile(distances, reject_percentile)
            keep = distances <= cutoff
            moved_kept = moved[keep]
            target_kept = target[indices[keep]]
            distances_kept = distances[keep]
        else:
            moved_kept = moved
            target_kept = target[indices]
            distances_kept = distances

        delta = best_fit_transform(moved_kept, target_kept)
        transform = delta @ transform
        mean_error = float(np.mean(distances_kept))

        if abs(previous_error - mean_error) < tolerance:
            converged = True
            return IcpResult(transform, mean_error, iteration, converged)

        previous_error = mean_error

    return IcpResult(transform, previous_error, max_iterations, converged)


def chamfer_distance(a: np.ndarray, b: np.ndarray) -> dict[str, float]:
    tree_a = cKDTree(a)
    tree_b = cKDTree(b)
    distances_a_to_b, _ = tree_b.query(a, k=1)
    distances_b_to_a, _ = tree_a.query(b, k=1)

    mean_a_to_b = float(np.mean(distances_a_to_b))
    mean_b_to_a = float(np.mean(distances_b_to_a))
    chamfer_mean = mean_a_to_b + mean_b_to_a
    chamfer_squared = float(np.mean(distances_a_to_b**2) + np.mean(distances_b_to_a**2))

    diagonal = float(np.linalg.norm(np.ptp(np.vstack((a, b)), axis=0)))
    normalized = chamfer_mean / diagonal if diagonal > 0.0 else 0.0
    similarity = max(0.0, 1.0 - normalized) * 100.0

    return {
        "mean_a_to_b": mean_a_to_b,
        "mean_b_to_a": mean_b_to_a,
        "chamfer_mean": chamfer_mean,
        "chamfer_squared": chamfer_squared,
        "normalized_chamfer": normalized,
        "similarity_percent": similarity,
    }


def set_axes_equal(ax) -> None:
    limits = np.array(
        [
            ax.get_xlim3d(),
            ax.get_ylim3d(),
            ax.get_zlim3d(),
        ],
        dtype=np.float64,
    )
    centers = limits.mean(axis=1)
    radius = 0.5 * np.max(limits[:, 1] - limits[:, 0])

    ax.set_xlim3d([centers[0] - radius, centers[0] + radius])
    ax.set_ylim3d([centers[1] - radius, centers[1] + radius])
    ax.set_zlim3d([centers[2] - radius, centers[2] + radius])


def plot_alignment(
    reference_points: np.ndarray,
    aligned_candidate_points: np.ndarray,
    output_path: Path | None = None,
    show: bool = False,
) -> None:
    import matplotlib.pyplot as plt

    fig = plt.figure(figsize=(9, 8))
    ax = fig.add_subplot(111, projection="3d")

    ax.scatter(
        reference_points[:, 0],
        reference_points[:, 1],
        reference_points[:, 2],
        s=2,
        c="blue",
        alpha=0.45,
        depthshade=False,
        label="Reference STL",
    )
    ax.scatter(
        aligned_candidate_points[:, 0],
        aligned_candidate_points[:, 1],
        aligned_candidate_points[:, 2],
        s=2,
        c="red",
        alpha=0.45,
        depthshade=False,
        label="Aligned candidate STL",
    )

    ax.set_title("ICP Alignment Result")
    ax.set_xlabel("X")
    ax.set_ylabel("Y")
    ax.set_zlabel("Z")
    ax.legend(loc="upper right")
    set_axes_equal(ax)
    fig.tight_layout()

    if output_path:
        fig.savefig(output_path, dpi=200)
        print()
        print(f"Wrote alignment plot: {output_path}")

    if show:
        plt.show()

    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rigidly align two STL files using ICP, then compare similarity with Chamfer distance."
    )
    parser.add_argument("reference_stl", type=Path, help="Fixed/reference STL file")
    parser.add_argument("candidate_stl", type=Path, help="Moving/candidate STL file to align")
    parser.add_argument("--samples", type=int, default=5000, help="Surface sample count per mesh")
    parser.add_argument("--max-iterations", type=int, default=80, help="Maximum ICP iterations")
    parser.add_argument("--tolerance", type=float, default=1e-6, help="ICP convergence tolerance")
    parser.add_argument(
        "--reject-percentile",
        type=float,
        default=95.0,
        help="Ignore worst matching distances above this percentile during ICP; use 100 to disable",
    )
    parser.add_argument("--seed", type=int, default=7, help="Random seed for mesh surface sampling")
    parser.add_argument("--no-pca-init", action="store_true", help="Start ICP from centroid alignment only")
    parser.add_argument("--output", type=Path, help="Optional path to write the aligned candidate STL")
    parser.add_argument("--matrix", action="store_true", help="Print the final 4x4 transform matrix")
    parser.add_argument("--plot", action="store_true", help="Show a red/blue 3D scatter plot of the aligned result")
    parser.add_argument("--plot-output", type=Path, help="Optional PNG path for the red/blue alignment plot")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    reference_mesh = load_mesh(args.reference_stl)
    candidate_mesh = load_mesh(args.candidate_stl)

    reference_points = sample_points(reference_mesh, args.samples, args.seed)
    candidate_points = sample_points(candidate_mesh, args.samples, args.seed)

    if args.no_pca_init:
        translation = reference_points.mean(axis=0) - candidate_points.mean(axis=0)
        initial_transform = compose_transform(np.eye(3), translation)
    else:
        initial_transform = initial_pca_transform(candidate_points, reference_points)

    result = icp(
        candidate_points,
        reference_points,
        initial_transform=initial_transform,
        max_iterations=args.max_iterations,
        tolerance=args.tolerance,
        reject_percentile=args.reject_percentile,
    )

    aligned_candidate_points = transform_points(candidate_points, result.transform)
    metrics = chamfer_distance(reference_points, aligned_candidate_points)

    print("ICP alignment")
    print(f"  converged: {result.converged}")
    print(f"  iterations: {result.iterations}")
    print(f"  final mean nearest-neighbor error: {result.mean_error:.6g}")
    print()
    print("Chamfer similarity")
    print(f"  reference -> aligned candidate mean distance: {metrics['mean_a_to_b']:.6g}")
    print(f"  aligned candidate -> reference mean distance: {metrics['mean_b_to_a']:.6g}")
    print(f"  symmetric chamfer mean distance: {metrics['chamfer_mean']:.6g}")
    print(f"  symmetric chamfer squared distance: {metrics['chamfer_squared']:.6g}")
    print(f"  normalized chamfer: {metrics['normalized_chamfer']:.6g}")
    print(f"  similarity score: {metrics['similarity_percent']:.2f}%")

    if args.matrix:
        print()
        print("Transform matrix candidate -> reference")
        print(np.array2string(result.transform, precision=8, suppress_small=True))

    if args.output:
        aligned_mesh = candidate_mesh.copy()
        aligned_mesh.apply_transform(result.transform)
        aligned_mesh.export(args.output)
        print()
        print(f"Wrote aligned STL: {args.output}")

    if args.plot or args.plot_output:
        plot_alignment(
            reference_points,
            aligned_candidate_points,
            output_path=args.plot_output,
            show=args.plot,
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
