"""Render eight CAD views from normalized cube-vertex directions."""

from __future__ import annotations

import argparse
import itertools
import math
import sys
from pathlib import Path

import numpy as np

from render_cad_wireframe import (
    SUPPORTED_EXTENSIONS,
    RenderError,
    camera_basis,
    load_geometry,
    render_wireframe,
)
from render_cad_wireframe_all_angle import angle_label, common_fit_distance, spherical_angles


def cube_vertex_directions() -> list[np.ndarray]:
    """Return the 8 unit vectors pointing to cube vertices."""
    directions: list[np.ndarray] = []
    for vertex in itertools.product((-1.0, 1.0), repeat=3):
        direction = np.asarray(vertex, dtype=float)
        directions.append(direction / np.linalg.norm(direction))
    return directions


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render 8 wireframe views of an STL or STEP model from cube vertex directions."
    )
    parser.add_argument("input", type=Path, help="Input .stl, .step, or .stp model")
    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        help="Output directory (default: <model>_cube_vertices)",
    )
    parser.add_argument(
        "--distance",
        type=float,
        default=None,
        help="Camera distance in model radii (default: automatically fit all views)",
    )
    parser.add_argument(
        "--margin",
        type=float,
        default=0.05,
        help="Automatic-fit image border as a fraction (default: 0.05)",
    )
    parser.add_argument("--fov", type=float, default=35.0, help="Vertical field of view in degrees")
    parser.add_argument(
        "--projection",
        choices=("orthographic", "perspective"),
        default="orthographic",
        help="Projection type (default: orthographic)",
    )
    parser.add_argument("--width", type=int, default=1280, help="Image width")
    parser.add_argument("--height", type=int, default=960, help="Image height")
    parser.add_argument(
        "--wireframe-boldness",
        "--line-width",
        dest="wireframe_boldness",
        type=float,
        default=0.35,
        help="Wire width in points",
    )
    parser.add_argument("--wireframe-alpha", type=float, default=0.82)
    parser.add_argument("--surface-alpha", type=float, default=1.0)
    parser.add_argument("--surface-color", help="Use one color for every STEP surface, for example #7b8093")
    parser.add_argument("--lighting", action="store_true", help="Add experimental diffuse/specular lighting")
    parser.add_argument("--curve-samples", type=int, default=32, help="Samples per curved STEP edge")
    parser.add_argument(
        "--surface-mesh-size",
        type=float,
        default=0.0125,
        help="Maximum STEP fill-mesh edge as a fraction of model diagonal",
    )
    parser.add_argument("--verbose", action="store_true", help="Print rendering checkpoints")
    parser.add_argument(
        "--edges-only",
        action="store_true",
        help="Skip Gmsh surface meshing and render sampled B-rep edges only",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace, source: Path) -> None:
    if not source.is_file():
        raise RenderError(f"Input file does not exist: {source}")
    if source.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise RenderError("Input must be .stl, .step, or .stp.")
    if args.distance is not None and args.distance <= 1.05:
        raise RenderError("--distance must be greater than 1.05 model radii.")
    if not 0.0 <= args.margin < 0.45:
        raise RenderError("--margin must be at least 0 and less than 0.45.")
    if not 1.0 <= args.fov < 179.0:
        raise RenderError("--fov must be between 1 and 179 degrees.")
    if args.width < 64 or args.height < 64:
        raise RenderError("--width and --height must each be at least 64 pixels.")
    if args.wireframe_boldness <= 0:
        raise RenderError("--wireframe-boldness must be positive.")
    if not 0.0 <= args.wireframe_alpha <= 1.0:
        raise RenderError("--wireframe-alpha must be between 0 and 1.")
    if not 0.0 <= args.surface_alpha <= 1.0:
        raise RenderError("--surface-alpha must be between 0 and 1.")
    if args.surface_color is not None:
        try:
            from matplotlib.colors import to_rgb

            to_rgb(args.surface_color)
        except ValueError as exc:
            raise RenderError(f"Invalid --surface-color: {args.surface_color}") from exc
    if args.curve_samples < 4:
        raise RenderError("--curve-samples must be at least 4.")
    if not 0.001 <= args.surface_mesh_size <= 0.25:
        raise RenderError("--surface-mesh-size must be between 0.001 and 0.25.")


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve()
    output_dir = (
        args.output_dir
        or source.with_name(f"{source.stem}_cube_vertices")
    ).expanduser().resolve()

    try:
        validate_args(args, source)
        output_dir.mkdir(parents=True, exist_ok=True)

                                                                               
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot              

        if args.verbose:
            print(f"[cube-view] input: {source}", flush=True)
            print(f"[cube-view] output-dir: {output_dir}", flush=True)

        geometry = load_geometry(
            source,
            args.curve_samples,
            args.surface_mesh_size,
            args.verbose,
            args.edges_only,
        )
        directions = cube_vertex_directions()
        distance = args.distance
        if distance is None:
            distance = common_fit_distance(
                geometry.vertices,
                directions,
                args.fov,
                args.width,
                args.height,
                args.margin,
                args.projection,
            )
            print(
                f"Automatic common camera distance: {distance:.6f} model radii "
                f"(margin={args.margin:.1%})"
            )

        for index, direction in enumerate(directions, start=1):
            azimuth, elevation = spherical_angles(direction)
            _, right, up, forward = camera_basis(azimuth, elevation)
            output = output_dir / (
                f"cube_view_{index:02d}_az_{angle_label(azimuth)}_"
                f"el_{angle_label(elevation)}.png"
            )
            if args.verbose:
                print(f"[cube-view] rendering {index:02d}/8: {output.name}", flush=True)
            render_wireframe(
                geometry,
                output,
                azimuth,
                elevation,
                distance,
                args.fov,
                args.width,
                args.height,
                args.wireframe_boldness,
                args.wireframe_alpha,
                args.surface_alpha,
                args.surface_color,
                args.projection,
                False,
                experimental_lighting=args.lighting,
                camera_basis_override=(direction, right, up, forward),
                verbose=args.verbose,
            )
            print(
                f"[{index:02d}/8] {output.name} "
                f"(azimuth={azimuth:.2f}, elevation={elevation:.2f})"
            )
    except RenderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected rendering failure: {exc}", file=sys.stderr)
        return 1

    print(f"Created 8 cube-vertex views in: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
