"""Render CAD views from regular-dodecahedron vertex directions."""

from __future__ import annotations

import argparse
import itertools
import math
import sys
from pathlib import Path

import numpy as np

from render_cad_wireframe import (
    SUPPORTED_EXTENSIONS,
    RenderError,
    camera_basis,
    load_geometry,
    render_wireframe,
)


def dodecahedron_directions() -> list[np.ndarray]:
    """Return the 20 unit vectors pointing to regular dodecahedron vertices."""
    phi = (1.0 + math.sqrt(5.0)) * 0.5
    inverse_phi = 1.0 / phi
    vertices: list[tuple[float, float, float]] = []

                                               
    vertices.extend(itertools.product((-1.0, 1.0), repeat=3))

                                   
    for first_sign, second_sign in itertools.product((-1.0, 1.0), repeat=2):
        vertices.extend(
            (
                (0.0, first_sign * inverse_phi, second_sign * phi),
                (first_sign * inverse_phi, second_sign * phi, 0.0),
                (first_sign * phi, 0.0, second_sign * inverse_phi),
            )
        )

    directions = []
    for vertex in vertices:
        direction = np.asarray(vertex, dtype=float)
        directions.append(direction / np.linalg.norm(direction))
    return directions


def spherical_angles(direction: np.ndarray) -> tuple[float, float]:
    azimuth = math.degrees(math.atan2(direction[1], direction[0]))
    elevation = math.degrees(math.asin(float(direction[2])))
    return azimuth, elevation


def angle_label(value: float) -> str:
    prefix = "p" if value >= 0 else "m"
    return f"{prefix}{abs(value):05.1f}"


def common_fit_distance(
    vertices: np.ndarray,
    directions: list[np.ndarray],
    fov: float,
    width: int,
    height: int,
    margin: float,
    projection: str,
) -> float:
    """Find one camera radius that fits the model from every direction."""
    center = (vertices.min(axis=0) + vertices.max(axis=0)) * 0.5
    centered = vertices - center
    radius = float(np.linalg.norm(centered, axis=1).max())
    if radius <= 0:
        raise RenderError("The model has zero spatial extent.")

    focal_pixels = 0.5 * height / math.tan(math.radians(fov) * 0.5)
    usable_half_width = width * (0.5 - margin)
    usable_half_height = height * (0.5 - margin)
    required_distance = 1.05

    for direction in directions:
        azimuth, elevation = spherical_angles(direction)
        _, right, up, forward = camera_basis(azimuth, elevation)
        camera_x = centered @ right
        camera_y = centered @ up
        depth_offset = centered @ forward
        required_depth = np.maximum(
            focal_pixels * np.abs(camera_x) / usable_half_width,
            focal_pixels * np.abs(camera_y) / usable_half_height,
        )
        if projection == "orthographic":
            view_distance = float(np.max(required_depth / radius))
        else:
            view_distance = float(
                np.max((required_depth - depth_offset) / radius)
            )
        required_distance = max(required_distance, view_distance)

                                                                           
    return required_distance * 1.002


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Render 20 wireframe views of an STL or STEP model from regular "
            "dodecahedron vertex directions."
        )
    )
    parser.add_argument("input", type=Path, help="Input .stl, .step, or .stp model")
    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        help="Output directory (default: <model>_all_angles)",
    )
    parser.add_argument(
        "--distance",
        type=float,
        default=None,
        help="Camera distance in model radii (default: automatically fit all views)",
    )
    parser.add_argument(
        "--margin",
        type=float,
        default=0.05,
        help="Automatic-fit image border as a fraction (default: 0.05)",
    )
    parser.add_argument(
        "--fov",
        type=float,
        default=35.0,
        help="Vertical field of view in degrees (default: 35)",
    )
    parser.add_argument(
        "--projection",
        choices=("orthographic", "perspective"),
        default="orthographic",
        help="Projection type (default: orthographic)",
    )
    parser.add_argument(
        "--width", type=int, default=1280, help="Image width (default: 1280)"
    )
    parser.add_argument(
        "--height", type=int, default=960, help="Image height (default: 960)"
    )
    parser.add_argument(
        "--wireframe-boldness",
        "--line-width",
        dest="wireframe_boldness",
        type=float,
        default=0.35,
        help="Wire width in points (default: 0.35)",
    )
    parser.add_argument(
        "--wireframe-alpha",
        type=float,
        default=0.82,
        help="Front wire opacity from 0 to 1 (default: 0.82)",
    )
    parser.add_argument(
        "--surface-alpha",
        type=float,
        default=1.0,
        help="STEP surface opacity from 0 to 1 (default: 1)",
    )
    parser.add_argument(
        "--surface-color",
        help="Use one color for every STEP surface, for example #7b8093",
    )
    parser.add_argument(
        "--lighting",
        action="store_true",
        help="Add experimental diffuse illumination and specular reflection",
    )
    parser.add_argument(
        "--curve-samples",
        type=int,
        default=32,
        help="Samples per curved STEP edge (default: 32)",
    )
    parser.add_argument(
        "--surface-mesh-size",
        type=float,
        default=0.0125,
        help=(
            "Maximum STEP fill-mesh edge as a fraction of model diagonal "
            "(default: 0.0125; smaller is finer)"
        ),
    )
    parser.add_argument("--verbose", action="store_true", help="Print rendering checkpoints")
    parser.add_argument(
        "--edges-only",
        action="store_true",
        help="Skip Gmsh surface meshing and render sampled B-rep edges only",
    )
    return parser.parse_args()


def validate_args(args: argparse.Namespace, source: Path) -> None:
    if not source.is_file():
        raise RenderError(f"Input file does not exist: {source}")
    if source.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise RenderError("Input must be .stl, .step, or .stp.")
    if args.distance is not None and args.distance <= 1.05:
        raise RenderError("--distance must be greater than 1.05 model radii.")
    if not 0.0 <= args.margin < 0.45:
        raise RenderError("--margin must be at least 0 and less than 0.45.")
    if not 1.0 <= args.fov < 179.0:
        raise RenderError("--fov must be between 1 and 179 degrees.")
    if args.width < 64 or args.height < 64:
        raise RenderError("--width and --height must each be at least 64 pixels.")
    if args.wireframe_boldness <= 0:
        raise RenderError("--wireframe-boldness must be positive.")
    if not 0.0 <= args.wireframe_alpha <= 1.0:
        raise RenderError("--wireframe-alpha must be between 0 and 1.")
    if not 0.0 <= args.surface_alpha <= 1.0:
        raise RenderError("--surface-alpha must be between 0 and 1.")
    if args.surface_color is not None:
        try:
            from matplotlib.colors import to_rgb

            to_rgb(args.surface_color)
        except ValueError as exc:
            raise RenderError(f"Invalid --surface-color: {args.surface_color}") from exc
    if args.curve_samples < 4:
        raise RenderError("--curve-samples must be at least 4.")
    if not 0.001 <= args.surface_mesh_size <= 0.25:
        raise RenderError("--surface-mesh-size must be between 0.001 and 0.25.")


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve()
    output_dir = (
        args.output_dir
        or source.with_name(f"{source.stem}_all_angles")
    ).expanduser().resolve()

    try:
        validate_args(args, source)
        output_dir.mkdir(parents=True, exist_ok=True)

                                                                               
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot              

        if args.verbose:
            print(f"[20-view] input: {source}", flush=True)
            print(f"[20-view] output-dir: {output_dir}", flush=True)
        geometry = load_geometry(
            source,
            args.curve_samples,
            args.surface_mesh_size,
            args.verbose,
            args.edges_only,
        )
        directions = dodecahedron_directions()
        distance = args.distance
        if distance is None:
            distance = common_fit_distance(
                geometry.vertices,
                directions,
                args.fov,
                args.width,
                args.height,
                args.margin,
                args.projection,
            )
            print(
                f"Automatic common camera distance: {distance:.6f} model radii "
                f"(margin={args.margin:.1%})"
            )
        for index, direction in enumerate(directions, start=1):
            azimuth, elevation = spherical_angles(direction)
            output = output_dir / (
                f"view_{index:02d}_az_{angle_label(azimuth)}_"
                f"el_{angle_label(elevation)}.png"
            )
            if args.verbose:
                print(f"[20-view] rendering {index:02d}/20: {output.name}", flush=True)
            render_wireframe(
                geometry,
                output,
                azimuth,
                elevation,
                distance,
                args.fov,
                args.width,
                args.height,
                args.wireframe_boldness,
                args.wireframe_alpha,
                args.surface_alpha,
                args.surface_color,
                args.projection,
                False,
                experimental_lighting=args.lighting,
                verbose=args.verbose,
            )
            print(
                f"[{index:02d}/20] {output.name} "
                f"(azimuth={azimuth:.2f}, elevation={elevation:.2f})"
            )
    except RenderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected rendering failure: {exc}", file=sys.stderr)
        return 1

    print(f"Created 20 views in: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
