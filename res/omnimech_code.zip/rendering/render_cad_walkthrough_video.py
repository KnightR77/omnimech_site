"""Render a lit STEP walkthrough video with configurable camera paths."""

from __future__ import annotations

import argparse
import math
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

from render_cad_wireframe_all_angle import dodecahedron_directions, spherical_angles
from render_cad_wireframe import (
    RenderError,
    camera_basis,
    load_geometry,
    render_wireframe,
)


PLAIN_COLOR = "#7b8093"


def camera_basis_from_direction(
    camera_direction: np.ndarray,
    previous_right: np.ndarray | None = None,
) -> tuple[np.ndarray, ...]:
    """Build a stable camera basis for a direction on the viewing sphere.

    When previous_right is supplied, the right vector is parallel-transported
    onto the new camera plane. This keeps the roll smooth while sliding across
    dodecahedron vertices instead of letting every frame independently snap to
    world-up.
    """
    camera_direction = np.asarray(camera_direction, dtype=float)
    norm = np.linalg.norm(camera_direction)
    if norm <= 1e-12:
        raise RenderError("Encountered a zero camera direction.")
    camera_direction = camera_direction / norm
    forward = -camera_direction

    right = None
    if previous_right is not None:
        candidate = previous_right - np.dot(previous_right, forward) * forward
        candidate_norm = np.linalg.norm(candidate)
        if candidate_norm > 1e-8:
            right = candidate / candidate_norm

    if right is None:
        world_up = np.asarray([0.0, 0.0, 1.0], dtype=float)
        right = np.cross(forward, world_up)
        if np.linalg.norm(right) < 1e-8:
            world_up = np.asarray([0.0, 1.0, 0.0], dtype=float)
            right = np.cross(forward, world_up)
        right /= np.linalg.norm(right)

    up = np.cross(right, forward)
    up /= np.linalg.norm(up)
    return camera_direction, right, up, forward


def vertical_camera_basis(angle: float) -> tuple[np.ndarray, ...]:
    """Continuous camera basis for a true orbit around the world Y axis."""
    radians = math.radians(angle)
    camera_direction = np.asarray(
        [math.cos(radians), 0.0, math.sin(radians)], dtype=float
    )
    forward = -camera_direction
    right = np.asarray([0.0, 1.0, 0.0], dtype=float)
    up = np.cross(right, forward)
    up /= np.linalg.norm(up)
    return camera_direction, right, up, forward


def rotation_views(
    step: float,
) -> list[tuple[str, float, float, tuple[np.ndarray, ...]]]:
    angles = np.arange(0.0, 360.0, step, dtype=float)
    horizontal = [
        ("horizontal", float(angle), 0.0, camera_basis(float(angle), 0.0))
        for angle in angles
    ]
    vertical = [
        ("vertical", 0.0, float(angle), vertical_camera_basis(float(angle)))
        for angle in angles
    ]
    return horizontal + vertical


def slerp(start: np.ndarray, end: np.ndarray, t: float) -> np.ndarray:
    """Spherical interpolation between two unit vectors."""
    start = start / np.linalg.norm(start)
    end = end / np.linalg.norm(end)
    dot = float(np.clip(np.dot(start, end), -1.0, 1.0))
    if dot > 0.999999:
        blended = (1.0 - t) * start + t * end
        return blended / np.linalg.norm(blended)
    angle = math.acos(dot)
    sin_angle = math.sin(angle)
    return (
        math.sin((1.0 - t) * angle) / sin_angle * start
        + math.sin(t * angle) / sin_angle * end
    )


def dodecahedron_adjacency(directions: list[np.ndarray]) -> list[list[int]]:
    """Return nearest-neighbor graph edges for regular dodecahedron vertices."""
    count = len(directions)
    distances = np.full((count, count), np.inf, dtype=float)
    for i in range(count):
        for j in range(i + 1, count):
            distance = float(np.linalg.norm(directions[i] - directions[j]))
            distances[i, j] = distances[j, i] = distance
    edge_length = float(np.min(distances))
    tolerance = edge_length * 1e-6
    return [
        sorted(
            (
                j
                for j in range(count)
                if i != j and abs(distances[i, j] - edge_length) <= tolerance
            ),
            key=lambda j: j,
        )
        for i in range(count)
    ]


def dodecahedron_vertex_route(directions: list[np.ndarray], closed: bool) -> list[int]:
    """Find a repeat-free route over all dodecahedron vertices.

    The route follows actual dodecahedron graph edges where possible, then
    optionally closes back to the first vertex. A deterministic backtracking
    search is tiny here (20 vertices, degree 3) and gives a much nicer camera
    path than jumping through the raw coordinate-list order.
    """
    adjacency = dodecahedron_adjacency(directions)
    count = len(directions)
    start = 0
    route = [start]
    visited = {start}

    def search(current: int) -> bool:
        if len(route) == count:
            return (not closed) or (start in adjacency[current])
        candidates = sorted(
            (node for node in adjacency[current] if node not in visited),
            key=lambda node: sum(1 for next_node in adjacency[node] if next_node not in visited),
        )
        for node in candidates:
            visited.add(node)
            route.append(node)
            if search(node):
                return True
            route.pop()
            visited.remove(node)
        return False

    if search(start):
        return route

                                                                              
                                                             
    remaining = set(range(count))
    route = [start]
    remaining.remove(start)
    while remaining:
        current = route[-1]
        next_node = min(
            remaining,
            key=lambda node: float(np.linalg.norm(directions[current] - directions[node])),
        )
        route.append(next_node)
        remaining.remove(next_node)
    return route


def dodecahedron_views(
    step: float,
    closed: bool = True,
) -> list[tuple[str, float, float, tuple[np.ndarray, ...]]]:
    directions = dodecahedron_directions()
    route = dodecahedron_vertex_route(directions, closed)
    path = [directions[index] for index in route]
    if closed:
        path.append(path[0])

    frames: list[np.ndarray] = []
    for segment_index in range(len(path) - 1):
        start = path[segment_index]
        end = path[segment_index + 1]
        angle = math.degrees(
            math.acos(float(np.clip(np.dot(start, end), -1.0, 1.0)))
        )
        frame_count = max(1, int(math.ceil(angle / step)))
        for frame_index in range(frame_count):
            frames.append(slerp(start, end, frame_index / frame_count))
    if not closed:
        frames.append(path[-1])

    views: list[tuple[str, float, float, tuple[np.ndarray, ...]]] = []
    previous_right = None
    for direction in frames:
        basis = camera_basis_from_direction(direction, previous_right)
        previous_right = basis[1]
        azimuth, elevation = spherical_angles(direction)
        views.append(("dodecahedron", azimuth, elevation, basis))
    return views


def common_fit_distance_for_views(
    vertices: np.ndarray,
    views: list[tuple[str, float, float, tuple[np.ndarray, ...]]],
    fov: float,
    width: int,
    height: int,
    margin: float,
    projection: str,
) -> float:
    center = (vertices.min(axis=0) + vertices.max(axis=0)) * 0.5
    centered = vertices - center
    radius = float(np.linalg.norm(centered, axis=1).max())
    if radius <= 0:
        raise RenderError("The model has zero spatial extent.")
    focal_pixels = 0.5 * height / math.tan(math.radians(fov) * 0.5)
    usable_half_width = width * (0.5 - margin)
    usable_half_height = height * (0.5 - margin)
    required_distance = 1.05
    for _, _, _, basis in views:
        _, right, up, forward = basis
        camera_x = centered @ right
        camera_y = centered @ up
        depth_offset = centered @ forward
        required_depth = np.maximum(
            focal_pixels * np.abs(camera_x) / usable_half_width,
            focal_pixels * np.abs(camera_y) / usable_half_height,
        )
        if projection == "orthographic":
            view_distance = float(np.max(required_depth / radius))
        else:
            view_distance = float(np.max((required_depth - depth_offset) / radius))
        required_distance = max(required_distance, view_distance)
    return required_distance * 1.002


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create a lit STEP walkthrough MP4 using either horizontal/vertical "
            "axis rotations or a smooth dodecahedron-vertex spherical route."
        )
    )
    parser.add_argument("input", type=Path, help="Input .step or .stp model")
    parser.add_argument("-o", "--output", type=Path, help="Output MP4 path")
    parser.add_argument(
        "--rotation-step",
        type=float,
        default=1.0,
        help=(
            "Approximate degrees per frame. For axis mode this is exact; for "
            "dodecahedron mode each spherical segment is divided to stay at or "
            "below this angle (default: 1)."
        ),
    )
    parser.add_argument(
        "--path-mode",
        choices=("axis", "dodecahedron"),
        default="axis",
        help=(
            "Video camera path: axis rotations, or a "
            "smooth route through dodecahedron vertices (default: axis)."
        ),
    )
    parser.add_argument(
        "--no-dodecahedron-loop",
        action="store_true",
        help="In dodecahedron mode, do not close the route back to the first vertex.",
    )
    parser.add_argument("--fps", type=float, default=15.0, help="Frames per second (default: 15)")
    parser.add_argument("--width", type=int, default=1280, help="Video width (default: 1280)")
    parser.add_argument("--height", type=int, default=960, help="Video height (default: 960)")
    parser.add_argument("--margin", type=float, default=0.05, help="Image border fraction (default: 0.05)")
    parser.add_argument("--fov", type=float, default=35.0)
    parser.add_argument(
        "--projection",
        choices=("orthographic", "perspective"),
        default="orthographic",
    )
    parser.add_argument("--surface-color", default=PLAIN_COLOR)
    parser.add_argument("--surface-alpha", type=float, default=1.0)
    parser.add_argument("--wireframe-boldness", type=float, default=0.35)
    parser.add_argument("--wireframe-alpha", type=float, default=0.82)
    parser.add_argument("--curve-samples", type=int, default=32)
    parser.add_argument("--surface-mesh-size", type=float, default=0.0125)
    parser.add_argument(
        "--no-progress",
        action="store_true",
        help="Suppress target-frame and per-frame progress output",
    )
    parser.add_argument("--verbose", action="store_true", help="Print rendering checkpoints")
    parser.add_argument(
        "--edges-only",
        action="store_true",
        help="Skip Gmsh surface meshing and render sampled B-rep edges only",
    )
    return parser.parse_args()


def validate(args: argparse.Namespace, source: Path) -> None:
    if not source.is_file():
        raise RenderError(f"Input file does not exist: {source}")
    if source.suffix.lower() not in {".step", ".stp"}:
        raise RenderError("Walkthrough video requires STEP or STP input.")
    if not 0.0 < args.rotation_step <= 360.0:
        raise RenderError("--rotation-step must be greater than 0 and at most 360.")
    if args.fps <= 0:
        raise RenderError("--fps must be positive.")
    if args.width < 64 or args.height < 64:
        raise RenderError("--width and --height must each be at least 64.")
    if not 0.0 <= args.margin < 0.45:
        raise RenderError("--margin must be at least 0 and less than 0.45.")
    if not 1.0 <= args.fov < 179.0:
        raise RenderError("--fov must be between 1 and 179 degrees.")
    if not 0.0 <= args.surface_alpha <= 1.0:
        raise RenderError("--surface-alpha must be between 0 and 1.")
    if not 0.0 <= args.wireframe_alpha <= 1.0:
        raise RenderError("--wireframe-alpha must be between 0 and 1.")
    if args.wireframe_boldness <= 0:
        raise RenderError("--wireframe-boldness must be positive.")
    if args.curve_samples < 4:
        raise RenderError("--curve-samples must be at least 4.")
    if not 0.001 <= args.surface_mesh_size <= 0.25:
        raise RenderError("--surface-mesh-size must be between 0.001 and 0.25.")


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve()
    output = (
        args.output or source.with_name(f"{source.stem}_walkthrough.mp4")
    ).expanduser().resolve()

    writer = None
    try:
        validate(args, source)
        import cv2
        import matplotlib
        from matplotlib.colors import to_rgb

        to_rgb(args.surface_color)
        matplotlib.use("Agg")
        import matplotlib.pyplot              

        if args.path_mode == "dodecahedron":
            views = dodecahedron_views(
                args.rotation_step,
                closed=not args.no_dodecahedron_loop,
            )
        else:
            views = rotation_views(args.rotation_step)
        total_frames = len(views)
        if not args.no_progress:
            if args.path_mode == "dodecahedron":
                print(
                    f"[{source.stem}] Target frames: {total_frames} "
                    f"(smooth dodecahedron spherical route)"
                )
            else:
                frames_per_rotation = len(views) // 2
                print(
                    f"[{source.stem}] Target frames: {total_frames} "
                    f"({frames_per_rotation} horizontal + {frames_per_rotation} vertical)"
                )
        if args.verbose:
            print(f"[video] input: {source}", flush=True)
            print(f"[video] output: {output}", flush=True)
        geometry = load_geometry(
            source,
            args.curve_samples,
            args.surface_mesh_size,
            args.verbose,
            args.edges_only,
        )
        distance = common_fit_distance_for_views(
            geometry.vertices,
            views,
            args.fov,
            args.width,
            args.height,
            args.margin,
            args.projection,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        writer = cv2.VideoWriter(
            str(output),
            cv2.VideoWriter_fourcc(*"mp4v"),
            args.fps,
            (args.width, args.height),
        )
        if not writer.isOpened():
            raise RenderError("OpenCV could not initialize the MP4 video writer.")

        with tempfile.TemporaryDirectory(prefix="cad_video_") as temporary:
            frame_path = Path(temporary) / "frame.png"
            total = len(views)
            render_started = time.perf_counter()
            for index, (phase, azimuth, elevation, basis) in enumerate(views, start=1):
                render_wireframe(
                    geometry,
                    frame_path,
                    azimuth,
                    elevation,
                    distance,
                    args.fov,
                    args.width,
                    args.height,
                    args.wireframe_boldness,
                    args.wireframe_alpha,
                    args.surface_alpha,
                    args.surface_color,
                    args.projection,
                    False,
                    experimental_lighting=True,
                    camera_basis_override=basis,
                    verbose=args.verbose and index == 1,
                )
                frame = cv2.imread(str(frame_path), cv2.IMREAD_COLOR)
                if frame is None or frame.shape[1] != args.width or frame.shape[0] != args.height:
                    raise RenderError(f"Could not read rendered frame {index}.")
                writer.write(frame)
                elapsed = time.perf_counter() - render_started
                eta = (elapsed / index) * (total - index)
                if not args.no_progress:
                    print(
                        f"\r[{source.stem}] [{index}/{total}] {index / total:6.2%} | "
                        f"{phase:10s} | "
                        f"elapsed {elapsed:7.1f}s | ETA {eta:7.1f}s",
                        end="",
                        flush=True,
                    )
            if not args.no_progress:
                print()
        writer.release()
        writer = None
        if not output.is_file() or output.stat().st_size == 0:
            raise RenderError("Video writer returned without creating an MP4 file.")
    except (RenderError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected video rendering failure: {exc}", file=sys.stderr)
        return 1
    finally:
        if writer is not None:
            writer.release()

    duration = len(views) / args.fps
    print(
        f"Created walkthrough: {output} "
        f"({duration:.2f}s at {args.fps:g} FPS)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
