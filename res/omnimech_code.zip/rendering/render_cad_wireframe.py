"""Render a perspective wireframe projection from a mesh or STEP model.

Mesh files are loaded with trimesh. STEP wireframes use exact B-rep topology
from Gmsh's OpenCASCADE kernel. A hidden-edge display mesh is used only to color
each surface; its triangle edges are never drawn.
"""

from __future__ import annotations

import argparse
import math
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np


SUPPORTED_EXTENSIONS = {".glb", ".gltf", ".obj", ".stl", ".step", ".stp"}


class RenderError(RuntimeError):
    pass


@dataclass
class WireGeometry:
    vertices: np.ndarray
    edges: np.ndarray
    surface_faces: np.ndarray | None = None
    surface_ids: np.ndarray | None = None


def load_geometry(
    source: Path,
    curve_samples: int,
    surface_mesh_size: float,
    verbose: bool = False,
    edges_only: bool = False,
) -> WireGeometry:
    if verbose:
        print(f"[wireframe] loading geometry: {source}", flush=True)
    try:
        import trimesh
    except ImportError as exc:
        raise RenderError("Install the mesh loader with: python -m pip install trimesh") from exc

    if source.suffix.lower() in {".step", ".stp"}:
        return load_step_brep_edges(
            source, curve_samples, surface_mesh_size, verbose, edges_only
        )

    try:
        if verbose:
            print("[wireframe] trimesh.load started", flush=True)
        loaded = trimesh.load(source, force="mesh", process=False)
        if verbose:
            print("[wireframe] trimesh.load finished", flush=True)
        if isinstance(loaded, trimesh.Scene):
            meshes = [geometry for geometry in loaded.geometry.values()]
            if not meshes:
                raise RenderError("The model contains no mesh geometry.")
            loaded = trimesh.util.concatenate(meshes)
        if not isinstance(loaded, trimesh.Trimesh) or len(loaded.faces) == 0:
            raise RenderError("The model contains no triangular faces.")
        faces = np.asarray(loaded.faces, dtype=int)
        return WireGeometry(
            vertices=np.asarray(loaded.vertices, dtype=float),
            edges=np.asarray(loaded.edges_unique, dtype=int),
            surface_faces=faces,
            surface_ids=np.zeros(len(faces), dtype=int),
        )
    except RenderError:
        raise
    except Exception as exc:
        raise RenderError(f"Could not load model geometry: {exc}") from exc


def load_step_brep_edges(
    source: Path,
    curve_samples: int,
    surface_mesh_size: float,
    verbose: bool = False,
    edges_only: bool = False,
) -> WireGeometry:
    """Sample exact STEP B-rep curves without generating surface triangles."""
    try:
        import gmsh                
    except ImportError as exc:
        raise RenderError(
            "STEP loading requires Gmsh. Install it with: python -m pip install gmsh"
        ) from exc

    initialized = False
    try:
        started_at = time.perf_counter()
        if verbose:
            print("[wireframe] gmsh.initialize started", flush=True)
        gmsh.initialize()
        initialized = True
        gmsh.option.setNumber("General.Terminal", 0)
        if verbose:
            print(f"[wireframe] gmsh.open started: {source}", flush=True)
        gmsh.open(str(source))
        if verbose:
            print(
                f"[wireframe] gmsh.open finished in {time.perf_counter() - started_at:.1f}s",
                flush=True,
            )

        def is_smooth_seam(curve_tag: int, start: float, stop: float) -> bool:
            """Return True for tangent/periodic topology edges, not sharp edges."""
            try:
                adjacent_surfaces, _ = gmsh.model.getAdjacencies(1, curve_tag)
                if len(adjacent_surfaces) != 2:
                    return False
                for parameter in np.linspace(start, stop, 3):
                    point = np.asarray(
                        gmsh.model.getValue(1, curve_tag, [float(parameter)]),
                        dtype=float,
                    )
                    normals = []
                    for surface_tag in adjacent_surfaces:
                        surface_parameters = gmsh.model.getParametrization(
                            2, int(surface_tag), point.tolist()
                        )
                        normal = np.asarray(
                            gmsh.model.getNormal(
                                int(surface_tag), surface_parameters
                            ),
                            dtype=float,
                        )
                        normal_length = np.linalg.norm(normal)
                        if normal_length <= 1e-12:
                            return False
                        normals.append(normal / normal_length)
                    if abs(float(np.dot(normals[0], normals[1]))) < 0.999:
                        return False
                return True
            except Exception:
                return False

        vertex_blocks: list[np.ndarray] = []
        edge_blocks: list[np.ndarray] = []
        vertex_offset = 0
        curve_entities = gmsh.model.getEntities(dim=1)
        if verbose:
            print(f"[wireframe] sampling {len(curve_entities)} B-rep curve(s)", flush=True)
        for curve_index, (_, tag) in enumerate(curve_entities, start=1):
            if verbose and (curve_index == 1 or curve_index % 100 == 0):
                print(
                    f"[wireframe] curve {curve_index}/{len(curve_entities)}",
                    flush=True,
                )
            lower, upper = gmsh.model.getParametrizationBounds(1, tag)
            start = float(np.asarray(lower).flat[0])
            stop = float(np.asarray(upper).flat[0])
            if is_smooth_seam(tag, start, stop):
                continue
            curve_type = gmsh.model.getType(1, tag).lower()
                                                                         
                                                                            
            count = max(8, curve_samples // 4) if curve_type == "line" else curve_samples
            parameters = np.linspace(start, stop, count)
            points = np.asarray(
                gmsh.model.getValue(1, tag, parameters.tolist()), dtype=float
            ).reshape((-1, 3))
            if len(points) < 2 or not np.all(np.isfinite(points)):
                continue
            local_edges = np.column_stack(
                (
                    np.arange(vertex_offset, vertex_offset + len(points) - 1),
                    np.arange(vertex_offset + 1, vertex_offset + len(points)),
                )
            )
            vertex_blocks.append(points)
            edge_blocks.append(local_edges)
            vertex_offset += len(points)

        if not vertex_blocks:
            raise RenderError("Gmsh found no B-rep curves in the STEP model.")

        wire_vertices = np.vstack(vertex_blocks)
        if edges_only:
            geometry = WireGeometry(
                vertices=wire_vertices,
                edges=np.vstack(edge_blocks).astype(int),
            )
            if verbose:
                print(
                    "[wireframe] edges-only geometry ready: "
                    f"{len(geometry.vertices)} vertices, {len(geometry.edges)} edges",
                    flush=True,
                )
            return geometry

        bounds = gmsh.model.getBoundingBox(-1, -1)
        diagonal = float(
            np.linalg.norm(np.asarray(bounds[3:6]) - np.asarray(bounds[0:3]))
        )
        gmsh.option.setNumber("Mesh.MeshSizeMax", diagonal * surface_mesh_size)
        gmsh.option.setNumber("Mesh.MeshSizeMin", diagonal * surface_mesh_size * 0.2)
        gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 32)
        gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 1)
        if verbose:
            print(
                "[wireframe] gmsh surface mesh started "
                f"(diagonal={diagonal:.6g}, mesh_size={diagonal * surface_mesh_size:.6g})",
                flush=True,
            )
        gmsh.model.mesh.generate(2)
        if verbose:
            print("[wireframe] gmsh surface mesh finished", flush=True)
        node_tags, coordinates, _ = gmsh.model.mesh.getNodes()
        surface_vertices = np.asarray(coordinates, dtype=float).reshape((-1, 3))
        surface_offset = len(wire_vertices)
        tag_to_index = {
            int(tag): surface_offset + index for index, tag in enumerate(node_tags)
        }
        surface_faces: list[list[int]] = []
        surface_ids: list[int] = []

        surface_entities = gmsh.model.getEntities(dim=2)
        if verbose:
            print(f"[wireframe] collecting mesh elements from {len(surface_entities)} surface(s)", flush=True)
        for surface_index, (_, surface_tag) in enumerate(surface_entities):
            element_types, _, element_nodes = gmsh.model.mesh.getElements(
                dim=2, tag=surface_tag
            )
            for element_type, flattened_nodes in zip(element_types, element_nodes):
                name, dimension, _, nodes_per_element, _, primary_nodes = (
                    gmsh.model.mesh.getElementProperties(element_type)
                )
                if dimension != 2:
                    continue
                nodes = np.asarray(flattened_nodes, dtype=np.int64).reshape(
                    (-1, nodes_per_element)
                )[:, :primary_nodes]
                if name.lower().startswith("triangle") and primary_nodes >= 3:
                    for row in nodes:
                        surface_faces.append(
                            [tag_to_index[int(tag)] for tag in row[:3]]
                        )
                        surface_ids.append(surface_index)
                elif name.lower().startswith("quadrilateral") and primary_nodes >= 4:
                    for row in nodes:
                        a, b, c, d = (tag_to_index[int(tag)] for tag in row[:4])
                        surface_faces.extend(([a, b, c], [a, c, d]))
                        surface_ids.extend((surface_index, surface_index))

        geometry = WireGeometry(
            vertices=np.vstack((wire_vertices, surface_vertices)),
            edges=np.vstack(edge_blocks).astype(int),
            surface_faces=np.asarray(surface_faces, dtype=int),
            surface_ids=np.asarray(surface_ids, dtype=int),
        )
        if verbose:
            print(
                "[wireframe] geometry ready: "
                f"{len(geometry.vertices)} vertices, {len(geometry.edges)} edges, "
                f"{0 if geometry.surface_faces is None else len(geometry.surface_faces)} faces",
                flush=True,
            )
        return geometry
    except RenderError:
        raise
    except Exception as exc:
        raise RenderError(f"Could not read STEP B-rep curves with Gmsh: {exc}") from exc
    finally:
        if initialized:
            if verbose:
                print("[wireframe] gmsh.finalize", flush=True)
            gmsh.finalize()


def camera_basis(azimuth_deg: float, elevation_deg: float) -> tuple[np.ndarray, ...]:
    azimuth = math.radians(azimuth_deg)
    elevation = math.radians(elevation_deg)
    camera_direction = np.array(
        [
            math.cos(elevation) * math.cos(azimuth),
            math.cos(elevation) * math.sin(azimuth),
            math.sin(elevation),
        ],
        dtype=float,
    )
    forward = -camera_direction
    world_up = np.array([0.0, 0.0, 1.0])
    right = np.cross(forward, world_up)
    if np.linalg.norm(right) < 1e-8:
        world_up = np.array([0.0, 1.0, 0.0])
        right = np.cross(forward, world_up)
    right /= np.linalg.norm(right)
    up = np.cross(right, forward)
    up /= np.linalg.norm(up)
    return camera_direction, right, up, forward


def project_vertices(
    vertices: np.ndarray,
    azimuth: float,
    elevation: float,
    distance: float,
    fov: float,
    width: int,
    height: int,
    projection: str,
    camera_basis_override: tuple[np.ndarray, ...] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    bounds_center = (vertices.min(axis=0) + vertices.max(axis=0)) * 0.5
    centered = vertices - bounds_center
    radius = float(np.linalg.norm(centered, axis=1).max())
    if radius <= 0:
        raise RenderError("The model has zero spatial extent.")

    camera_direction, right, up, forward = (
        camera_basis_override
        if camera_basis_override is not None
        else camera_basis(azimuth, elevation)
    )
    camera_position = bounds_center + camera_direction * distance * radius
    relative = vertices - camera_position
    camera_x = relative @ right
    camera_y = relative @ up
    camera_z = relative @ forward
    if np.any(camera_z <= 0):
        raise RenderError("Camera intersects the model; increase --distance.")

    focal_pixels = 0.5 * height / math.tan(math.radians(fov) * 0.5)
    if projection == "orthographic":
        projected_x = width * 0.5 + focal_pixels * camera_x / (distance * radius)
        projected_y = height * 0.5 - focal_pixels * camera_y / (distance * radius)
    else:
        projected_x = width * 0.5 + focal_pixels * camera_x / camera_z
        projected_y = height * 0.5 - focal_pixels * camera_y / camera_z
    projected = np.column_stack(
        (projected_x, projected_y)
    )
    return projected, camera_z


def render_wireframe(
    geometry: WireGeometry,
    output: Path,
    azimuth: float,
    elevation: float,
    distance: float,
    fov: float,
    width: int,
    height: int,
    line_width: float,
    wireframe_alpha: float,
    surface_alpha: float,
    surface_color: str | None,
    projection: str,
    show: bool,
    experimental_lighting: bool = False,
    camera_basis_override: tuple[np.ndarray, ...] | None = None,
    verbose: bool = False,
) -> None:
    import matplotlib

    if not show:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection

    if verbose:
        print(f"[wireframe] projecting {len(geometry.vertices)} vertices", flush=True)
    vertices = geometry.vertices
    projected, depth = project_vertices(
        vertices,
        azimuth,
        elevation,
        distance,
        fov,
        width,
        height,
        projection,
        camera_basis_override,
    )
    edges = geometry.edges
    source_segments = projected[edges]
    source_depths = depth[edges]

                                                                           
                                                                             
    subdivisions = 8
    starts = np.arange(subdivisions, dtype=float) / subdivisions
    stops = np.arange(1, subdivisions + 1, dtype=float) / subdivisions
    segment_starts = (
        source_segments[:, None, 0, :] * (1.0 - starts[None, :, None])
        + source_segments[:, None, 1, :] * starts[None, :, None]
    )
    segment_stops = (
        source_segments[:, None, 0, :] * (1.0 - stops[None, :, None])
        + source_segments[:, None, 1, :] * stops[None, :, None]
    )
    segments = np.stack((segment_starts, segment_stops), axis=2).reshape((-1, 2, 2))
    depth_starts = (
        source_depths[:, None, 0] * (1.0 - starts[None, :])
        + source_depths[:, None, 1] * starts[None, :]
    )
    depth_stops = (
        source_depths[:, None, 0] * (1.0 - stops[None, :])
        + source_depths[:, None, 1] * stops[None, :]
    )
    segment_depths = np.stack((depth_starts, depth_stops), axis=2).reshape((-1, 2))
    edge_depth = segment_depths.mean(axis=1)

    dpi = 100
    figure = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi)
    axes = figure.add_axes([0, 0, 1, 1])
    axes.set_facecolor("white")
    surface_depth = None
    if (
        geometry.surface_faces is not None
        and geometry.surface_ids is not None
        and len(geometry.surface_faces) > 0
        and surface_alpha > 0
    ):
        if verbose:
            print(
                f"[wireframe] rasterizing {len(geometry.surface_faces)} surface face(s)",
                flush=True,
            )
        try:
            import cv2
        except ImportError as exc:
            raise RenderError(
                "Colored STEP surfaces require OpenCV: python -m pip install opencv-python"
            ) from exc

        faces = geometry.surface_faces
        face_depth = depth[faces].mean(axis=1)
        face_order = np.argsort(face_depth)[::-1]
        if surface_color is not None:
            from matplotlib.colors import to_rgb

            rgb = np.asarray(to_rgb(surface_color), dtype=float)
            face_colors = np.tile(
                np.asarray(rgb * 255, dtype=np.uint8),
                (len(geometry.surface_ids), 1),
            )
        else:
            palette = plt.get_cmap("tab20")
            face_colors = np.asarray(
                palette(geometry.surface_ids % 20)[:, :3] * 255,
                dtype=np.uint8,
            )
        if experimental_lighting:
            face_vertices = vertices[faces]
            normals = np.cross(
                face_vertices[:, 1] - face_vertices[:, 0],
                face_vertices[:, 2] - face_vertices[:, 0],
            )
            normal_lengths = np.linalg.norm(normals, axis=1)
            valid_normals = normal_lengths > 1e-12
            normals[valid_normals] /= normal_lengths[valid_normals, None]
            camera_direction, right, up, _ = (
                camera_basis_override
                if camera_basis_override is not None
                else camera_basis(azimuth, elevation)
            )
            light_direction = camera_direction - 0.35 * right + 0.55 * up
            light_direction /= np.linalg.norm(light_direction)
            half_vector = light_direction + camera_direction
            half_vector /= np.linalg.norm(half_vector)
            diffuse = np.abs(normals @ light_direction)
            specular = np.power(np.abs(normals @ half_vector), 28.0)
            illumination = 0.48 + 0.52 * diffuse
            lit_colors = face_colors.astype(float) * illumination[:, None]
            lit_colors += 255.0 * (0.16 * specular[:, None])
            face_colors = np.asarray(np.clip(lit_colors, 0, 255), dtype=np.uint8)
        surface_rgb = np.full((height, width, 3), 255, dtype=np.uint8)
        surface_mask = np.zeros((height, width), dtype=np.uint8)
        surface_depth = np.full((height, width), np.inf, dtype=np.float32)
        for face_index in face_order:
            polygon = np.rint(projected[faces[face_index]]).astype(np.int32)
            color = tuple(int(value) for value in face_colors[face_index])
            cv2.fillConvexPoly(surface_rgb, polygon, color, lineType=cv2.LINE_8)
            cv2.fillConvexPoly(surface_mask, polygon, 255, lineType=cv2.LINE_8)
            cv2.fillConvexPoly(
                surface_depth,
                polygon,
                float(face_depth[face_index]),
                lineType=cv2.LINE_8,
            )
        if surface_alpha < 1.0:
            covered = surface_mask.astype(bool)
            surface_rgb[covered] = np.rint(
                surface_rgb[covered] * surface_alpha
                + 255.0 * (1.0 - surface_alpha)
            ).astype(np.uint8)
        axes.imshow(surface_rgb, origin="upper", extent=(0, width, height, 0))

    front_edges = np.ones(len(segments), dtype=bool)
    if surface_depth is not None:
        if verbose:
            print(f"[wireframe] classifying {len(segments)} display segment(s)", flush=True)
                                                                           
                                                                      
        sample_t = np.asarray((0.25, 0.5, 0.75))
        sample_points = (
            segments[:, None, 0, :] * (1.0 - sample_t[None, :, None])
            + segments[:, None, 1, :] * sample_t[None, :, None]
        )
        sample_depth = (
            segment_depths[:, None, 0] * (1.0 - sample_t[None, :])
            + segment_depths[:, None, 1] * sample_t[None, :]
        )
        pixel_x = np.clip(
            np.rint(sample_points[:, :, 0]).astype(int), 0, width - 1
        )
        pixel_y = np.clip(
            np.rint(sample_points[:, :, 1]).astype(int), 0, height - 1
        )
        front_depth = surface_depth[pixel_y, pixel_x]
                                                                              
                                                                              
                                                                         
        depth_tolerance = max(float(np.ptp(depth)) * 0.015, 1e-9)
        front_samples = np.isinf(front_depth) | (
            sample_depth <= front_depth + depth_tolerance
        )
        front_edges = np.count_nonzero(front_samples, axis=1) >= 2

                                                                      
                                                      
    visibility = front_edges.reshape((-1, subdivisions))
    candidates = [
        np.zeros(subdivisions, dtype=bool),
        np.ones(subdivisions, dtype=bool),
    ]
    for split in range(1, subdivisions):
        candidates.append(
            np.asarray([False] * split + [True] * (subdivisions - split))
        )
        candidates.append(
            np.asarray([True] * split + [False] * (subdivisions - split))
        )
    for index, states in enumerate(visibility):
        visibility[index] = min(
            candidates, key=lambda candidate: np.count_nonzero(candidate != states)
        )

    def continuous_runs(wanted_state: bool) -> tuple[list[np.ndarray], np.ndarray]:
        polylines: list[np.ndarray] = []
        run_depths: list[float] = []
        for index, states in enumerate(visibility):
            points = np.vstack((segment_starts[index, 0], segment_stops[index]))
            depths = np.concatenate(
                ([depth_starts[index, 0]], depth_stops[index])
            )
            run_start = None
            for segment_index, state in enumerate(states):
                if bool(state) == wanted_state and run_start is None:
                    run_start = segment_index
                at_end = segment_index == subdivisions - 1
                if run_start is not None and (bool(state) != wanted_state or at_end):
                    run_stop = segment_index if bool(state) == wanted_state else segment_index - 1
                    polylines.append(points[run_start : run_stop + 2])
                    run_depths.append(float(depths[run_start : run_stop + 2].mean()))
                    run_start = None
        return polylines, np.asarray(run_depths, dtype=float)

    front_lines, front_line_depth = continuous_runs(True)
    hidden_lines, hidden_line_depth = continuous_runs(False)
    hidden_alpha = wireframe_alpha * (1.0 - surface_alpha)
    if hidden_lines and hidden_alpha > 0:
        hidden_order = np.argsort(hidden_line_depth)[::-1]
        axes.add_collection(
            LineCollection(
                [hidden_lines[index] for index in hidden_order],
                colors="#17212b",
                linewidths=line_width,
                alpha=hidden_alpha,
                antialiaseds=True,
            )
        )
    front_order = np.argsort(front_line_depth)[::-1]
    axes.add_collection(
        LineCollection(
            [front_lines[index] for index in front_order],
            colors="#17212b",
            linewidths=line_width,
            alpha=wireframe_alpha,
            antialiaseds=True,
        )
    )
    axes.set_xlim(0, width)
    axes.set_ylim(height, 0)
    axes.set_aspect("equal")
    axes.axis("off")
    output.parent.mkdir(parents=True, exist_ok=True)
    if verbose:
        print(f"[wireframe] saving image: {output}", flush=True)
    figure.savefig(output, dpi=dpi, facecolor="white", edgecolor="none")
    if show:
        plt.show()
    plt.close(figure)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render a wireframe projection of a mesh or STEP model."
    )
    parser.add_argument("input", type=Path, help="Input .glb, .gltf, .obj, .stl, .step, or .stp model")
    parser.add_argument("-o", "--output", type=Path, help="Output PNG path")
    parser.add_argument("--azimuth", type=float, default=45.0, help="Camera azimuth in degrees (default: 45)")
    parser.add_argument("--elevation", type=float, default=30.0, help="Camera elevation in degrees (default: 30)")
    parser.add_argument("--distance", type=float, default=4.0, help="Camera distance in model radii (default: 4)")
    parser.add_argument("--fov", type=float, default=35.0, help="Vertical field of view in degrees (default: 35)")
    parser.add_argument(
        "--projection",
        choices=("orthographic", "perspective"),
        default="orthographic",
        help="Projection type (default: orthographic)",
    )
    parser.add_argument("--width", type=int, default=1280, help="Image width in pixels (default: 1280)")
    parser.add_argument("--height", type=int, default=960, help="Image height in pixels (default: 960)")
    parser.add_argument(
        "--wireframe-boldness",
        "--line-width",
        dest="wireframe_boldness",
        type=float,
        default=0.35,
        help="B-rep wire width in points (default: 0.35)",
    )
    parser.add_argument(
        "--wireframe-alpha",
        type=float,
        default=0.82,
        help="Front wire opacity from 0 to 1 (default: 0.82)",
    )
    parser.add_argument(
        "--surface-alpha",
        type=float,
        default=1.0,
        help="STEP surface opacity from 0 to 1 (default: 1)",
    )
    parser.add_argument(
        "--surface-color",
        help="Use one color for every STEP surface, for example #7b8093",
    )
    parser.add_argument(
        "--lighting",
        action="store_true",
        help="Add experimental diffuse illumination and specular reflection",
    )
    parser.add_argument(
        "--curve-samples",
        type=int,
        default=32,
        help="Samples per curved STEP B-rep edge (default: 32)",
    )
    parser.add_argument(
        "--surface-mesh-size",
        type=float,
        default=0.0125,
        help=(
            "Maximum STEP fill-mesh edge as a fraction of model diagonal "
            "(default: 0.0125; smaller is finer)"
        ),
    )
    parser.add_argument("--show", action="store_true", help="Open an interactive preview window")
    parser.add_argument("--verbose", action="store_true", help="Print rendering checkpoints")
    parser.add_argument(
        "--edges-only",
        action="store_true",
        help="Skip Gmsh surface meshing and render sampled B-rep edges only",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = args.input.expanduser().resolve()
    output = (args.output or source.with_name(f"{source.stem}_wireframe.png")).expanduser().resolve()

    try:
        if not source.is_file():
            raise RenderError(f"Input file does not exist: {source}")
        if source.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise RenderError("Input must be .glb, .gltf, .obj, .stl, .step, or .stp.")
        if args.distance <= 1.05:
            raise RenderError("--distance must be greater than 1.05 model radii.")
        if not 1.0 <= args.fov < 179.0:
            raise RenderError("--fov must be between 1 and 179 degrees.")
        if args.width < 64 or args.height < 64:
            raise RenderError("--width and --height must each be at least 64 pixels.")
        if args.wireframe_boldness <= 0:
            raise RenderError("--wireframe-boldness must be positive.")
        if not 0.0 <= args.wireframe_alpha <= 1.0:
            raise RenderError("--wireframe-alpha must be between 0 and 1.")
        if not 0.0 <= args.surface_alpha <= 1.0:
            raise RenderError("--surface-alpha must be between 0 and 1.")
        if args.surface_color is not None:
            try:
                from matplotlib.colors import to_rgb

                to_rgb(args.surface_color)
            except ValueError as exc:
                raise RenderError(f"Invalid --surface-color: {args.surface_color}") from exc
        if args.curve_samples < 4:
            raise RenderError("--curve-samples must be at least 4.")
        if not 0.001 <= args.surface_mesh_size <= 0.25:
            raise RenderError("--surface-mesh-size must be between 0.001 and 0.25.")

                                                                             
                                                                               
        import matplotlib
        if not args.show:
            matplotlib.use("Agg")
        import matplotlib.pyplot              

        if args.verbose:
            print(f"[wireframe] input: {source}", flush=True)
            print(f"[wireframe] output: {output}", flush=True)
        geometry = load_geometry(
            source,
            args.curve_samples,
            args.surface_mesh_size,
            args.verbose,
            args.edges_only,
        )
        render_wireframe(
            geometry,
            output,
            args.azimuth,
            args.elevation,
            args.distance,
            args.fov,
            args.width,
            args.height,
            args.wireframe_boldness,
            args.wireframe_alpha,
            args.surface_alpha,
            args.surface_color,
            args.projection,
            args.show,
            experimental_lighting=args.lighting,
            verbose=args.verbose,
        )
    except RenderError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected rendering failure: {exc}", file=sys.stderr)
        return 1

    print(f"Created wireframe: {output} ({output.stat().st_size:,} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
