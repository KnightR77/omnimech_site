"""Convert one SolidWorks part or assembly to one STL file.

SolidWorks must be installed on Windows.  The script uses the SolidWorks COM API
and deliberately contains no directory scanning or batch behavior.
"""

from __future__ import annotations

import argparse
import gc
import sys
from pathlib import Path
from typing import Any


SW_DOC_PART = 1
SW_DOC_ASSEMBLY = 2
SW_OPEN_SILENT = 1
SW_OPEN_READ_ONLY = 2
SW_SAVE_AS_CURRENT_VERSION = 0
SW_SAVE_AS_SILENT = 1
SW_STEP_AP = 75
STEP_AP203 = 203
SW_STL_COMPONENTS_INTO_ONE_FILE = 72

DOCUMENT_TYPES = {
    ".sldprt": SW_DOC_PART,
    ".sldasm": SW_DOC_ASSEMBLY,
}


class ConversionError(RuntimeError):
    """An expected, user-facing conversion failure."""


def connect_to_solidworks(visible: bool) -> tuple[Any, Any, bool]:
    """Return (pythoncom, SolidWorks application, started_by_this_script)."""
    try:
        import pythoncom                
        import pywintypes                
        import win32com.client                
    except ImportError as exc:
        raise ConversionError(
            "pywin32 is not installed. Run: python -m pip install pywin32"
        ) from exc

    pythoncom.CoInitialize()
    started_here = False
    try:
        try:
            app = win32com.client.GetActiveObject("SldWorks.Application")
        except pywintypes.com_error:
            app = win32com.client.Dispatch("SldWorks.Application")
            started_here = True
        app.Visible = visible
        return pythoncom, app, started_here
    except Exception:
        pythoncom.CoUninitialize()
        raise


def describe_com_error(exc: Exception) -> str:
    """Extract the useful message from a pywin32 COM exception."""
    excepinfo = getattr(exc, "excepinfo", None)
    if excepinfo and len(excepinfo) > 2 and excepinfo[2]:
        return str(excepinfo[2]).strip()
    return str(exc).strip()


def long_ref() -> Any:
    """Create a COM `long*` for SolidWorks Errors/Warnings output arguments."""
    import pythoncom                
    from win32com.client import VARIANT                

    return VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)


def com_value(obj: Any, name: str) -> Any:
    """Read a zero-argument COM member exposed as either a method or property."""
    value = getattr(obj, name)
    return value() if callable(value) else value


def get_open_document(app: Any, source: Path) -> Any | None:
    """Avoid opening and later closing a document already open by the user."""
    try:
        return app.GetOpenDocumentByName(str(source))
    except Exception:
        return None


def open_document(app: Any, source: Path) -> tuple[Any, bool]:
    existing = get_open_document(app, source)
    if existing is not None:
        return existing, False

    doc_type = DOCUMENT_TYPES[source.suffix.lower()]
    options = SW_OPEN_SILENT | SW_OPEN_READ_ONLY
    try:
        errors = long_ref()
        warnings = long_ref()
        model = app.OpenDoc6(
            str(source), doc_type, options, "", errors, warnings
        )
    except Exception as exc:
        raise ConversionError(
            f"SolidWorks could not open the model: {describe_com_error(exc)}"
        ) from exc

    if model is None:
        extra = (
            " Check that all referenced component files are available."
            if doc_type == SW_DOC_ASSEMBLY
            else ""
        )
        raise ConversionError(f"SolidWorks returned no document.{extra}")

    return model, True


def activate_document(app: Any, model: Any, expected_source: Path) -> Any:
    """Activate the requested model and prove SolidWorks selected the right file."""
    errors = long_ref()
    try:
        active_model = app.ActivateDoc3(com_value(model, "GetTitle"), True, 0, errors)
    except Exception as exc:
        raise ConversionError(
            f"Could not activate the source document: {describe_com_error(exc)}"
        ) from exc

    if active_model is None:
        raise ConversionError(
            f"SolidWorks could not activate the source document (error {errors.value})."
        )

    try:
        active_path = Path(com_value(active_model, "GetPathName")).resolve()
    except Exception as exc:
        raise ConversionError("Could not verify the active SolidWorks document.") from exc

    if active_path != expected_source:
        raise ConversionError(
            "SolidWorks activated the wrong document. "
            f"Expected {expected_source}, but got {active_path}."
        )
    return active_model


def save_model(model: Any, output: Path, format_name: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)

                                                                        
                                                                      
    try:
        model.ResolveAllLightWeightComponents(True)
    except Exception:
        pass
                                                                             
                                                                            
                                                           
    try:
        result = model.SaveAs3(
            str(output), SW_SAVE_AS_CURRENT_VERSION, SW_SAVE_AS_SILENT
        )
    except Exception as exc:
        raise ConversionError(
            f"SolidWorks {format_name} export failed: {describe_com_error(exc)}"
        ) from exc

    if not output.is_file():
        detail = f" (SaveAs3 returned {result!r})" if result is not None else ""
        raise ConversionError(
            f"SolidWorks did not create the {format_name} file{detail}."
        )
    if output.stat().st_size == 0:
        raise ConversionError(f"SolidWorks created an empty {format_name} file.")


def save_step_ap203(app: Any, model: Any, output: Path) -> None:
    """Export STEP AP203 without permanently changing SolidWorks preferences."""
    try:
        previous_step_ap = app.GetUserPreferenceIntegerValue(SW_STEP_AP)
        if not app.SetUserPreferenceIntegerValue(SW_STEP_AP, STEP_AP203):
            raise ConversionError("SolidWorks rejected the STEP AP203 preference.")
    except ConversionError:
        raise
    except Exception as exc:
        raise ConversionError(
            f"Could not select STEP AP203: {describe_com_error(exc)}"
        ) from exc

    try:
        save_model(model, output, "STEP AP203")
    finally:
        try:
            app.SetUserPreferenceIntegerValue(SW_STEP_AP, previous_step_ap)
        except Exception:
            pass


def save_stl(app: Any, model: Any, output: Path) -> None:
    """Export one STL, combining assembly components and restoring preferences."""
    output.parent.mkdir(parents=True, exist_ok=True)
    files_before = set(output.parent.iterdir())
    try:
        previous_combined = app.GetUserPreferenceToggle(
            SW_STL_COMPONENTS_INTO_ONE_FILE
        )
        app.SetUserPreferenceToggle(SW_STL_COMPONENTS_INTO_ONE_FILE, True)
    except Exception as exc:
        raise ConversionError(
            f"Could not select single-file STL assembly export: {describe_com_error(exc)}"
        ) from exc

    try:
        save_model(model, output, "STL")
    finally:
        try:
            app.SetUserPreferenceToggle(
                SW_STL_COMPONENTS_INTO_ONE_FILE, previous_combined
            )
        except Exception:
            pass
                                                                              
                                                                               
        try:
            for created in set(output.parent.iterdir()) - files_before:
                if created != output and created.is_file():
                    created.unlink()
        except OSError:
            pass


def convert(
    source: Path, output: Path, visible: bool, overwrite: bool
) -> tuple[Path, Path]:
    source = source.expanduser().resolve()
    output = output.expanduser().resolve()
    step_output = output.with_suffix(".step")

    if not source.is_file():
        raise ConversionError(f"Input file does not exist: {source}")
    if source.suffix.lower() not in DOCUMENT_TYPES:
        raise ConversionError("Input must be a .sldprt or .sldasm file.")
    if output.suffix.lower() != ".stl":
        raise ConversionError("Output filename must end in .stl.")
    if source == output:
        raise ConversionError("Input and output paths must be different.")
    existing_outputs = [path for path in (output, step_output) if path.exists()]
    if existing_outputs and not overwrite:
        raise ConversionError(
            "Output already exists: "
            + ", ".join(str(path) for path in existing_outputs)
            + "\nUse --overwrite to replace it."
        )
    for path in existing_outputs:
        try:
            path.unlink()
        except OSError as exc:
            raise ConversionError(f"Cannot replace output file: {exc}") from exc

    pythoncom = None
    app = None
    started_here = False
    model = None
    opened_here = False
    previous_active = None
    try:
        pythoncom, app, started_here = connect_to_solidworks(visible)
        try:
            previous_active = app.ActiveDoc
        except Exception:
            previous_active = None
        model, opened_here = open_document(app, source)
        model = activate_document(app, model, source)
        save_stl(app, model, output)
        save_step_ap203(app, model, step_output)
        return output, step_output
    finally:
        if app is not None and previous_active is not None:
            try:
                previous_path = Path(com_value(previous_active, "GetPathName")).resolve()
                if previous_path != source:
                    restore_errors = long_ref()
                    app.ActivateDoc3(
                        com_value(previous_active, "GetTitle"), True, 0, restore_errors
                    )
            except Exception:
                pass
        if app is not None and model is not None and opened_here:
            try:
                app.CloseDoc(com_value(model, "GetTitle"))
            except Exception:
                pass
                                                                          
                                                                                
                                                                               
                                                    
        if app is not None and started_here:
            try:
                app.Visible = True
            except Exception:
                pass
        model = None
        app = None
        gc.collect()
        if pythoncom is not None:
            pythoncom.CoUninitialize()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Convert one SolidWorks .sldprt or .sldasm file to STL and STEP AP203."
        )
    )
    parser.add_argument("input", type=Path, help="SolidWorks part or assembly")
    parser.add_argument(
        "output",
        type=Path,
        nargs="?",
        help="Output STL path (default: next to the input file)",
    )
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--visible", action="store_true", help="Keep the SolidWorks window visible"
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output = args.output or args.input.with_suffix(".stl")
    try:
        stl_created, step_created = convert(
            args.input, output, args.visible, args.overwrite
        )
    except ConversionError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected SolidWorks/COM error: {describe_com_error(exc)}", file=sys.stderr)
        return 1

    print(f"Created STL: {stl_created} ({stl_created.stat().st_size:,} bytes)")
    print(
        f"Created STEP AP203: {step_created} "
        f"({step_created.stat().st_size:,} bytes)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
