from __future__ import annotations

import argparse
import ast
import base64
import binascii
import http.client
import json
import os
import re
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
DEFAULT_API_KEY_FILE = ROOT / "api_key.txt"
EXPERIMENT_LOG_FILE = ROOT / "zeroshot_exp.log"
DEFAULT_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = "google/gemini-3.1-pro-preview"
DEFAULT_FALLBACK_MODELS: tuple[str, ...] = ()
FILE_WRITER_TOOL_NAME = "write_generated_file"
TARGET_MODEL_SLUGS = {
    "gemini-3.1-pro-preview": "google/gemini-3.1-pro-preview",
    "gemini-3.5-flash": "google/gemini-3.5-flash",
    "qwen3.5-9b": "qwen/qwen3.5-9b",
}
ENGINEERING_CODE_PROMPT = """You are an expert in 2D engineering drawing interpretation and 3D CAD model generation.

Using the supplied 2D engineering drawing as the source of truth, generate a complete standalone Python script that reconstructs the depicted mechanical part and exports a BREP STEP model.

The generated Python script must run without exceptions, export a valid non-empty STEP file, and produce geometry that is faithful to the drawing's readable dimensions, feature counts, relative placement, proportions, symmetry, and overall shape.

Output requirements:

1. Return Python source code only, not STEP data.
2. Do not use Markdown fences.
3. Do not include explanations before or after the code.
4. The script must export generated_model.step in its current working directory.
5. The script must print the absolute output path, bounding-box dimensions, volume if available, and a short validity/status summary.

Drawing interpretation requirements:

1. Interpret all visible orthographic, section, detail, auxiliary, and enlarged views together.
2. Use all clearly readable dimensions from the drawing.
3. Treat dimensions as millimeters unless another unit is explicitly shown.
4. Preserve the major outer profile, thicknesses, steps, bores, holes, slots, tapers, chamfers, fillets, bosses, pockets, ribs, and repeated patterns visible in the drawing.
5. Preserve feature counts, relative placement, orientation, symmetry, coaxial relationships, and alignment between views.
6. When a dimension is missing or ambiguous, infer a conservative engineering value from the views and document the assumption in a concise code comment.
7. Avoid decorative, unsupported, or random geometry that is not justified by the drawing.
8. The supplied 2D engineering drawing may contain additional views other than standard orthographic projections, such as section views, detail views, auxiliary views, and enlarged views. Use all available information to reconstruct the part accurately. Do not treat additional views as separate parts or assemblies unless explicitly indicated.
9. Unless explicitly shown, do not assume hidden features, internal cavities, or internal threads. If a feature is not clearly visible in any view, do not include it in the reconstruction.
10. Unless explicitly defined, assume only one part is represented in the drawing. Do not add additional parts, assemblies, or fasteners unless they are clearly depicted.

Python and CAD construction requirements:

1. The script must run independently with Python and deterministic geometry.
2. Do not require network access, GUI interaction, command-line arguments, runtime user input, cameras, lighting, rendering, animation, or visualization.
3. Prefer CadQuery for CAD construction and STEP export.
4. You may use numpy, scipy, shapely, cadquery, and pythonocc-core when useful, but include a dependency check that reports missing packages and suitable pip installation commands.
5. Use NumPy exactly as: import numpy as np
6. Use named dimensions and explicit feature placements so the reconstruction can be inspected and modified.
7. For circular or repeated features, create reusable helper functions so placements and dimensions remain explicit and auditable.
8. Prefer robust constructive methods. If boolean operations are used, check the result immediately; boolean failures must raise a clear error or use a geometrically valid fallback that still represents the intended feature.
9. Use sufficient segment counts for round mechanical features so cylinders and holes are recognizably circular.
10. Keep coordinates, dimensions, and transforms clear in the code.
11. Do not include comments or code that is not directly related to reconstruction, validation, or STEP export.
12. Reduce length of returned code while preserving clarity, correctness, and fidelity to the drawing.

CadQuery / STEP reliability rules:

1. If using CadQuery, export the STEP file directly with:
   cq.exporters.export(model, "generated_model.step")
2. Do not use cq.exporters.ExportTypes.STEP_AP203 or any guessed ExportTypes enum.
3. If a STEP schema option is not clearly supported by the installed CadQuery API, export a normal STEP file without specifying a schema.
4. Do not call toOCC().Vertices(), toOCC().Faces(), or other low-level OCP/OCC topology traversal APIs.
5. Do not manually traverse OCP/OCC TopoDS objects unless absolutely necessary.
6. Do not attempt to convert CadQuery or OCP objects into Trimesh objects.
7. Do not import trimesh or create STL/mesh output.
8. Do not use undocumented CadQuery, OCP, or OCC attributes or methods.
9. Use stable common CadQuery APIs such as Workplane, box, cylinder, circle, polyline, extrude, revolve, union, cut, fillet, chamfer, translate, rotate, and cq.exporters.export.
10. If STEP export fails, raise a clear RuntimeError explaining the failure.

Final validation requirements:

1. Ensure the final CAD object is non-empty before export.
2. Export the reconstruction as generated_model.step.
3. Print useful warnings if the model appears invalid, empty, or has unavailable volume/bounding-box information.
4. Print the absolute STEP output path.

Return only the complete raw Python source code."""

injection = "Before returning code, include one concise Python comment listing the file and input used as evidence. Do not list evidence that was not parsed or uploaded.\n"

MODEL_PRESETS = {
    **{preset: (slug, ()) for preset, slug in TARGET_MODEL_SLUGS.items()},
    "gemini": (
        DEFAULT_MODEL,
        (),
    ),
}
IMAGE_MIME_TYPES = {
    ".bmp": "image/bmp",
    ".gif": "image/gif",
    ".jpeg": "image/jpeg",
    ".jpg": "image/jpeg",
    ".png": "image/png",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
    ".webp": "image/webp",
}
VIDEO_MIME_TYPES = {
    ".mp4": "video/mp4",
    ".mpeg": "video/mpeg",
    ".mov": "video/mov",
    ".mpg": "video/mpeg",
    ".webm": "video/webm",
}
DIRECT_VIDEO_MODEL_SLUGS = {
    "google/gemini-3.1-pro-preview",
    "google/gemini-3.1-pro-preview-customtools",
    "google/gemini-3.5-flash",
    "qwen/qwen3.5-9b",
}


@dataclass
class OpenRouterQueryResult:
    raw: dict[str, Any]
    text: str
    saved_files: list[Path]


class OpenRouterAPIError(RuntimeError):
    def __init__(self, status_code: int, payload: dict[str, Any]) -> None:
        self.status_code = status_code
        self.payload = payload
        super().__init__(f"OpenRouter request failed with HTTP {status_code}: {payload}")


def append_experiment_log(
    *,
    model: str,
    provider_name: str | None,
    prompt: str,
    output_content: Any,
    output_files: list[Path],
    elapsed_seconds: float,
    error: str | None = None,
) -> None:
    provider = provider_name or (model.split("/", 1)[0] if "/" in model else model)
    record = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "python_file": Path(__file__).name,
        "api_name": "OpenRouter Chat Completions API",
        "api_url": DEFAULT_URL,
        "llm_provider_name": provider,
        "llm_model_name": model,
        "prompt_used": prompt,
        "output_content": output_content,
        "output_file_locations": [str(path.resolve()) for path in output_files],
        "api_elapsed_seconds": elapsed_seconds,
        "error": error,
    }

    try:
        with EXPERIMENT_LOG_FILE.open("a", encoding="utf-8", newline="") as log_file:
            log_file.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")))
            log_file.write("\n")
    except OSError as exc:
        print(f"Could not append experiment log: {exc}", file=sys.stderr)


def explain_openrouter_error(error: Exception) -> str:
    if not isinstance(error, OpenRouterAPIError):
        return str(error)

    message = str(error)
    error_info = error.payload.get("error") if isinstance(error.payload, dict) else None
    if not isinstance(error_info, dict):
        return message

    provider_message = str(error_info.get("message", ""))
    if error.status_code == 403 and "Terms Of Service" in provider_message:
        return (
            message
            + "\n\nThis is a provider/OpenRouter policy rejection, not a Python encoding error. "
            "Try a different model/provider or review the provider's input restrictions."
        )

    return message


def read_api_key(api_key: str | None = None, api_key_file: str | Path | None = None) -> str:
    if api_key:
        return api_key.strip()

    env_key = os.getenv("OPENROUTER_API_KEY")
    if env_key:
        return env_key.strip()

    key_path = Path(api_key_file) if api_key_file else DEFAULT_API_KEY_FILE
    if key_path.exists():
        return key_path.read_text(encoding="utf-8").strip()

    raise RuntimeError(
        "Missing OpenRouter API key. Set OPENROUTER_API_KEY or create api_key.txt."
    )


def encode_image_data_url(image_path: str | Path) -> tuple[str, str]:
    path = Path(image_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Image does not exist: {path}")

    mime_type = IMAGE_MIME_TYPES.get(path.suffix.lower())
    if mime_type is None:
        supported = ", ".join(sorted(IMAGE_MIME_TYPES))
        raise ValueError(f"Expected an image file ({supported}): {path}")

    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return path.name, f"data:{mime_type};base64,{encoded}"


def encode_video_data_url(video_path: str | Path) -> tuple[str, str]:
    path = Path(video_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Video does not exist: {path}")

    mime_type = VIDEO_MIME_TYPES.get(path.suffix.lower())
    if mime_type is None:
        supported = ", ".join(sorted(VIDEO_MIME_TYPES))
        raise ValueError(f"Expected a video file ({supported}): {path}")

    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return path.name, f"data:{mime_type};base64,{encoded}"


def model_supports_direct_video(model: str) -> bool:
    return model in DIRECT_VIDEO_MODEL_SLUGS or model.startswith("~google/gemini-")


def build_image_payload(
    image_path: str | Path,
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    _, data_url = encode_image_data_url(image_path)
    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": data_url,
                        },
                    },
                ],
            }
        ],
    }

    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    add_file_writer_tool(payload, use_file_tool, force_file_tool)

    return payload


def build_image_video_payload(
    drawing_image_path: str | Path,
    walkthrough_video_path: str | Path,
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    _, drawing_data_url = encode_image_data_url(drawing_image_path)
    _, video_data_url = encode_video_data_url(walkthrough_video_path)
    video_text = (
        "Video 1 is a dodecahedron-path walkaround rendering of "
        "the existing/generated 3D model. The camera visits "
        "multiple directions around the model, similar to viewing "
        "it from the vertices of a dodecahedron. Use the video as "
        "visual evidence for the current 3D shape, orientation, "
        "proportions, hidden-side continuity, and missing or "
        "incorrect features. If Video 1 conflicts with the "
        "dimensioned drawing, the drawing takes priority."
    )
    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            prompt
                            + "\n\nImage 1 is the source 2D engineering drawing. "
                            "Use it as the source of truth for dimensions, feature "
                            "counts, and engineering intent."
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": drawing_data_url,
                        },
                    },
                    {
                        "type": "text",
                        "text": video_text,
                    },
                    {
                        "type": "video_url",
                        "video_url": {
                            "url": video_data_url,
                        },
                    },
                ],
            }
        ],
    }

    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    add_file_writer_tool(payload, use_file_tool, force_file_tool)

    return payload


def build_text_payload(
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": prompt,
            }
        ],
    }

    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    add_file_writer_tool(payload, use_file_tool, force_file_tool)

    return payload


def file_writer_tool_schema() -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": FILE_WRITER_TOOL_NAME,
            "description": (
                "Write a generated file for the user. Use this when the user asks for "
                "a STEP, CAD, JSON, or other file artifact."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "Output filename including extension, for example generated_model.step.",
                    },
                    "mime_type": {
                        "type": "string",
                        "description": "Best MIME type for the file, for example model/step or text/plain.",
                    },
                    "encoding": {
                        "type": "string",
                        "enum": ["utf-8", "base64"],
                        "description": "Use utf-8 for text formats like ASCII STL/OBJ; base64 for binary files.",
                    },
                    "content": {
                        "type": "string",
                        "description": "The complete file content, encoded according to encoding.",
                    },
                },
                "required": ["filename", "encoding", "content"],
                "additionalProperties": False,
            },
        },
    }


def add_file_writer_tool(payload: dict[str, Any], use_file_tool: bool, force_file_tool: bool) -> None:
    if not use_file_tool:
        return

    payload["tools"] = [file_writer_tool_schema()]
    if force_file_tool:
        payload["tool_choice"] = {
            "type": "function",
            "function": {"name": FILE_WRITER_TOOL_NAME},
        }


def build_input_payload(
    input_path: str | Path | None,
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    if input_path is None:
        return build_text_payload(
            prompt,
            model=model,
            use_file_tool=use_file_tool,
            force_file_tool=force_file_tool,
            max_tokens=max_tokens,
            temperature=temperature,
        )

    path = Path(input_path)
    suffix = path.suffix.lower()
    if suffix in IMAGE_MIME_TYPES:
        return build_image_payload(
            path,
            prompt,
            model=model,
            use_file_tool=use_file_tool,
            force_file_tool=force_file_tool,
            max_tokens=max_tokens,
            temperature=temperature,
        )

    supported = ", ".join(sorted(IMAGE_MIME_TYPES))
    raise ValueError(f"Expected a supported image file ({supported}): {path}")


def print_verbose_request(
    *,
    payload: dict[str, Any],
    input_files: list[Path],
    fallback_models: list[str],
    api_key_file: Path,
    output_dir: Path | None,
    raw_output: Path | None,
    timeout: int,
) -> None:
    print("\n=== OpenRouter request preview ===")
    print(f"Endpoint URL: {DEFAULT_URL}")
    print(f"Primary model: {payload.get('model')}")
    print(f"Fallback models: {', '.join(fallback_models) if fallback_models else '(none)'}")
    print(f"API key file: {api_key_file}")
    print(f"Output dir: {output_dir if output_dir else '(none)'}")
    print(f"Raw output: {raw_output if raw_output else '(none)'}")
    print(f"Timeout seconds: {timeout}")
    if "max_tokens" in payload:
        print(f"Max tokens: {payload['max_tokens']}")
    if "temperature" in payload:
        print(f"Temperature: {payload['temperature']}")

    print("\nFiles attached:")
    if input_files:
        for index, path in enumerate(input_files, start=1):
            resolved = path.resolve()
            size = resolved.stat().st_size if resolved.exists() else 0
            print(f"{index}. {resolved} ({size} bytes)")
    else:
        print("(none)")

    print("\nMessage text blocks:")
    text_index = 1
    for message_index, message in enumerate(payload.get("messages", []), start=1):
        content = message.get("content")
        if isinstance(content, str):
            print(f"\n--- message {message_index}, text {text_index} ---")
            print(content)
            text_index += 1
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, dict) and part.get("type") == "text":
                    print(f"\n--- message {message_index}, text {text_index} ---")
                    print(str(part.get("text", "")))
                    text_index += 1
                elif isinstance(part, dict) and part.get("type") in {"image_url", "video_url", "file"}:
                    print(f"\n--- message {message_index}, attachment ---")
                    print(f"type: {part.get('type')}")
                    if part.get("type") == "file":
                        file_info = part.get("file") or {}
                        print(f"filename: {file_info.get('filename')}")

    if payload.get("tools"):
        print("\nTool schema:")
        print(json.dumps(payload["tools"], ensure_ascii=False, indent=2))
    if payload.get("tool_choice"):
        print("\nTool choice:")
        print(json.dumps(payload["tool_choice"], ensure_ascii=False, indent=2))
    print("=== End request preview ===\n")


def post_openrouter_chat(
    payload: dict[str, Any],
    *,
    api_key: str | None = None,
    api_key_file: str | Path | None = None,
    http_referer: str | None = None,
    app_title: str | None = "cad-multimodal-query",
    timeout: int = 120,
    retries: int = 2,
    raw_body_output_dir: str | Path | None = None,
    blank_body_retries: int = 2,
) -> dict[str, Any]:
    key = read_api_key(api_key=api_key, api_key_file=api_key_file)
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    if http_referer:
        headers["HTTP-Referer"] = http_referer
    if app_title:
        headers["X-OpenRouter-Title"] = app_title

    request_body = json.dumps(payload).encode("utf-8")
    last_error: Exception | None = None
    response_status: int | None = None
    response_content_type: str | None = None
    response_body = ""
    total_attempts = retries + blank_body_retries + 1
    blank_body_failures = 0
    attempt = 0
    while attempt < total_attempts:
        attempt += 1
        request = urllib.request.Request(
            DEFAULT_URL,
            data=request_body,
            headers=headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                response_status = getattr(response, "status", None)
                response_content_type = response.headers.get("Content-Type")
                response_body = read_response_body_with_deadline(response, timeout).decode("utf-8", errors="replace")
            if raw_body_output_dir:
                save_raw_response_body(response_body, raw_body_output_dir)
            try:
                return json.loads(response_body)
            except json.JSONDecodeError as exc:
                last_error = exc
                if response_body.strip():
                    break
                blank_body_failures += 1
                if blank_body_failures <= blank_body_retries and attempt < total_attempts:
                    print(
                        f"OpenRouter returned a blank non-JSON body on attempt {attempt}; retrying.",
                        file=sys.stderr,
                    )
                    time.sleep(min(2 ** (blank_body_failures - 1), 5))
                    continue
                break
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            try:
                parsed_error = json.loads(error_body)
            except json.JSONDecodeError:
                parsed_error = {"error": {"message": error_body}}
            raise OpenRouterAPIError(exc.code, parsed_error) from exc
        except TimeoutError as exc:
            raise RuntimeError(f"OpenRouter request timed out after {timeout} seconds: {exc}") from exc
        except (http.client.IncompleteRead, urllib.error.URLError) as exc:
            last_error = exc
            if attempt > retries:
                raise RuntimeError(f"OpenRouter request failed after {attempt} attempts: {exc}") from exc
            wait_seconds = min(2 ** (attempt - 1), 5)
            print(
                f"OpenRouter transport error on attempt {attempt}; retrying in {wait_seconds}s: {exc}",
                file=sys.stderr,
            )
            time.sleep(wait_seconds)

    preview = response_body[:2000].strip()
    raise RuntimeError(
        "OpenRouter returned a non-JSON response body "
        f"(status={response_status}, content_type={response_content_type}, "
        f"decode_error={last_error}). Raw body saved to output directory: "
        f"{bool(raw_body_output_dir)}. Body preview:\n{preview}"
    )


def save_raw_response_body(response_body: str, output_dir: str | Path) -> Path:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    target = output / "openrouter_response_body.txt"
    while target.exists():
        target = output / f"{target.stem}_copy{target.suffix}"
    target.write_text(response_body, encoding="utf-8", errors="replace")
    return target


def set_response_socket_timeout(response: Any, seconds: float) -> None:
    try:
        response.fp.raw._sock.settimeout(seconds)
    except AttributeError:
        return


def read_response_body_with_deadline(response: Any, timeout: int | None) -> bytes:
    if timeout is None or timeout <= 0:
        return response.read()

    deadline = time.monotonic() + timeout
    chunks: list[bytes] = []
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"Timed out while reading OpenRouter response body after {timeout} seconds")
        set_response_socket_timeout(response, min(5.0, remaining))
        try:
            chunk = response.read(64 * 1024)
        except socket.timeout as exc:
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Timed out while reading OpenRouter response body after {timeout} seconds") from exc
            continue
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)


def response_text(response: dict[str, Any]) -> str:
    choices = response.get("choices") or []
    if not choices:
        return ""

    message = choices[0].get("message", {})
    content = message.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                parts.append(str(item.get("text", "")))
        return "\n".join(part for part in parts if part)
    reasoning = message.get("reasoning")
    if isinstance(reasoning, str) and reasoning.strip():
        return reasoning
    reasoning_details = message.get("reasoning_details")
    if isinstance(reasoning_details, list):
        parts = [
            str(item.get("text", ""))
            for item in reasoning_details
            if isinstance(item, dict) and isinstance(item.get("text"), str)
        ]
        if parts:
            return "\n".join(part for part in parts if part)
    return str(content)


CODE_BLOCK_EXTENSIONS = {
    "stl": ".stl",
    "obj": ".obj",
    "ply": ".ply",
    "off": ".off",
    "json": ".json",
    "xml": ".xml",
    "step": ".step",
    "stp": ".stp",
}


def safe_output_name(value: str, fallback: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return cleaned or fallback


def save_data_url(data_url: str, output_path: Path) -> Path:
    header, encoded = data_url.split(",", 1)
    if ";base64" not in header:
        output_path.write_text(urllib.request.url2pathname(encoded), encoding="utf-8")
        return output_path

    try:
        data = base64.b64decode(encoded)
    except binascii.Error as exc:
        raise ValueError(f"Invalid base64 data URL for {output_path}") from exc

    output_path.write_bytes(data)
    return output_path


def looks_like_python_source(text: str) -> bool:
    if not text.strip() or "```" in text:
        return False

    try:
        tree = ast.parse(text)
    except SyntaxError:
        return False

    return any(
        isinstance(
            statement,
            (
                ast.Import,
                ast.ImportFrom,
                ast.FunctionDef,
                ast.AsyncFunctionDef,
                ast.ClassDef,
            ),
        )
        for statement in tree.body
    )


def extract_generated_files_from_response(response: dict[str, Any], output_dir: str | Path) -> list[Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []

    text = response_text(response)
    if text:
        if looks_like_python_source(text):
            python_path = output / "generate_step.py"
            while python_path.exists():
                python_path = output / f"{python_path.stem}_copy{python_path.suffix}"
            python_path.write_text(text.rstrip() + "\n", encoding="utf-8")
            saved.append(python_path)

    code_block_pattern = re.compile(r"```([^\r\n`]*)\r?\n?(.*?)```", re.DOTALL)
    block_index = 1
    for match in code_block_pattern.finditer(text):
        info = match.group(1).strip()
        body = match.group(2).strip()
        if not body and " " in info:
            info, body = info.split(" ", 1)
            body = body.strip()
        if not body:
            continue

        info_parts = info.split()
        label = info_parts[0].lower() if info_parts else ""
        filename = ""
        for part in info_parts:
            if "." in part:
                filename = safe_output_name(Path(part).name, "")
                break

        if not filename:
            ext = CODE_BLOCK_EXTENSIONS.get(label)
            if ext is None and body.lower().startswith("solid "):
                ext = ".stl"
            if ext is None:
                ext = ".txt"
            filename = f"generated_{block_index:03d}{ext}"

        target = output / filename
        while target.exists():
            target = output / f"{target.stem}_{block_index:03d}{target.suffix}"

        target.write_text(body + "\n", encoding="utf-8")
        saved.append(target)
        block_index += 1

    for choice_index, choice in enumerate(response.get("choices") or [], start=1):
        message = choice.get("message") or {}
        content = message.get("content")
        parts = content if isinstance(content, list) else []
        for part_index, part in enumerate(parts, start=1):
            if not isinstance(part, dict):
                continue

            file_info = part.get("file")
            if isinstance(file_info, dict):
                filename = safe_output_name(
                    str(file_info.get("filename") or file_info.get("name") or f"generated_file_{choice_index}_{part_index}"),
                    f"generated_file_{choice_index}_{part_index}",
                )
                data = file_info.get("file_data") or file_info.get("data")
                if isinstance(data, str):
                    target = output / filename
                    if data.startswith("data:"):
                        saved.append(save_data_url(data, target))
                    else:
                        target.write_text(data, encoding="utf-8")
                        saved.append(target)

            for key in ("image_url", "audio_url"):
                url_info = part.get(key)
                if not isinstance(url_info, dict):
                    continue
                url = url_info.get("url")
                if not isinstance(url, str) or not url.startswith("data:"):
                    continue
                mime = url.split(";", 1)[0].split(":", 1)[-1]
                ext = "." + mime.rsplit("/", 1)[-1].replace("jpeg", "jpg")
                target = output / f"generated_{choice_index}_{part_index}{ext}"
                saved.append(save_data_url(url, target))

    return saved


def save_json_file_response(response: dict[str, Any], output_dir: str | Path) -> list[Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    target = output / "openrouter_response.json"
    while target.exists():
        target = output / f"{target.stem}_copy{target.suffix}"

    target.write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
    return [target]


def save_raw_output_response(response: dict[str, Any], raw_output: str | Path) -> Path:
    target = Path(raw_output)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def save_tool_call_files(response: dict[str, Any], output_dir: str | Path) -> list[Path]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []

    for choice in response.get("choices") or []:
        message = choice.get("message") or {}
        for tool_call in message.get("tool_calls") or []:
            if not isinstance(tool_call, dict):
                continue
            function = tool_call.get("function") or {}
            if function.get("name") != FILE_WRITER_TOOL_NAME:
                continue

            raw_arguments = function.get("arguments") or "{}"
            try:
                arguments = json.loads(raw_arguments)
            except json.JSONDecodeError:
                continue

            filename = safe_output_name(
                str(arguments.get("filename") or "generated_file"),
                "generated_file",
            )
            target = output / filename
            while target.exists():
                target = output / f"{target.stem}_copy{target.suffix}"

            content = arguments.get("content")
            if not isinstance(content, str):
                continue

            encoding = str(arguments.get("encoding") or "utf-8").lower()
            if encoding == "base64":
                try:
                    target.write_bytes(base64.b64decode(content))
                except binascii.Error:
                    continue
            else:
                target.write_text(content, encoding="utf-8")

            saved.append(target)

    return saved


def run_generated_python_scripts(paths: list[Path], cwd: Path) -> list[tuple[Path, int, str, str]]:
    results: list[tuple[Path, int, str, str]] = []
    cwd = cwd.resolve()

    for path in paths:
        if path.suffix.lower() != ".py":
            continue

        script_path = path.resolve()
        try:
            script_path.relative_to(cwd)
        except ValueError:
            results.append((script_path, 1, "", "Refusing to run script outside output directory."))
            continue

        completed = subprocess.run(
            [sys.executable, str(script_path)],
            cwd=str(cwd),
            text=True,
            capture_output=True,
            timeout=300,
            check=False,
        )
        results.append((script_path, completed.returncode, completed.stdout, completed.stderr))

    return results


def openrouter_query_file(
    input_path: str | Path | None,
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    api_key: str | None = None,
    api_key_file: str | Path | None = None,
    output_dir: str | Path | None = None,
    raw_output: str | Path | None = None,
    fallback_models: list[str] | tuple[str, ...] = DEFAULT_FALLBACK_MODELS,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    save_json_file: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
    timeout: int = 120,
) -> OpenRouterQueryResult:
    models_to_try = [model, *(item for item in fallback_models if item != model)]
    errors: list[str] = []

    for model_name in models_to_try:
        payload = build_input_payload(
            input_path,
            prompt,
            model=model_name,
            use_file_tool=use_file_tool,
            force_file_tool=force_file_tool,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        try:
            raw = post_openrouter_chat(
                payload,
                api_key=api_key,
                api_key_file=api_key_file,
                timeout=timeout,
                raw_body_output_dir=output_dir,
            )
            break
        except OpenRouterAPIError as exc:
            errors.append(f"{model_name}: HTTP {exc.status_code}: {exc.payload}")
            if exc.status_code not in {403, 404, 429, 500, 502, 503, 504}:
                raise
    else:
        raise RuntimeError("All OpenRouter model attempts failed:\n" + "\n".join(errors))

    saved_files: list[Path] = []
    if raw_output:
        saved_files.append(save_raw_output_response(raw, raw_output))
    if output_dir:
        saved_files.extend(save_json_file_response(raw, output_dir))
        saved_files.extend(save_tool_call_files(raw, output_dir))
        saved_files.extend(extract_generated_files_from_response(raw, output_dir))

    return OpenRouterQueryResult(
        raw=raw,
        text=response_text(raw),
        saved_files=saved_files,
    )


def openrouter_query_image_video(
    drawing_image_path: str | Path,
    walkthrough_video_path: str | Path,
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    api_key: str | None = None,
    api_key_file: str | Path | None = None,
    output_dir: str | Path | None = None,
    raw_output: str | Path | None = None,
    fallback_models: list[str] | tuple[str, ...] = DEFAULT_FALLBACK_MODELS,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    save_json_file: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
    timeout: int = 120,
) -> OpenRouterQueryResult:
    models_to_try = [model, *(item for item in fallback_models if item != model)]
    errors: list[str] = []

    for model_name in models_to_try:
        payload = build_image_video_payload(
            drawing_image_path,
            walkthrough_video_path,
            prompt,
            model=model_name,
            use_file_tool=use_file_tool,
            force_file_tool=force_file_tool,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        try:
            raw = post_openrouter_chat(
                payload,
                api_key=api_key,
                api_key_file=api_key_file,
                timeout=timeout,
                raw_body_output_dir=output_dir,
            )
            break
        except OpenRouterAPIError as exc:
            errors.append(f"{model_name}: HTTP {exc.status_code}: {exc.payload}")
            if exc.status_code not in {403, 404, 429, 500, 502, 503, 504}:
                raise
    else:
        raise RuntimeError("All OpenRouter model attempts failed:\n" + "\n".join(errors))

    saved_files: list[Path] = []
    if raw_output:
        saved_files.append(save_raw_output_response(raw, raw_output))
    if output_dir:
        saved_files.extend(save_json_file_response(raw, output_dir))
        saved_files.extend(save_tool_call_files(raw, output_dir))
        saved_files.extend(extract_generated_files_from_response(raw, output_dir))

    return OpenRouterQueryResult(
        raw=raw,
        text=response_text(raw),
        saved_files=saved_files,
    )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Ask OpenRouter to generate reconstruction code from a 2D engineering "
            "drawing image plus a dodecahedron-path walkthrough video."
        )
    )
    parser.add_argument("drawing_image", type=Path, nargs="?", help="Source 2D engineering drawing image.")
    parser.add_argument("walkthrough_video", type=Path, nargs="?", help="Walkaround video of the existing/generated 3D model.")
    parser.add_argument(
        "items",
        nargs="*",
        help="Optional extra manual prompt text appended after the embedded reconstruction prompt.",
    )
    parser.add_argument(
        "--model-preset",
        choices=sorted(MODEL_PRESETS),
        default="gemini",
        help="Named model preset to use when --model is not set. Defaults to gemini for video input.",
    )
    parser.add_argument(
        "--list-model-presets",
        action="store_true",
        help="Print available --model-preset names and OpenRouter slugs, then exit.",
    )
    parser.add_argument("--model", help=f"Explicit model slug. Defaults to the selected preset model.")
    parser.add_argument(
        "--fallback-models",
        default=None,
        help="Optional comma-separated fallback model slugs. Defaults to none.",
    )
    parser.add_argument("--api-key-file", type=Path, default=DEFAULT_API_KEY_FILE)
    parser.add_argument("--output-dir", type=Path, help="Save response text and extracted generated files here.")
    parser.add_argument("--raw-output", type=Path, help="Write the full JSON response to this file.")
    parser.add_argument(
        "--file-tool",
        action="store_true",
        help="Expose a write_generated_file tool so the model can return files through tool calls.",
    )
    parser.add_argument(
        "--force-file-tool",
        action="store_true",
        help="Force the model to call write_generated_file. Best for commands that must produce an STL/OBJ/etc.",
    )
    parser.add_argument(
        "--run-generated-script",
        action="store_true",
        help="After saving generated Python scripts, run them from --output-dir.",
    )
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--temperature", type=float)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print endpoint, selected models, attached files, and full request text blocks before calling the API.",
    )
    return parser.parse_args(argv)


def split_cli_image_video_and_prompt(args: argparse.Namespace) -> tuple[Path, Path, str]:
    if args.drawing_image is None or args.walkthrough_video is None:
        raise ValueError(
            "Provide both drawing_image and walkthrough_video, or use --list-model-presets."
        )

    if args.drawing_image.suffix.lower() not in IMAGE_MIME_TYPES:
        supported = ", ".join(sorted(IMAGE_MIME_TYPES))
        raise ValueError(f"drawing_image must be an image file ({supported}): {args.drawing_image}")
    if not args.drawing_image.exists():
        raise FileNotFoundError(f"drawing_image does not exist: {args.drawing_image}")

    if args.walkthrough_video.suffix.lower() not in VIDEO_MIME_TYPES:
        supported = ", ".join(sorted(VIDEO_MIME_TYPES))
        raise ValueError(
            f"walkthrough_video must be a video file ({supported}): {args.walkthrough_video}"
        )
    if not args.walkthrough_video.exists():
        raise FileNotFoundError(f"walkthrough_video does not exist: {args.walkthrough_video}")

    return args.drawing_image, args.walkthrough_video, " ".join(args.items)


def build_engineering_prompt(manual_prompt: str) -> str:
    manual_prompt = manual_prompt.strip()
    image_video_guidance = (
        "\n\nDrawing-plus-video reconstruction guidance:\n"
        "1. Image 1 is the dimensioned 2D engineering drawing and is the source of truth.\n"
        "2. Video 1 is a rendered dodecahedron-path walkaround of the current or candidate 3D model.\n"
        "3. Treat the video as a continuous multi-view reference: use it to understand spatial form, "
        "orientation, visible proportions, occluded-side continuity, and likely defects, but do not let it "
        "override clear dimensions or feature counts in the drawing.\n"
        "4. If the rendered model appears incomplete or inconsistent with the drawing, generate code for the corrected part implied by the drawing.\n"
    )
    if not manual_prompt:
        return ENGINEERING_CODE_PROMPT + image_video_guidance
    return (
        ENGINEERING_CODE_PROMPT
        + image_video_guidance
        + "\n\nAdditional user instructions:\n"
        + manual_prompt
    )


def resolve_models(args: argparse.Namespace) -> tuple[str, list[str]]:
    preset_model, preset_fallbacks = MODEL_PRESETS[args.model_preset]
    model = args.model or preset_model

    if args.fallback_models is None:
        fallback_models = list(preset_fallbacks)
    else:
        fallback_models = [
            item.strip()
            for item in args.fallback_models.split(",")
            if item.strip()
        ]

    return model, fallback_models


def print_model_presets() -> None:
    print("Available model presets:")
    for name in sorted(MODEL_PRESETS):
        model, fallbacks = MODEL_PRESETS[name]
        fallback_text = ", ".join(fallbacks) if fallbacks else "(none)"
        print(f"  {name}: {model} | fallbacks: {fallback_text}")


def main() -> int:
    args = parse_args()
    if args.list_model_presets:
        print_model_presets()
        return 0

    drawing_image, walkthrough_video, manual_prompt = split_cli_image_video_and_prompt(args)
    prompt = build_engineering_prompt(manual_prompt)

    model, fallback_models = resolve_models(args)
    if args.verbose:
        preview_payload = build_image_video_payload(
            drawing_image,
            walkthrough_video,
            prompt,
            model=model,
            use_file_tool=args.file_tool or args.force_file_tool,
            force_file_tool=args.force_file_tool,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
        )
        print_verbose_request(
            payload=preview_payload,
            input_files=[drawing_image, walkthrough_video],
            fallback_models=fallback_models,
            api_key_file=args.api_key_file,
            output_dir=args.output_dir,
            raw_output=args.raw_output,
            timeout=args.timeout,
        )
    api_started_at = time.perf_counter()
    try:
        result = openrouter_query_image_video(
            drawing_image,
            walkthrough_video,
            prompt,
            model=model,
            api_key_file=args.api_key_file,
            output_dir=args.output_dir,
            raw_output=args.raw_output,
            fallback_models=fallback_models,
            use_file_tool=args.file_tool or args.force_file_tool,
            force_file_tool=args.force_file_tool,
            save_json_file=True,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            timeout=args.timeout,
        )
    except OpenRouterAPIError as exc:
        api_elapsed = time.perf_counter() - api_started_at
        error_message = explain_openrouter_error(exc)
        print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
        append_experiment_log(
            model=model,
            provider_name=None,
            prompt=prompt,
            output_content=exc.payload,
            output_files=[],
            elapsed_seconds=api_elapsed,
            error=error_message,
        )
        print(f"OpenRouter query failed: {error_message}", file=sys.stderr)
        return 1
    except Exception as exc:
        api_elapsed = time.perf_counter() - api_started_at
        error_message = str(exc)
        print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
        append_experiment_log(
            model=model,
            provider_name=None,
            prompt=prompt,
            output_content=None,
            output_files=[],
            elapsed_seconds=api_elapsed,
            error=error_message,
        )
        print(f"OpenRouter query failed: {exc}", file=sys.stderr)
        return 1

    api_elapsed = time.perf_counter() - api_started_at
    print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
    actual_model = str(result.raw.get("model") or model)
    actual_provider = result.raw.get("provider")
    output_files = list(result.saved_files)
    if args.raw_output:
        output_files.append(args.raw_output)
    append_experiment_log(
        model=actual_model,
        provider_name=str(actual_provider) if actual_provider else None,
        prompt=prompt,
        output_content=result.raw,
        output_files=output_files,
        elapsed_seconds=api_elapsed,
    )

    print(result.text)

    if args.raw_output:
        args.raw_output.parent.mkdir(parents=True, exist_ok=True)
        args.raw_output.write_text(
            json.dumps(result.raw, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if result.saved_files:
        print("\nSaved files:")
        for path in result.saved_files:
            print(f"- {path}")

    if args.run_generated_script:
        if args.output_dir is None:
            print("--run-generated-script requires --output-dir.", file=sys.stderr)
            return 1
        run_results = run_generated_python_scripts(result.saved_files, args.output_dir)
        if run_results:
            print("\nGenerated script runs:")
            for script_path, returncode, stdout, stderr in run_results:
                print(f"- {script_path} exited {returncode}")
                if stdout:
                    print(stdout.rstrip())
                if stderr:
                    print(stderr.rstrip(), file=sys.stderr)
                if returncode != 0:
                    return returncode
        else:
            print("No generated Python scripts were saved to run.", file=sys.stderr)
            return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
