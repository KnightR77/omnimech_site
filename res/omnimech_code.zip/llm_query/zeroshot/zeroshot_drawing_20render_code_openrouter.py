from __future__ import annotations

import argparse
import json
import math
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import zeroshot_drawing_8render_code_openrouter as base


ROOT = base.ROOT
DEFAULT_API_KEY_FILE = base.DEFAULT_API_KEY_FILE
EXPERIMENT_LOG_FILE = base.EXPERIMENT_LOG_FILE
DEFAULT_URL = base.DEFAULT_URL
DEFAULT_MODEL = base.DEFAULT_MODEL
DEFAULT_FALLBACK_MODELS = base.DEFAULT_FALLBACK_MODELS
FILE_WRITER_TOOL_NAME = base.FILE_WRITER_TOOL_NAME
TARGET_MODEL_SLUGS = base.TARGET_MODEL_SLUGS
ENGINEERING_CODE_PROMPT = base.ENGINEERING_CODE_PROMPT
MODEL_PRESETS = base.MODEL_PRESETS
IMAGE_MIME_TYPES = base.IMAGE_MIME_TYPES
OpenRouterQueryResult = base.OpenRouterQueryResult
OpenRouterAPIError = base.OpenRouterAPIError

DODECA_VIEW_FILENAME_RE = re.compile(
    r"view_(?P<index>\d+)_az_(?P<az_sign>[mp])(?P<az>\d+(?:\.\d+)?)_"
    r"el_(?P<el_sign>[mp])(?P<el>\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
DODECA_VIEW_INDEX_RE = re.compile(r"view_(?P<index>\d+)", re.IGNORECASE)


append_experiment_log = base.append_experiment_log
explain_openrouter_error = base.explain_openrouter_error
read_api_key = base.read_api_key
encode_image_data_url = base.encode_image_data_url
build_image_payload = base.build_image_payload
build_text_payload = base.build_text_payload
file_writer_tool_schema = base.file_writer_tool_schema
add_file_writer_tool = base.add_file_writer_tool
build_input_payload = base.build_input_payload
print_verbose_request = base.print_verbose_request
post_openrouter_chat = base.post_openrouter_chat
response_text = base.response_text
looks_like_python_source = base.looks_like_python_source
safe_output_name = base.safe_output_name
save_data_url = base.save_data_url
extract_generated_files_from_response = base.extract_generated_files_from_response
save_json_file_response = base.save_json_file_response
save_raw_output_response = base.save_raw_output_response
save_tool_call_files = base.save_tool_call_files
resolve_models = base.resolve_models
print_model_presets = base.print_model_presets


def signed_angle(sign: str, value: str) -> float:
    magnitude = float(value)
    return -magnitude if sign.lower() == "m" else magnitude


def dodecahedron_vertex_from_angles(azimuth_deg: float, elevation_deg: float) -> tuple[int, int, int]:
    azimuth = math.radians(azimuth_deg)
    elevation = math.radians(elevation_deg)
    x = math.cos(elevation) * math.cos(azimuth)
    y = math.cos(elevation) * math.sin(azimuth)
    z = math.sin(elevation)
    return (
        1 if x >= 0.0 else -1,
        1 if y >= 0.0 else -1,
        1 if z >= 0.0 else -1,
    )


def describe_render_view(path: Path, fallback_index: int) -> str:
    match = DODECA_VIEW_FILENAME_RE.search(path.stem)
    if not match:
        index_match = DODECA_VIEW_INDEX_RE.search(path.stem)
        index = int(index_match.group("index")) if index_match else fallback_index
        return (
            f"Image {index + 1} / dodecahedron render view {index}: "
            f"regular-dodecahedron camera direction. Filename: {path.name}."
        )

    index = int(match.group("index"))
    azimuth = signed_angle(match.group("az_sign"), match.group("az"))
    elevation = signed_angle(match.group("el_sign"), match.group("el"))
    octant = dodecahedron_vertex_from_angles(azimuth, elevation)
    return (
        f"Image {index + 1} / dodecahedron render view {index}: "
        f"camera direction near octant {octant}; spherical coordinates "
        f"azimuth {azimuth:.1f} degrees, elevation {elevation:.1f} degrees. "
        f"Filename: {path.name}."
    )


def build_drawing_plus_20_render_payload(
    drawing_image_path: str | Path,
    render_image_paths: list[Path],
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
) -> dict[str, Any]:
    if len(render_image_paths) != 20:
        raise ValueError(f"Expected exactly 20 render images, got {len(render_image_paths)}")

    _, drawing_data_url = encode_image_data_url(drawing_image_path)
    content: list[dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                prompt
                + "\n\nImage 1 is the source 2D engineering drawing. "
                "Use it as the source of truth for dimensions, feature counts, "
                "feature placement, and engineering intent."
            ),
        },
        {
            "type": "image_url",
            "image_url": {
                "url": drawing_data_url,
            },
        },
        {
            "type": "text",
            "text": (
                "The next 20 images are rendered views of the current or candidate "
                "3D model from the 20 vertex directions of a regular dodecahedron. "
                "Use them together as auxiliary multi-view evidence for 3D shape, "
                "orientation, proportions, occluded-side continuity, and visible "
                "missing or incorrect features. If any render conflicts with the "
                "dimensioned drawing, the drawing takes priority."
            ),
        },
    ]

    for index, render_path in enumerate(render_image_paths, start=1):
        _, render_data_url = encode_image_data_url(render_path)
        content.append({"type": "text", "text": describe_render_view(render_path, index)})
        content.append(
            {
                "type": "image_url",
                "image_url": {
                    "url": render_data_url,
                },
            }
        )

    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": content,
            }
        ],
    }

    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    add_file_writer_tool(payload, use_file_tool, force_file_tool)

    return payload


def openrouter_query_drawing_plus_20_renders(
    drawing_image_path: str | Path,
    render_image_paths: list[Path],
    prompt: str,
    *,
    model: str = DEFAULT_MODEL,
    api_key: str | None = None,
    api_key_file: str | Path | None = None,
    output_dir: str | Path | None = None,
    raw_output: str | Path | None = None,
    fallback_models: list[str] | tuple[str, ...] = DEFAULT_FALLBACK_MODELS,
    use_file_tool: bool = False,
    force_file_tool: bool = False,
    save_json_file: bool = False,
    max_tokens: int | None = None,
    temperature: float | None = None,
    timeout: int = 120,
) -> OpenRouterQueryResult:
    models_to_try = [model, *(item for item in fallback_models if item != model)]
    errors: list[str] = []

    for model_name in models_to_try:
        payload = build_drawing_plus_20_render_payload(
            drawing_image_path,
            render_image_paths,
            prompt,
            model=model_name,
            use_file_tool=use_file_tool,
            force_file_tool=force_file_tool,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        try:
            raw = post_openrouter_chat(
                payload,
                api_key=api_key,
                api_key_file=api_key_file,
                timeout=timeout,
                raw_body_output_dir=output_dir,
            )
            break
        except OpenRouterAPIError as exc:
            errors.append(f"{model_name}: HTTP {exc.status_code}: {exc.payload}")
            if exc.status_code not in {403, 404, 429, 500, 502, 503, 504}:
                raise
    else:
        raise RuntimeError("All OpenRouter model attempts failed:\n" + "\n".join(errors))

    saved_files: list[Path] = []
    if raw_output:
        saved_files.append(save_raw_output_response(raw, raw_output))
    if output_dir:
        saved_files.extend(save_json_file_response(raw, output_dir))
        saved_files.extend(save_tool_call_files(raw, output_dir))
        saved_files.extend(extract_generated_files_from_response(raw, output_dir))

    return OpenRouterQueryResult(
        raw=raw,
        text=response_text(raw),
        saved_files=saved_files,
    )


def build_engineering_prompt(manual_prompt: str) -> str:
    manual_prompt = manual_prompt.strip()
    twenty_view_guidance = (
        "\n\nDrawing plus 20-render reconstruction guidance:\n"
        "1. Image 1 is the dimensioned 2D engineering drawing and is the source of truth.\n"
        "2. Images 2 through 21 are rendered dodecahedron-vertex views of the current or candidate 3D model.\n"
        "3. Use the twenty rendered views together to understand spatial form, orientation, visible proportions, "
        "occluded sides, and likely defects, but do not let them override clear dimensions or feature counts in the drawing.\n"
        "4. If the rendered model appears incomplete or inconsistent with the drawing, generate code for the corrected part implied by the drawing.\n"
    )
    if not manual_prompt:
        return ENGINEERING_CODE_PROMPT + twenty_view_guidance
    return (
        ENGINEERING_CODE_PROMPT
        + twenty_view_guidance
        + "\n\nAdditional user instructions:\n"
        + manual_prompt
    )


def image_sort_key(path: Path) -> tuple[int, str]:
    match = DODECA_VIEW_INDEX_RE.search(path.stem)
    if match:
        return int(match.group("index")), path.name.casefold()
    return 9999, path.name.casefold()


def dodeca_view_index(path: Path) -> int | None:
    match = DODECA_VIEW_INDEX_RE.search(path.stem)
    return int(match.group("index")) if match else None


def validate_image_file(label: str, path: Path) -> None:
    if path.suffix.lower() not in IMAGE_MIME_TYPES:
        supported = ", ".join(sorted(IMAGE_MIME_TYPES))
        raise ValueError(f"{label} must be an image file ({supported}): {path}")
    if not path.exists():
        raise FileNotFoundError(f"{label} does not exist: {path}")


def render_images_from_dir(render_dir: Path) -> list[Path]:
    if not render_dir.is_dir():
        raise NotADirectoryError(f"--render-dir does not exist: {render_dir}")
    images = [
        path
        for path in render_dir.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_MIME_TYPES
    ]
    view_images = [path for path in images if dodeca_view_index(path) is not None]
    if view_images:
        by_index: dict[int, list[Path]] = {}
        for path in view_images:
            index = dodeca_view_index(path)
            if index is not None:
                by_index.setdefault(index, []).append(path)

        expected = set(range(1, 21))
        found = set(by_index)
        missing = sorted(expected - found)
        duplicates = sorted(index for index, paths in by_index.items() if len(paths) > 1)
        unexpected = sorted(index for index in found if index not in expected)
        if missing or duplicates or unexpected:
            details = []
            if missing:
                details.append("missing view indices: " + ", ".join(f"{i:02d}" for i in missing))
            if duplicates:
                details.append("duplicate view indices: " + ", ".join(f"{i:02d}" for i in duplicates))
            if unexpected:
                details.append("unexpected view indices: " + ", ".join(f"{i:02d}" for i in unexpected))
            raise ValueError(f"Expected view_01 through view_20 in {render_dir}; " + "; ".join(details))
        return [sorted(by_index[index], key=lambda path: path.name.casefold())[0] for index in range(1, 21)]

    selected = sorted(images, key=image_sort_key)
    if len(selected) != 20:
        raise ValueError(
            f"Expected exactly 20 render images in {render_dir}, found {len(selected)}"
        )
    return selected


def split_cli_images_and_prompt(args: argparse.Namespace) -> tuple[Path, list[Path], str]:
    if args.drawing_image is None:
        raise ValueError(
            "Provide drawing_image plus --render-dir or --render-images, or use --list-model-presets."
        )
    validate_image_file("drawing_image", args.drawing_image)

    if args.render_images is not None and args.render_dir is not None:
        raise ValueError("Use either --render-images or --render-dir/--render-folder, not both.")
    if args.render_images is not None:
        render_images = list(args.render_images)
    elif args.render_dir is not None:
        render_images = render_images_from_dir(args.render_dir)
    else:
        raise ValueError("Provide --render-dir/--render-folder, or provide exactly 20 paths with --render-images.")

    if len(render_images) != 20:
        raise ValueError(f"Expected exactly 20 render images, got {len(render_images)}")
    for index, path in enumerate(render_images, start=1):
        validate_image_file(f"render_image_{index}", path)

    return args.drawing_image, render_images, " ".join(args.items)


def run_generated_python_scripts(paths: list[Path], cwd: Path) -> list[tuple[Path, int, str, str]]:
    results: list[tuple[Path, int, str, str]] = []
    cwd = cwd.resolve()

    for path in paths:
        if path.suffix.lower() != ".py":
            continue

        script_path = path.resolve()
        try:
            script_path.relative_to(cwd)
        except ValueError:
            results.append((script_path, 1, "", "Refusing to run script outside output directory."))
            continue

        completed = subprocess.run(
            [sys.executable, str(script_path)],
            cwd=str(cwd),
            text=True,
            capture_output=True,
            timeout=300,
            check=False,
        )
        results.append((script_path, completed.returncode, completed.stdout, completed.stderr))

    return results


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Ask OpenRouter to generate reconstruction code from a 2D engineering "
            "drawing image plus 20 dodecahedron rendered model images."
        )
    )
    parser.add_argument("drawing_image", type=Path, nargs="?", help="Source 2D engineering drawing image.")
    parser.add_argument(
        "items",
        nargs="*",
        help="Optional extra manual prompt text appended after the embedded reconstruction prompt.",
    )
    parser.add_argument(
        "--render-dir",
        "--render-folder",
        dest="render_dir",
        type=Path,
        help="Directory containing the 20 dodecahedron render images. Used unless --render-images is supplied.",
    )
    parser.add_argument(
        "--render-images",
        type=Path,
        nargs=20,
        metavar="IMAGE",
        help="Twenty explicit render image paths. Overrides folder mode.",
    )
    parser.add_argument(
        "--model-preset",
        choices=sorted(MODEL_PRESETS),
        default="gpt",
        help="Named model preset to use when --model is not set. Defaults to gpt.",
    )
    parser.add_argument("--list-model-presets", action="store_true")
    parser.add_argument("--model", help=f"Explicit model slug. Defaults to the selected preset model.")
    parser.add_argument("--fallback-models", default=None)
    parser.add_argument("--api-key-file", type=Path, default=DEFAULT_API_KEY_FILE)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--raw-output", type=Path)
    parser.add_argument("--file-tool", action="store_true")
    parser.add_argument("--force-file-tool", action="store_true")
    parser.add_argument("--run-generated-script", action="store_true")
    parser.add_argument("--max-tokens", type=int)
    parser.add_argument("--temperature", type=float)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--verbose", action="store_true")
    return parser.parse_args(argv)


def main() -> int:
    args = parse_args()
    if args.list_model_presets:
        print_model_presets()
        return 0

    drawing_image, render_images, manual_prompt = split_cli_images_and_prompt(args)
    prompt = build_engineering_prompt(manual_prompt)

    model, fallback_models = resolve_models(args)
    if args.verbose:
        preview_payload = build_drawing_plus_20_render_payload(
            drawing_image,
            render_images,
            prompt,
            model=model,
            use_file_tool=args.file_tool or args.force_file_tool,
            force_file_tool=args.force_file_tool,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
        )
        print_verbose_request(
            payload=preview_payload,
            input_files=[drawing_image, *render_images],
            fallback_models=fallback_models,
            api_key_file=args.api_key_file,
            output_dir=args.output_dir,
            raw_output=args.raw_output,
            timeout=args.timeout,
        )
    api_started_at = time.perf_counter()
    try:
        result = openrouter_query_drawing_plus_20_renders(
            drawing_image,
            render_images,
            prompt,
            model=model,
            api_key_file=args.api_key_file,
            output_dir=args.output_dir,
            raw_output=args.raw_output,
            fallback_models=fallback_models,
            use_file_tool=args.file_tool or args.force_file_tool,
            force_file_tool=args.force_file_tool,
            save_json_file=True,
            max_tokens=args.max_tokens,
            temperature=args.temperature,
            timeout=args.timeout,
        )
    except OpenRouterAPIError as exc:
        api_elapsed = time.perf_counter() - api_started_at
        error_message = explain_openrouter_error(exc)
        print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
        append_experiment_log(
            model=model,
            provider_name=None,
            prompt=prompt,
            output_content=exc.payload,
            output_files=[],
            elapsed_seconds=api_elapsed,
            error=error_message,
        )
        print(f"OpenRouter query failed: {error_message}", file=sys.stderr)
        return 1
    except Exception as exc:
        api_elapsed = time.perf_counter() - api_started_at
        error_message = str(exc)
        print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
        append_experiment_log(
            model=model,
            provider_name=None,
            prompt=prompt,
            output_content=None,
            output_files=[],
            elapsed_seconds=api_elapsed,
            error=error_message,
        )
        print(f"OpenRouter query failed: {exc}", file=sys.stderr)
        return 1

    api_elapsed = time.perf_counter() - api_started_at
    print(f"OpenRouter API execution time: {api_elapsed:.2f} seconds")
    actual_model = str(result.raw.get("model") or model)
    actual_provider = result.raw.get("provider")
    output_files = list(result.saved_files)
    if args.raw_output:
        output_files.append(args.raw_output)
    append_experiment_log(
        model=actual_model,
        provider_name=str(actual_provider) if actual_provider else None,
        prompt=prompt,
        output_content=result.raw,
        output_files=output_files,
        elapsed_seconds=api_elapsed,
    )

    print(result.text)

    if args.raw_output:
        args.raw_output.parent.mkdir(parents=True, exist_ok=True)
        args.raw_output.write_text(json.dumps(result.raw, ensure_ascii=False, indent=2), encoding="utf-8")
    if result.saved_files:
        print("\nSaved files:")
        for path in result.saved_files:
            print(f"- {path}")

    if args.run_generated_script:
        if args.output_dir is None:
            print("--run-generated-script requires --output-dir.", file=sys.stderr)
            return 1
        run_results = run_generated_python_scripts(result.saved_files, args.output_dir)
        if run_results:
            print("\nGenerated script runs:")
            for script_path, returncode, stdout, stderr in run_results:
                print(f"- {script_path} exited {returncode}")
                if stdout:
                    print(stdout.rstrip())
                if stderr:
                    print(stderr.rstrip(), file=sys.stderr)
                if returncode != 0:
                    return returncode
        else:
            print("No generated Python scripts were saved to run.", file=sys.stderr)
            return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
