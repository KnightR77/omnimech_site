"""Iterative drawing-to-STEP query loop."""

from __future__ import annotations

import argparse
import base64
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
DEFAULT_RENDERER = ROOT / "render_cad_wireframe.py"
DEFAULT_API_KEY_FILE = ROOT / "api_key.txt"
DEFAULT_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = "openai/gpt-5.5"
PLAIN_SURFACE_COLOR = "#7b8093"
DEFAULT_RENDER_FOV = 35.0
DEFAULT_RENDER_PROJECTION = "orthographic"
DEFAULT_RENDER_MARGIN = 0.05
DEFAULT_RENDER_LINE_WIDTH = 2.0

TARGET_MODEL_SLUGS = {
    "gpt-5.5": "openai/gpt-5.5",
    "gpt-5.4-mini": "openai/gpt-5.4-mini",
    "gemini-3.1-pro-preview": "google/gemini-3.1-pro-preview",
    "gemini-3.5-flash": "google/gemini-3.5-flash",
    "claude-opus-4.8": "anthropic/claude-opus-4.8",
    "llama4-maverick": "meta-llama/llama-4-maverick",
    "ministral-14b-2512": "mistralai/ministral-14b-2512",
    "qwen3.7-plus": "qwen/qwen3.7-plus",
    "qwen3.5-9b": "qwen/qwen3.5-9b",
}

MODEL_PRESETS = {
    **{key: (value, ()) for key, value in TARGET_MODEL_SLUGS.items()},
    "gpt": ("openai/gpt-5.5", ()),
    "gemini": ("google/gemini-3.5-flash", ()),
    "qwen": ("qwen/qwen3.7-plus", ()),
    "cheap": ("qwen/qwen3.7-plus", ()),
}

IMAGE_MIME_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}

DEFAULT_PROMPT = """You are an expert in 2D engineering drawing interpretation and 3D CAD model generation.

Using the supplied 2D engineering drawing as the source of truth, generate a complete standalone Python script that reconstructs the depicted mechanical part and exports a BREP STEP model.

The generated Python script must run without exceptions, export a valid non-empty STEP file, and produce geometry that is faithful to the drawing's readable dimensions, feature counts, relative placement, proportions, symmetry, and overall shape.

Output requirements:

1. Return Python source code inside the agentic JSON schema below, not STEP data.
2. Do not use Markdown fences.
3. Do not include explanations before or after the JSON object.
4. The script must export generated_model.step in its current working directory.
5. The script must print the absolute output path, bounding-box dimensions, volume if available, and a short validity/status summary.

Drawing interpretation requirements:

1. Interpret all visible orthographic, section, detail, auxiliary, and enlarged views together.
2. Use all clearly readable dimensions from the drawing.
3. Treat dimensions as millimeters unless another unit is explicitly shown.
4. Preserve the major outer profile, thicknesses, steps, bores, holes, slots, tapers, chamfers, fillets, bosses, pockets, ribs, and repeated patterns visible in the drawing.
5. Preserve feature counts, relative placement, orientation, symmetry, coaxial relationships, and alignment between views.
6. When a dimension is missing or ambiguous, infer a conservative engineering value from the views and document the assumption in a concise code comment.
7. Avoid decorative, unsupported, or random geometry that is not justified by the drawing.
8. The supplied 2D engineering drawing may contain additional views other than standard orthographic projections, such as section views, detail views, auxiliary views, and enlarged views. Use all available information to reconstruct the part accurately. Do not treat additional views as separate parts or assemblies unless explicitly indicated.
9. Unless explicitly shown, do not assume hidden features, internal cavities, or internal threads. If a feature is not clearly visible in any view, do not include it in the reconstruction.
10. Unless explicitly defined, assume only one part is represented in the drawing. Do not add additional parts, assemblies, or fasteners unless they are clearly depicted.

Python and CAD construction requirements:

1. The script must run independently with Python and deterministic geometry.
2. Do not require network access, GUI interaction, command-line arguments, runtime user input, cameras, lighting, rendering, animation, or visualization.
3. Prefer CadQuery for CAD construction and STEP export.
4. You may use numpy, scipy, shapely, cadquery, and pythonocc-core when useful, but include a dependency check that reports missing packages and suitable pip installation commands.
5. Use NumPy exactly as: import numpy as np
6. Use named dimensions and explicit feature placements so the reconstruction can be inspected and modified.
7. For circular or repeated features, create reusable helper functions so placements and dimensions remain explicit and auditable.
8. Prefer robust constructive methods. If boolean operations are used, check the result immediately; boolean failures must raise a clear error or use a geometrically valid fallback that still represents the intended feature.
9. Use sufficient segment counts for round mechanical features so cylinders and holes are recognizably circular.
10. Keep coordinates, dimensions, and transforms clear in the code.
11. Do not include comments or code that is not directly related to reconstruction, validation, or STEP export.
12. Reduce length of returned code while preserving clarity, correctness, and fidelity to the drawing.

CadQuery / STEP reliability rules:

1. If using CadQuery, export the STEP file directly with:
   cq.exporters.export(model, "generated_model.step")
2. Do not use cq.exporters.ExportTypes.STEP_AP203 or any guessed ExportTypes enum.
3. If a STEP schema option is not clearly supported by the installed CadQuery API, export a normal STEP file without specifying a schema.
4. Do not call toOCC().Vertices(), toOCC().Faces(), or other low-level OCP/OCC topology traversal APIs.
5. Do not manually traverse OCP/OCC TopoDS objects unless absolutely necessary.
6. Do not attempt to convert CadQuery or OCP objects into Trimesh objects.
7. Do not import trimesh or create STL/mesh output.
8. Do not use undocumented CadQuery, OCP, or OCC attributes or methods.
9. Use stable common CadQuery APIs such as Workplane, box, cylinder, circle, polyline, extrude, revolve, union, cut, fillet, chamfer, translate, rotate, and cq.exporters.export.
10. If STEP export fails, raise a clear RuntimeError explaining the failure.

Final validation requirements:

1. Ensure the final CAD object is non-empty before export.
2. Export the reconstruction as generated_model.step.
3. Print useful warnings if the model appears invalid, empty, or has unavailable volume/bounding-box information.
4. Print the absolute STEP output path.

Return only according to the agentic JSON schema below."""


AGENT_RESPONSE_INSTRUCTIONS = """

Agentic response requirements:

Return exactly one JSON object and no Markdown.

The JSON object must have this schema:
{
  "code": "complete standalone Python source code that exports generated_model.step",
  "needs_render_feedback": true,
  "render_view": {
    "azimuth_deg": number,
    "elevation_deg": number,
    "distance": number
  },
  "notes": "short explanation of what changed or what view was requested"
}

The code must be complete on every turn, not a patch.

Set needs_render_feedback to true if you want the local runner to render the
generated STEP model and send the render back for another revision turn. Set it
to false only when you are confident the returned code is final and no visual
render feedback is needed. If you are uncertain about shape correctness, hidden
features, proportions, or code execution, set needs_render_feedback to true.

The render_view is the spherical camera view to use when needs_render_feedback
is true. Use azimuth_deg in degrees around the Z axis, elevation_deg in degrees
above the XY plane, and distance in model radii. Choose the view that would best
help you inspect likely missing or incorrect features in the next turn.
"""


MAIN_PROMPT = (
    DEFAULT_PROMPT
    + AGENT_RESPONSE_INSTRUCTIONS
    + """

Agentic task objective:

You are working in an iterative generate-run-render-revise loop. In this first
turn, use the supplied engineering drawing to generate the best complete STEP
generation script you can. Also choose one spherical render view that would be
most useful for inspecting whether your generated 3D model matches the drawing.

The local runner will execute your code, render the generated STEP model from
your requested view, and return execution/render feedback in a later turn.
"""
)


REPAIR_PROMPT = """
You are continuing an iterative CAD reconstruction task.

Use the execution feedback below to return a revised complete Python script.
Keep the engineering drawing as the source of truth. The rendered model image is
only feedback about the current generated model. If the render conflicts with
the drawing, fix the model according to the drawing.

Set needs_render_feedback to true if you still want another local render
feedback turn after this code is executed. Set it to false only when you are
confident the current code should be final and no further visual render feedback
is needed.

Return exactly one JSON object with the same schema:
{
  "code": "complete standalone Python source code that exports generated_model.step",
  "needs_render_feedback": true,
  "render_view": {
    "azimuth_deg": number,
    "elevation_deg": number,
    "distance": number
  },
  "notes": "short explanation of what changed or what view was requested"
}
"""


@dataclass
class AgentResponse:
    code: str
    needs_render_feedback: bool
    azimuth_deg: float
    elevation_deg: float
    distance: float
    notes: str
    parsed: dict[str, Any]


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_api_key(api_key_file: Path) -> str:
    import os

    env_key = os.getenv("OPENROUTER_API_KEY")
    if env_key:
        return env_key.strip()
    if api_key_file.exists():
        return api_key_file.read_text(encoding="utf-8").strip()
    raise RuntimeError("Missing OpenRouter API key. Set OPENROUTER_API_KEY or create api_key.txt.")


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def payload_for_logging(payload: dict[str, Any]) -> dict[str, Any]:
    def redact(value: Any) -> Any:
        if isinstance(value, dict):
            redacted: dict[str, Any] = {}
            for key, item in value.items():
                if key == "url" and isinstance(item, str) and item.startswith("data:"):
                    prefix = item.split(",", 1)[0]
                    redacted[key] = f"{prefix},<base64 omitted; {len(item)} chars>"
                else:
                    redacted[key] = redact(item)
            return redacted
        if isinstance(value, list):
            return [redact(item) for item in value]
        return value

    return redact(payload)


def encode_image_data_url(path: Path) -> str:
    resolved = path.resolve()
    mime_type = IMAGE_MIME_TYPES.get(resolved.suffix.lower())
    if mime_type is None:
        supported = ", ".join(sorted(IMAGE_MIME_TYPES))
        raise ValueError(f"Expected image file ({supported}): {resolved}")
    return f"data:{mime_type};base64,{base64.b64encode(resolved.read_bytes()).decode('ascii')}"


def response_text(response: dict[str, Any]) -> str:
    choices = response.get("choices") or []
    if not choices:
        return ""
    message = choices[0].get("message") or {}
    content = message.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [
            str(part.get("text", ""))
            for part in content
            if isinstance(part, dict) and part.get("type") == "text"
        ]
        return "\n".join(part for part in parts if part)
    return str(content)


def save_raw_response_body(response_body: str, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / "openrouter_response_body.txt"
    while target.exists():
        target = output_dir / f"{target.stem}_copy{target.suffix}"
    target.write_text(response_body, encoding="utf-8", errors="replace")
    return target


def post_openrouter_chat(
    payload: dict[str, Any],
    *,
    api_key_file: Path,
    timeout: int | None,
    raw_body_output_dir: Path | None,
    blank_body_retries: int = 2,
) -> dict[str, Any]:
    key = read_api_key(api_key_file)
    request_body = json.dumps(payload).encode("utf-8")
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "X-OpenRouter-Title": "cad-agentic-query",
    }

    response_status: int | None = None
    response_content_type: str | None = None
    last_error: json.JSONDecodeError | None = None
    response_body = ""
    for attempt in range(1, blank_body_retries + 2):
        request = urllib.request.Request(DEFAULT_URL, data=request_body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                response_status = getattr(response, "status", None)
                response_content_type = response.headers.get("Content-Type")
                response_body = response.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            error_body = exc.read().decode("utf-8", errors="replace")
            if raw_body_output_dir:
                save_raw_response_body(error_body, raw_body_output_dir)
            try:
                parsed_error = json.loads(error_body)
            except json.JSONDecodeError:
                parsed_error = {"error": {"message": error_body}}
            raise RuntimeError(f"OpenRouter HTTP {exc.code}: {json.dumps(parsed_error, ensure_ascii=False)}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"OpenRouter request failed: {exc}") from exc

        if raw_body_output_dir:
            save_raw_response_body(response_body, raw_body_output_dir)
        try:
            return json.loads(response_body)
        except json.JSONDecodeError as exc:
            last_error = exc
            if response_body.strip():
                break
            if attempt <= blank_body_retries:
                print(f"OpenRouter returned a blank body on attempt {attempt}; retrying.", file=sys.stderr)
                continue
            break

    preview = response_body[:2000].strip()
    raise RuntimeError(
        "OpenRouter returned a non-JSON response body "
        f"(status={response_status}, content_type={response_content_type}, "
        f"decode_error={last_error}). Body preview:\n{preview}"
    )


def extract_json_object(text: str) -> dict[str, Any]:
    stripped = text.strip()
    if stripped.startswith("```"):
        match = re.search(r"```(?:json)?\s*(.*?)```", stripped, re.DOTALL | re.IGNORECASE)
        if match:
            stripped = match.group(1).strip()
        else:
            stripped = re.sub(r"^```[A-Za-z0-9_-]*\s*", "", stripped, count=1).strip()
    decoder = json.JSONDecoder(strict=False)
    try:
        return decoder.decode(stripped)
    except json.JSONDecodeError as first_error:
        start = stripped.find("{")
        end = stripped.rfind("}")
        if start >= 0:
            if end > start:
                candidate = stripped[start : end + 1]
                try:
                    return decoder.decode(candidate)
                except json.JSONDecodeError:
                    try:
                        return extract_loose_agent_json(candidate)
                    except Exception:
                        pass
            try:
                return extract_loose_agent_json(stripped[start:])
            except Exception:
                pass
        raise first_error


def unescape_loose_json_string(value: str) -> str:
    return (
        value.replace('\\"', '"')
        .replace("\\\\", "\\")
        .replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace("\\r", "\r")
    )


def extract_loose_string_field(text: str, key: str) -> str:
    match = re.search(rf'"{re.escape(key)}"\s*:\s*"', text)
    if not match:
        return ""
    start = match.end()
    end_match = re.search(r'"\s*(?:,|\})\s*(?:"[A-Za-z_][A-Za-z0-9_]*"\s*:|\Z)', text[start:], re.DOTALL)
    if not end_match:
        if key == "code":
            value = text[start:]
            fence = value.rfind("```")
            if fence >= 0:
                value = value[:fence]
            return unescape_loose_json_string(value).rstrip()
        return ""
    return unescape_loose_json_string(text[start : start + end_match.start()])


def extract_loose_agent_json(text: str) -> dict[str, Any]:
    code = extract_loose_string_field(text, "code")
    if not code:
        raise ValueError("Could not recover 'code' from malformed JSON response.")
    parsed: dict[str, Any] = {"code": code}

    needs_match = re.search(r'"needs_render_feedback"\s*:\s*("?)(true|false|yes|no|1|0)\1', text, re.IGNORECASE)
    if needs_match:
        parsed["needs_render_feedback"] = needs_match.group(2).lower() in {"true", "yes", "1"}

    notes = extract_loose_string_field(text, "notes")
    if notes:
        parsed["notes"] = notes

    render_match = re.search(r'"render_view"\s*:\s*(\{.*?\})', text, re.DOTALL)
    if render_match:
        try:
            parsed["render_view"] = json.JSONDecoder(strict=False).decode(render_match.group(1))
        except json.JSONDecodeError:
            pass
    return parsed


def parse_agent_response(raw: dict[str, Any]) -> AgentResponse:
    text = response_text(raw)
    parsed = extract_json_object(text)
    code = parsed.get("code")
    if not isinstance(code, str) or not code.strip():
        raise ValueError("Model response JSON did not include non-empty 'code'.")
    view = parsed.get("render_view")
    if not isinstance(view, dict):
        raise ValueError("Model response JSON did not include 'render_view'.")
    needs_render_feedback = parsed.get("needs_render_feedback", True)
    if not isinstance(needs_render_feedback, bool):
        if isinstance(needs_render_feedback, str):
            needs_render_feedback = needs_render_feedback.strip().lower() in {"1", "true", "yes", "y"}
        else:
            needs_render_feedback = bool(needs_render_feedback)
    return AgentResponse(
        code=code.rstrip() + "\n",
        needs_render_feedback=needs_render_feedback,
        azimuth_deg=float(view.get("azimuth_deg", 45.0)),
        elevation_deg=float(view.get("elevation_deg", 30.0)),
        distance=float(view.get("distance", 4.0)),
        notes=str(parsed.get("notes") or ""),
        parsed=parsed,
    )


def build_initial_payload(
    drawing_image: Path,
    prompt: str,
    model: str,
    max_tokens: int | None,
    temperature: float | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt,
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": encode_image_data_url(drawing_image)},
                    },
                ],
            }
        ],
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    return payload


def build_followup_payload(
    *,
    model: str,
    drawing_image: Path,
    initial_prompt: str,
    iteration: int,
    feedback_text: str,
    render_image: Path | None,
    render_view: dict[str, float] | None,
    max_tokens: int | None,
    temperature: float | None,
) -> dict[str, Any]:
    content: list[dict[str, Any]] = [
        {
            "type": "text",
            "text": (
                "ORIGINAL USER TASK - iteration 1 prompt:\n"
                + initial_prompt
                + "\n\nITERATIVE REFINEMENT INSTRUCTIONS - apply in every later iteration:\n"
                + REPAIR_PROMPT
                + f"\n\nITERATION {iteration} INPUT:\n"
                "The original engineering drawing is included again as Image 1. "
                "The local runner feedback below is new feedback from the previous generated code."
            ),
        },
        {"type": "image_url", "image_url": {"url": encode_image_data_url(drawing_image)}},
        {"type": "text", "text": feedback_text},
    ]
    if render_image is not None:
        view_text = ""
        if render_view is not None:
            view_text = (
                f" View parameters: azimuth={render_view.get('azimuth_deg', 45.0):.3f} deg, "
                f"elevation={render_view.get('elevation_deg', 30.0):.3f} deg, "
                f"requested distance={render_view.get('distance', 4.0):.3f} model radii."
            )
        content.append(
            {
                "type": "text",
                "text": "Image 2 below is the rendered view of the currently generated STEP model." + view_text,
            }
        )
        content.append(
            {
                "type": "image_url",
                "image_url": {"url": encode_image_data_url(render_image)},
            }
        )

    payload: dict[str, Any] = {
        "model": model,
        "messages": [{"role": "user", "content": content}],
    }
    if max_tokens is not None:
        payload["max_tokens"] = max_tokens
    if temperature is not None:
        payload["temperature"] = temperature
    return payload


def post_payload(payload: dict[str, Any], api_key_file: Path, timeout: int | None, output_dir: Path) -> dict[str, Any]:
    return post_openrouter_chat(
        payload,
        api_key_file=api_key_file,
        timeout=timeout,
        raw_body_output_dir=output_dir,
    )


def run_generated_code(
    script_path: Path,
    *,
    python_exe: str,
    timeout: int | None,
) -> dict[str, Any]:
    started = time.perf_counter()
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = subprocess.run(
            [python_exe, script_path.name],
            cwd=str(script_path.parent),
            text=True,
            capture_output=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
        (script_path.parent / "execution_stdout.txt").write_text(stdout, encoding="utf-8", errors="replace")
        (script_path.parent / "execution_stderr.txt").write_text(stderr, encoding="utf-8", errors="replace")
        step_path = script_path.parent / "generated_model.step"
        alt_step = script_path.parent / "generated_model.stp"
        output_path = step_path if step_path.is_file() else alt_step
        output_exists = output_path.is_file() and output_path.stat().st_size > 0
        status = "success" if output_exists else "failure"
        return {
            "status": status,
            "returncode": proc.returncode,
            "elapsed_seconds": time.perf_counter() - started,
            "stdout": stdout,
            "stderr": stderr,
            "step_path": str(output_path) if output_exists else None,
            "step_size_bytes": output_path.stat().st_size if output_exists else 0,
            "warning": (
                f"Process returned {proc.returncode}, but STEP was generated."
                if output_exists and proc.returncode != 0
                else None
            ),
            "error": None if output_exists else f"Script returned {proc.returncode} and no non-empty STEP was generated.",
        }
    except subprocess.TimeoutExpired as exc:
        stdout = exc.stdout or ""
        stderr = exc.stderr or ""
        (script_path.parent / "execution_stdout.txt").write_text(stdout, encoding="utf-8", errors="replace")
        (script_path.parent / "execution_stderr.txt").write_text(stderr, encoding="utf-8", errors="replace")
        return {
            "status": "failure",
            "returncode": None,
            "elapsed_seconds": time.perf_counter() - started,
            "stdout": stdout,
            "stderr": stderr,
            "step_path": None,
            "step_size_bytes": 0,
            "error": f"Execution timed out after {timeout} seconds.",
        }
    except Exception as exc:
        return {
            "status": "failure",
            "returncode": None,
            "elapsed_seconds": time.perf_counter() - started,
            "stdout": "",
            "stderr": traceback.format_exc(),
            "step_path": None,
            "step_size_bytes": 0,
            "error": str(exc),
        }


def render_step(
    step_path: Path,
    output_path: Path,
    *,
    azimuth: float,
    elevation: float,
    distance: float,
    python_exe: str,
    renderer: Path,
    timeout: int | None,
    width: int,
    height: int,
) -> dict[str, Any]:
    fit_result = compute_fit_distance_for_view(
        step_path,
        azimuth=azimuth,
        elevation=elevation,
        requested_distance=distance,
        fov=DEFAULT_RENDER_FOV,
        width=width,
        height=height,
        margin=DEFAULT_RENDER_MARGIN,
        projection=DEFAULT_RENDER_PROJECTION,
    )
    effective_distance = fit_result["effective_distance"]
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    cmd = [
        python_exe,
        str(renderer),
        str(step_path),
        "-o",
        str(output_path),
        "--azimuth",
        str(azimuth),
        "--elevation",
        str(elevation),
        "--distance",
        str(effective_distance),
        "--fov",
        str(DEFAULT_RENDER_FOV),
        "--projection",
        DEFAULT_RENDER_PROJECTION,
        "--width",
        str(width),
        "--height",
        str(height),
        "--surface-color",
        PLAIN_SURFACE_COLOR,
        "--line-width",
        str(DEFAULT_RENDER_LINE_WIDTH),
        "--lighting",
    ]
    started = time.perf_counter()
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            text=True,
            capture_output=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            env=env,
        )
        ok = proc.returncode == 0 and output_path.is_file() and output_path.stat().st_size > 0
        return {
            "status": "success" if ok else "failure",
            "returncode": proc.returncode,
            "elapsed_seconds": time.perf_counter() - started,
            "render_path": str(output_path) if ok else None,
            "requested_distance": distance,
            "effective_distance": effective_distance,
            "fit_distance": fit_result.get("fit_distance"),
            "fit_warning": fit_result.get("warning"),
            "surface_color": PLAIN_SURFACE_COLOR,
            "line_width": DEFAULT_RENDER_LINE_WIDTH,
            "lighting": True,
            "projection": DEFAULT_RENDER_PROJECTION,
            "fov": DEFAULT_RENDER_FOV,
            "stdout": proc.stdout or "",
            "stderr": proc.stderr or "",
            "error": None if ok else "Render failed or produced no non-empty PNG.",
        }
    except Exception as exc:
        return {
            "status": "failure",
            "returncode": None,
            "elapsed_seconds": time.perf_counter() - started,
            "render_path": None,
            "requested_distance": distance,
            "effective_distance": effective_distance,
            "fit_distance": fit_result.get("fit_distance"),
            "fit_warning": fit_result.get("warning"),
            "surface_color": PLAIN_SURFACE_COLOR,
            "line_width": DEFAULT_RENDER_LINE_WIDTH,
            "lighting": True,
            "projection": DEFAULT_RENDER_PROJECTION,
            "fov": DEFAULT_RENDER_FOV,
            "stdout": "",
            "stderr": traceback.format_exc(),
            "error": str(exc),
        }


def compute_fit_distance_for_view(
    step_path: Path,
    *,
    azimuth: float,
    elevation: float,
    requested_distance: float,
    fov: float,
    width: int,
    height: int,
    margin: float,
    projection: str,
) -> dict[str, Any]:
    """Compute a safe camera distance so the object stays inside the frame."""
    safe_requested = max(float(requested_distance), 1.1)
    try:
        import math
        import numpy as np
        from render_cad_wireframe import camera_basis, load_geometry

        geometry = load_geometry(
            step_path,
            curve_samples=32,
            surface_mesh_size=0.0125,
            verbose=False,
            edges_only=False,
        )
        vertices = geometry.vertices
        center = (vertices.min(axis=0) + vertices.max(axis=0)) * 0.5
        centered = vertices - center
        radius = float(np.linalg.norm(centered, axis=1).max())
        if radius <= 0:
            raise ValueError("model has zero spatial extent")

        _, right, up, forward = camera_basis(azimuth, elevation)
        camera_x = centered @ right
        camera_y = centered @ up
        depth_offset = centered @ forward

        focal_pixels = 0.5 * height / math.tan(math.radians(fov) * 0.5)
        usable_half_width = width * (0.5 - margin)
        usable_half_height = height * (0.5 - margin)
        required_depth = np.maximum(
            focal_pixels * np.abs(camera_x) / usable_half_width,
            focal_pixels * np.abs(camera_y) / usable_half_height,
        )
        if projection == "orthographic":
            fit_distance = float(np.max(required_depth / radius))
        else:
            fit_distance = float(np.max((required_depth - depth_offset) / radius))
        fit_distance = max(1.1, fit_distance * 1.002)
        return {
            "requested_distance": requested_distance,
            "fit_distance": fit_distance,
            "effective_distance": max(safe_requested, fit_distance),
            "warning": None,
        }
    except Exception as exc:
        return {
            "requested_distance": requested_distance,
            "fit_distance": None,
            "effective_distance": max(safe_requested, 4.0),
            "warning": f"Auto-fit distance failed; used conservative fallback. {exc}",
        }


def code_diff(previous: str, current: str) -> str:
    return "".join(
        difflib.unified_diff(
            previous.splitlines(keepends=True),
            current.splitlines(keepends=True),
            fromfile="latest_generate_step.py",
            tofile="previous_generate_step.py",
        )
    )


def trim(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} chars]"


def build_feedback(
    *,
    iteration: int,
    agent_response: AgentResponse,
    previous_code: str | None,
    execution: dict[str, Any],
    render: dict[str, Any] | None,
    full_history_first_response: bool,
    log_char_limit: int,
) -> str:
    code_context: dict[str, Any] = {
        "memory_role": "ITERATION HISTORY - compressed code history",
        "compression_method": "latest full code with prior versions stored as unified diffs",
        "latest_full_code": agent_response.code,
        "history": [],
    }
    if previous_code is not None:
        code_context["history"].append(
            {
                "type": "latest_to_previous_unified_diff",
                "description": (
                    "Diff from latest_full_code to the previous iteration. "
                    "apply this diff conceptually in reverse-time order to inspect the previous code."
                ),
                "content": code_diff(agent_response.code, previous_code),
            }
        )
    elif iteration == 1 and full_history_first_response:
        code_context["history"].append(
            {
                "type": "initial_full_code_also_shown_as_history",
                "content": agent_response.code,
            }
        )

    failure_schema = {
        "iteration": iteration,
        "result": "execution_failure",
        "model_requested_render_feedback": agent_response.needs_render_feedback,
        "requested_render_view": {
            "azimuth_deg": agent_response.azimuth_deg,
            "elevation_deg": agent_response.elevation_deg,
            "distance": agent_response.distance,
        },
        "execution": {
            "returncode": execution.get("returncode"),
            "elapsed_seconds": execution.get("elapsed_seconds"),
            "error": execution.get("error"),
            "stdout": trim(str(execution.get("stdout") or ""), log_char_limit),
            "stderr_or_backtrace": trim(str(execution.get("stderr") or ""), log_char_limit),
        },
        "code_context": code_context,
    }

    success_schema = {
        "iteration": iteration,
        "result": "step_generated_and_rendered" if render and render.get("status") == "success" else "step_generated_render_failed",
        "model_requested_render_feedback": agent_response.needs_render_feedback,
        "requested_render_view": {
            "azimuth_deg": agent_response.azimuth_deg,
            "elevation_deg": agent_response.elevation_deg,
            "distance": agent_response.distance,
        },
        "execution": {
            "returncode": execution.get("returncode"),
            "elapsed_seconds": execution.get("elapsed_seconds"),
            "step_size_bytes": execution.get("step_size_bytes"),
            "warning": execution.get("warning"),
            "stdout": trim(str(execution.get("stdout") or ""), log_char_limit),
            "stderr_or_backtrace": trim(str(execution.get("stderr") or ""), log_char_limit),
        },
        "render": render,
        "code_context": code_context,
    }
    payload = success_schema if execution.get("status") == "success" else failure_schema
    return f"ITERATION {iteration} LOCAL FEEDBACK:\n" + json.dumps(payload, ensure_ascii=False, indent=2)


def parse_model(model: str | None, preset: str) -> str:
    if model:
        return model
    if preset not in MODEL_PRESETS:
        raise ValueError(f"Unknown model preset: {preset}")
    return MODEL_PRESETS[preset][0]


def build_prompt(manual_prompt: str) -> str:
    if manual_prompt.strip():
        return MAIN_PROMPT + "\n\nAdditional user instructions:\n" + manual_prompt.strip()
    return MAIN_PROMPT


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Agentic OpenRouter loop for drawing-to-STEP code generation.")
    parser.add_argument("drawing_image", type=Path, help="Source 2D engineering drawing image.")
    parser.add_argument("prompt_items", nargs="*", help="Optional extra prompt text.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Directory for iteration outputs.")
    parser.add_argument("--model", help="OpenRouter model slug.")
    parser.add_argument("--model-preset", default="gpt-5.5", choices=sorted(MODEL_PRESETS))
    parser.add_argument("--api-key-file", type=Path, default=DEFAULT_API_KEY_FILE)
    parser.add_argument("--max-iter", type=int, default=3, help="Maximum agent iterations.")
    parser.add_argument("--max-tokens", type=int, default=None)
    parser.add_argument("--temperature", type=float, default=None)
    parser.add_argument("--request-timeout", type=int, default=300)
    parser.add_argument("--exec-timeout", type=int, default=180)
    parser.add_argument("--render-timeout", type=int, default=180)
    parser.add_argument("--python", default=sys.executable, help="Python executable for generated code and renderer.")
    parser.add_argument("--renderer", type=Path, default=DEFAULT_RENDERER)
    parser.add_argument("--render-width", type=int, default=1280)
    parser.add_argument("--render-height", type=int, default=960)
    parser.add_argument("--log-char-limit", type=int, default=6000)
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args(argv)

    if args.max_iter < 1:
        raise ValueError("--max-iter must be at least 1")
    if not args.drawing_image.exists():
        raise FileNotFoundError(f"Drawing image does not exist: {args.drawing_image}")

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    model = parse_model(args.model, args.model_preset)
    prompt = build_prompt(" ".join(args.prompt_items))

    manifest: dict[str, Any] = {
        "started_utc": utc_now_iso(),
        "drawing_image": str(args.drawing_image.resolve()),
        "output_dir": str(output_dir),
        "model": model,
        "model_preset": args.model_preset,
        "max_iter": args.max_iter,
        "iterations": [],
    }
    write_json(output_dir / "agentic_manifest.json", manifest)

    previous_code: str | None = None
    feedback_text: str | None = None
    render_image_for_next: Path | None = None
    render_view_for_next: dict[str, float] | None = None

    for iteration in range(1, args.max_iter + 1):
        iter_dir = output_dir / f"iter_{iteration:02d}"
        iter_dir.mkdir(parents=True, exist_ok=True)

        if iteration == 1:
            payload = build_initial_payload(
                args.drawing_image,
                prompt,
                model,
                args.max_tokens,
                args.temperature,
            )
        else:
            payload = build_followup_payload(
                model=model,
                drawing_image=args.drawing_image,
                initial_prompt=prompt,
                iteration=iteration,
                feedback_text=feedback_text or "",
                render_image=render_image_for_next,
                render_view=render_view_for_next,
                max_tokens=args.max_tokens,
                temperature=args.temperature,
            )

        write_json(iter_dir / "request_payload_preview.json", payload_for_logging(payload))
        if args.verbose:
            print(f"[iter {iteration}] querying {model}")

        query_started = time.perf_counter()
        raw = post_payload(payload, args.api_key_file, args.request_timeout, iter_dir)
        query_elapsed = time.perf_counter() - query_started
        write_json(iter_dir / "openrouter_response.json", raw)

        try:
            agent_response = parse_agent_response(raw)
        except Exception as exc:
            failure = {
                "iteration": iteration,
                "status": "parse_failure",
                "elapsed_query_seconds": query_elapsed,
                "error": str(exc),
                "traceback": traceback.format_exc(),
                "response_text": response_text(raw),
            }
            write_json(iter_dir / "iteration_metadata.json", failure)
            manifest["iterations"].append(failure)
            write_json(output_dir / "agentic_manifest.json", manifest)
            print(f"[iter {iteration}] parse_failure: {exc}")
            return 2
        if args.verbose:
            print(
                f"[iter {iteration}] requested render view: "
                f"a={agent_response.azimuth_deg:.3f} "
                f"e={agent_response.elevation_deg:.3f} "
                f"d={agent_response.distance:.3f} "
                f"need_render={agent_response.needs_render_feedback}"
            )

        script_path = iter_dir / "generate_step.py"
        script_path.write_text(agent_response.code, encoding="utf-8")
        shutil.copy2(script_path, output_dir / "generate_step_latest.py")

        execution = run_generated_code(script_path, python_exe=args.python, timeout=args.exec_timeout)
        render: dict[str, Any] | None = None
        render_image_for_next = None
        render_view_for_next = None
        should_render_for_feedback = (
            agent_response.needs_render_feedback
            and iteration < args.max_iter
            and execution.get("status") == "success"
            and execution.get("step_path")
        )
        if should_render_for_feedback:
            render_path = iter_dir / "requested_render.png"
            render = render_step(
                Path(str(execution["step_path"])),
                render_path,
                azimuth=agent_response.azimuth_deg,
                elevation=agent_response.elevation_deg,
                distance=agent_response.distance,
                python_exe=args.python,
                renderer=args.renderer,
                timeout=args.render_timeout,
                width=args.render_width,
                height=args.render_height,
            )
            if render.get("status") == "success" and render.get("render_path"):
                render_image_for_next = Path(str(render["render_path"]))
                render_view_for_next = {
                    "azimuth_deg": agent_response.azimuth_deg,
                    "elevation_deg": agent_response.elevation_deg,
                    "distance": agent_response.distance,
                }

        metadata = {
            "iteration": iteration,
            "status": execution.get("status"),
            "query_elapsed_seconds": query_elapsed,
            "model": model,
            "notes": agent_response.notes,
            "needs_render_feedback": agent_response.needs_render_feedback,
            "stop_requested_by_model": not agent_response.needs_render_feedback,
            "render_view": {
                "azimuth_deg": agent_response.azimuth_deg,
                "elevation_deg": agent_response.elevation_deg,
                "distance": agent_response.distance,
            },
            "execution": execution,
            "render": render,
            "usage": raw.get("usage"),
        }
        write_json(iter_dir / "iteration_metadata.json", metadata)
        manifest["iterations"].append(metadata)
        write_json(output_dir / "agentic_manifest.json", manifest)

        print(
            f"[iter {iteration}] {execution.get('status')} "
            f"step={execution.get('step_size_bytes', 0)} bytes "
            f"render={None if render is None else render.get('status')} "
            f"need_render={agent_response.needs_render_feedback}"
        )

        if execution.get("status") == "success" and not agent_response.needs_render_feedback:
            metadata["stop_reason"] = "model_declared_no_render_feedback_needed"
            write_json(iter_dir / "iteration_metadata.json", metadata)
            manifest["iterations"][-1] = metadata
            manifest["finished_utc"] = utc_now_iso()
            manifest["stop_reason"] = "model_declared_no_render_feedback_needed"
            write_json(output_dir / "agentic_manifest.json", manifest)
            break

        if iteration < args.max_iter:
            feedback_text = build_feedback(
                iteration=iteration,
                agent_response=agent_response,
                previous_code=previous_code,
                execution=execution,
                render=render,
                full_history_first_response=True,
                log_char_limit=args.log_char_limit,
            )
            (iter_dir / "feedback_to_next_turn.txt").write_text(feedback_text, encoding="utf-8")
            previous_code = agent_response.code

    if "stop_reason" not in manifest:
        manifest["stop_reason"] = "max_iter_reached"
        if manifest.get("iterations"):
            manifest["iterations"][-1]["stop_reason"] = "max_iter_reached"
            final_iteration = manifest["iterations"][-1].get("iteration")
            if final_iteration is not None:
                final_metadata_path = output_dir / f"iter_{int(final_iteration):02d}" / "iteration_metadata.json"
                write_json(final_metadata_path, manifest["iterations"][-1])
    manifest["finished_utc"] = utc_now_iso()
    write_json(output_dir / "agentic_manifest.json", manifest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
