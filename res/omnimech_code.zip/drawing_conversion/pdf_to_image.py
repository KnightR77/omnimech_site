                      
"""Convert one PDF drawing to image file(s)."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


DEFAULT_DPI = 300


def normalize_pages(page_count: int, page: int | None) -> list[int]:
    if page is None:
        return list(range(page_count))
    if page < 0 or page >= page_count:
        raise ValueError(f"Page index {page} is outside PDF page range 0..{page_count - 1}")
    return [page]


def output_for_page(
    output_path: Path,
    page_index: int,
    multiple_pages: bool,
    image_format: str,
) -> Path:
    suffix = f".{image_format.lower().lstrip('.')}"
    base = output_path.with_suffix("") if output_path.suffix else output_path
    if multiple_pages:
        return base.with_name(f"{base.name}_page_{page_index + 1:03d}{suffix}")
    return base.with_suffix(suffix)


def render_with_pymupdf(
    pdf_path: Path,
    output_path: Path,
    dpi: int,
    page: int | None,
    image_format: str,
) -> list[Path]:
    import fitz                

    written: list[Path] = []
    with fitz.open(pdf_path) as document:
        page_indexes = normalize_pages(document.page_count, page)
        multiple_pages = len(page_indexes) > 1
        matrix = fitz.Matrix(dpi / 72, dpi / 72)

        for page_index in page_indexes:
            pdf_page = document.load_page(page_index)
            pixmap = pdf_page.get_pixmap(matrix=matrix, alpha=False)
            target = output_for_page(output_path, page_index, multiple_pages, image_format)
            target.parent.mkdir(parents=True, exist_ok=True)
            pixmap.save(target)
            written.append(target)

    return written


def render_with_pypdfium2(
    pdf_path: Path,
    output_path: Path,
    dpi: int,
    page: int | None,
    image_format: str,
) -> list[Path]:
    import pypdfium2 as pdfium                

    written: list[Path] = []
    document = pdfium.PdfDocument(pdf_path)
    try:
        page_indexes = normalize_pages(len(document), page)
        multiple_pages = len(page_indexes) > 1
        scale = dpi / 72
        for page_index in page_indexes:
            pdf_page = document[page_index]
            image = pdf_page.render(scale=scale).to_pil()
            target = output_for_page(output_path, page_index, multiple_pages, image_format)
            target.parent.mkdir(parents=True, exist_ok=True)
            image.save(target)
            written.append(target)
            pdf_page.close()
    finally:
        document.close()

    return written


def convert_pdf_to_image(
    pdf_path: Path,
    output_path: Path | None = None,
    *,
    dpi: int = DEFAULT_DPI,
    page: int | None = 0,
    image_format: str = "png",
) -> list[Path]:
    pdf = pdf_path.expanduser().resolve()
    if not pdf.is_file():
        raise FileNotFoundError(f"PDF does not exist: {pdf}")
    if pdf.suffix.casefold() != ".pdf":
        raise ValueError(f"Input must be a PDF file: {pdf}")
    if dpi <= 0:
        raise ValueError("dpi must be positive")

    image_format = image_format.lower().lstrip(".")
    output = (
        output_path.expanduser().resolve()
        if output_path
        else pdf.with_suffix(f".{image_format}")
    )

    renderers = (("PyMuPDF", render_with_pymupdf), ("pypdfium2", render_with_pypdfium2))
    errors: list[str] = []
    for name, renderer in renderers:
        try:
            return renderer(pdf, output, dpi, page, image_format)
        except ImportError as exc:
            errors.append(f"{name} unavailable: {exc}")

    raise RuntimeError(
        "No supported PDF renderer is installed. Install one of:\n"
        "  python -m pip install pymupdf\n"
        "  python -m pip install pypdfium2 pillow\n"
        + "\n".join(errors)
    )


def parse_page(value: str) -> int | None:
    if value.lower() in {"all", "*"}:
        return None
    page = int(value)
    if page < 1:
        raise argparse.ArgumentTypeError("Page must be 1 or greater, or 'all'.")
    return page - 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert one PDF drawing to image file(s).")
    parser.add_argument("input", type=Path, help="Input PDF path")
    parser.add_argument("-o", "--output", type=Path, help="Output image path")
    parser.add_argument("--format", default="png", help="Output format, default png")
    parser.add_argument("--dpi", type=int, default=DEFAULT_DPI, help="Render DPI, default 300")
    parser.add_argument("--page", type=parse_page, default=0, help="1-based page number, or 'all'")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        written = convert_pdf_to_image(
            args.input,
            args.output,
            dpi=args.dpi,
            page=args.page,
            image_format=args.format,
        )
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    for path in written:
        print(f"Created image: {path} ({path.stat().st_size:,} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
