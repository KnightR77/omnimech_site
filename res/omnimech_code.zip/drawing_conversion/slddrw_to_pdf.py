                      
"""Convert one SolidWorks drawing (.slddrw) to one PDF file.

SolidWorks must be installed on Windows. The script uses the SolidWorks COM API
through pywin32 and deliberately contains no dataset scanning or batch logic.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any


SW_DOC_DRAWING = 3
SW_OPEN_SILENT = 1
SW_OPEN_READ_ONLY = 2
SW_SAVE_AS_CURRENT_VERSION = 0
SW_SAVE_AS_SILENT = 1


class ConversionError(RuntimeError):
    pass


def connect_to_solidworks(visible: bool) -> tuple[Any, Any, bool]:
    """Return (pythoncom, SolidWorks application, started_by_this_script)."""
    try:
        import pythoncom                
        import pywintypes                
        import win32com.client                
    except ImportError as exc:
        raise ConversionError(
            "pywin32 is not installed. Run: python -m pip install pywin32"
        ) from exc

    pythoncom.CoInitialize()
    started_here = False
    try:
        try:
            app = win32com.client.GetActiveObject("SldWorks.Application")
        except pywintypes.com_error:
            app = win32com.client.Dispatch("SldWorks.Application")
            started_here = True
        app.Visible = visible
        return pythoncom, app, started_here
    except Exception:
        pythoncom.CoUninitialize()
        raise


def describe_com_error(exc: Exception) -> str:
    excepinfo = getattr(exc, "excepinfo", None)
    if excepinfo and len(excepinfo) > 2 and excepinfo[2]:
        return str(excepinfo[2]).strip()
    return str(exc).strip()


def long_ref() -> Any:
    import pythoncom                
    from win32com.client import VARIANT                

    return VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)


def com_value(obj: Any, name: str) -> Any:
    value = getattr(obj, name)
    return value() if callable(value) else value


def get_open_document(app: Any, source: Path) -> Any | None:
    try:
        return app.GetOpenDocumentByName(str(source))
    except Exception:
        return None


def open_drawing(app: Any, source: Path) -> tuple[Any, bool]:
    existing = get_open_document(app, source)
    if existing is not None:
        return existing, False

    try:
        errors = long_ref()
        warnings = long_ref()
        model = app.OpenDoc6(
            str(source),
            SW_DOC_DRAWING,
            SW_OPEN_SILENT | SW_OPEN_READ_ONLY,
            "",
            errors,
            warnings,
        )
    except Exception as exc:
        raise ConversionError(
            f"SolidWorks could not open drawing: {describe_com_error(exc)}"
        ) from exc

    if model is None:
        raise ConversionError(f"SolidWorks returned no drawing document for {source}")

    return model, True


def activate_document(app: Any, model: Any, expected_source: Path) -> Any:
    errors = long_ref()
    try:
        active_model = app.ActivateDoc3(com_value(model, "GetTitle"), True, 0, errors)
    except Exception as exc:
        raise ConversionError(
            f"Could not activate drawing: {describe_com_error(exc)}"
        ) from exc

    if active_model is None:
        raise ConversionError(
            f"SolidWorks could not activate drawing (error {errors.value})."
        )

    try:
        active_path = Path(com_value(active_model, "GetPathName")).resolve()
    except Exception as exc:
        raise ConversionError("Could not verify the active SolidWorks drawing.") from exc

    if active_path != expected_source:
        raise ConversionError(
            "SolidWorks activated the wrong document. "
            f"Expected {expected_source}, but got {active_path}."
        )
    return active_model


def save_pdf(model: Any, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = model.SaveAs3(
            str(output), SW_SAVE_AS_CURRENT_VERSION, SW_SAVE_AS_SILENT
        )
    except Exception as exc:
        raise ConversionError(
            f"SolidWorks PDF export failed: {describe_com_error(exc)}"
        ) from exc

    if not output.is_file():
        detail = f" (SaveAs3 returned {result!r})" if result is not None else ""
        raise ConversionError(f"SolidWorks did not create the PDF file{detail}.")
    if output.stat().st_size == 0:
        raise ConversionError("SolidWorks created an empty PDF file.")


def close_if_opened_here(app: Any, model: Any, opened_here: bool) -> None:
    if not opened_here or model is None:
        return
    try:
        app.CloseDoc(com_value(model, "GetTitle"))
    except Exception:
        pass


def convert_slddrw_to_pdf(
    source: Path,
    output: Path | None = None,
    *,
    overwrite: bool = False,
    visible: bool = False,
) -> Path:
    source = source.expanduser().resolve()
    if not source.is_file():
        raise ConversionError(f"Input drawing does not exist: {source}")
    if source.suffix.casefold() != ".slddrw":
        raise ConversionError(f"Input must be a .slddrw file: {source}")

    output = (output or source.with_suffix(".pdf")).expanduser().resolve()
    if output.exists() and not overwrite:
        raise ConversionError(f"Output already exists; use --overwrite: {output}")
    if output.exists() and output.is_file():
        output.unlink()

    pythoncom, app, started_here = connect_to_solidworks(visible)
    model = None
    opened_here = False
    try:
        model, opened_here = open_drawing(app, source)
        model = activate_document(app, model, source)
        save_pdf(model, output)
        return output
    finally:
        close_if_opened_here(app, model, opened_here)
        if started_here:
            try:
                app.ExitApp()
            except Exception:
                pass
        pythoncom.CoUninitialize()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Convert one .slddrw drawing to PDF.")
    parser.add_argument("input", type=Path, help="Input SolidWorks .slddrw drawing")
    parser.add_argument("-o", "--output", type=Path, help="Output PDF path")
    parser.add_argument("--overwrite", action="store_true", help="Replace existing output")
    parser.add_argument("--visible", action="store_true", help="Show SolidWorks while exporting")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        output = convert_slddrw_to_pdf(
            args.input,
            args.output,
            overwrite=args.overwrite,
            visible=args.visible,
        )
    except ConversionError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"ERROR: Unexpected failure: {exc}", file=sys.stderr)
        return 1

    print(f"Created PDF: {output} ({output.stat().st_size:,} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
